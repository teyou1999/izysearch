docker build  -t base_search_image:0.0.1 .
