docker build  -t base_worker_image:0.0.1 .
