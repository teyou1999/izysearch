docker build  -t search_image:0.0.1 -f search.Dockerfile .
