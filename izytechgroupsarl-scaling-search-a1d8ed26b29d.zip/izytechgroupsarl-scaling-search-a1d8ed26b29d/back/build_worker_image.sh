docker build  -t worker_image:0.0.1 -f worker.Dockerfile .
