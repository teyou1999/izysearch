# Check migrations and run

DIR="/usr/local/lib/python3.6/site-packages/noyau/migrations"
items=($(ls -A $DIR | grep ""))

echo "*************************"
python3 manage.py makemigrations
new_migrations=$(python3 manage.py showmigrations | grep '\[ \]')
echo "$new_migrations"


if [ "$(python3 manage.py showmigrations | grep '\[ \]')" ]; then
    # On va seeder que si on n'a pas un fichier 0002* -> on a dejà migrate
    echo "-------------------------------"
    echo "Migrating data base"
    echo "\n"
    python3 manage.py migrate

    seed="1"
    match_item=0002
    for i in "${items[@]}"; do
      if [[ "$i" =~ "$match_item" ]]; then
        echo "++++++++++++++++++++++++++"
        echo "The database is already seeded"
        seed="0"
        break
      fi
    done
    echo "Seed : $seed"
    if [ $seed = "1" ]; then
        echo "++++++++++++++++++++++++++"
        echo "Insert base data in Search"
        python3 manage.py test noyau.seeders.super_admin_seeder
    fi
else
    echo "-------------------------------"
    echo "-------------------------------"
    echo "No migration needed"
    echo "-------------------------------"
    echo "-------------------------------"
fi
