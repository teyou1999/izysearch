./manage.py test noyau.seeders.super_admin_seeder
