from itypes import List
from noyau import TextPreprocessor
from noyau.models import MetadataValue
from noyau.repositories.db import get_all


def build_file_metadata(file_, preprocessor:TextPreprocessor=None):
    """
    Build Dynamically the metadata of a file.
    :param file_:
    :return:
    """
    metadata = {}
    metadata_values = get_all(MetadataValue, file=file_)
    for value in metadata_values:
        key = value.metadata.name
        if value.metadata.type.type == 1:
            metadata[key] = preprocessor.preprocess_metadata(value.value)

        if value.metadata.type.type == 2:
            metadata[key] = value.min_date

        # Base Interval Metadata
        if value.metadata.type.type == 3 :
            metadata[key] = {
                'min': value.min_value,
                'max': value.max_value
            }

        # Date Metadata
        if value.metadata.type.type == 4:
            metadata[key] = {
                'min': value.min_date,
                'max': value.max_date
            }

        # Base List
        if value.metadata.type.type == 5:
            metadata[key] = [preprocessor.preprocess_metadata(e) for e in value.value.split('@')]

    return metadata


def format_files_for_es(files:List, index_name:str, doc_type:str, preprocessor:TextPreprocessor=None)->list:
    """
    Build File entries in ElasticSearch. \
    :param files:
    :param index_name:
    :param doc_type:
    :param preprocessor:
    :return:
    """
    docs = []
    for file_ in files:
        es_entry = {
            'file_id': file_.id,
            'folder_id': file_.folder.id,
            '_index': index_name,
            '_type': doc_type,
            'text': file_.text
        }

        if file_.display_name:
            base_name = file_.display_name.split(".")[0]
            es_entry['name'] = preprocessor.preprocess_metadata(base_name)

        if file_.extension:
            es_entry['extension'] = file_.extension
        
        if file_.temp_pdf:
            es_entry['temp_pdf'] = file_.temp_pdf

        es_entry['metadata'] = build_file_metadata(file_, preprocessor)

        docs.append(es_entry)

    return docs


def format_pages_for_es(pages:List, index_name:str, doc_type:str, preprocessor:TextPreprocessor=None) -> list:
    """
    Build list of pages to index. \
    :param pages:
    :param index_name:
    :param doc_type:
    :param preprocessor:
    :return:
    """
    es_pages = []
    for page in pages:
        es_pages.append({
            'page_id': page.id,
            'file_id': page.file.id,
            'folder_id' : page.file.folder.id,
            '_index': index_name,
            '_type': doc_type,
            'text': preprocessor.preprocess_string(page.text)
        })

    return es_pages
