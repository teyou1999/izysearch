from noyau.models import Page
from noyau.repositories.db import get_all
from noyau.repositories.folder_helper import get_children_files


def get_files_to_split_ids(folder):
    """
    Get All files in a folder that need to split.
    :param folder:
    :return:
    """
    files = get_children_files(folder, processable=True)
    files_to_split_ids = []
    for file_ in files:
        if not file_.last_analyzed_date or not file_.is_analyzed or file_.last_analyzed_date < file_.created_at:
            files_to_split_ids.append(file_.id)

    return files_to_split_ids


def get_files_to_index(folder):
    """
    Get All files in the folder which need to be indexed.
    :param folder:
    :return:
    """
    files = get_children_files(folder, processable=True)
    files_to_indexed = []
    for file_ in files:
        if not file_.last_index_date or not file_.is_indexed or file_.last_index_date < file_.created_at:
            files_to_indexed.append(file_)

    return files_to_indexed


def get_pages_to_index(folder):
    """
    Get All pages in the folder which need to be indexed.
    :param folder:
    :return:
    """
    files = get_files_to_index(folder)
    return get_all(Page, file__in=files)


def get_all_pages(folder):
    """
    Get All pages in the folder.
    :param folder:
    :return:
    """
    files = get_children_files(folder)
    return get_all(Page, file__in=files)
