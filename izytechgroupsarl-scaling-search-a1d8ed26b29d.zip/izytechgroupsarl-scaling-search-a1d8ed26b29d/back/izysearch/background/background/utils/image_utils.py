import os
from typing import List

from pdf2image import convert_from_path


def create_single_page_image_path(file_path:str, page_index:int=0) -> str:
    """
    Create the image path related to a single page. \
    The created path will be returned as a string. \
    :param file_path:
    :param page_index:
    :return:
    """
    dirname = os.path.dirname(os.path.abspath(file_path))
    basename = os.path.basename(file_path)
    if basename[0] != '.':
        path = dirname + '/.' + os.path.splitext(basename)[0]+ '_' + str(page_index) + '.jpg'
    else:
        path = dirname + '/' + os.path.splitext(basename)[0]+ '_' + str(page_index) + '.jpg'

    return path


def create_file_image_paths( file_path:str) -> List:
    """
    Create image paths related to each single page in PDF. \
    :param file_path:
    :return:
    """
    images_files = []
    try:
        pages = convert_from_path(file_path, 200, first_page=1)

        # Store all the i
        for i, page in enumerate(pages):
            image_file = create_single_page_image_path(file_path, i)
            images_files.append(image_file)
            # Do not create the file if it exists
            if os.path.exists(image_file):
                pass
            else:
                page.save(image_file, 'JPEG')
    except Exception:
        print('Error During the analysis of : ', file_path)

    return images_files
