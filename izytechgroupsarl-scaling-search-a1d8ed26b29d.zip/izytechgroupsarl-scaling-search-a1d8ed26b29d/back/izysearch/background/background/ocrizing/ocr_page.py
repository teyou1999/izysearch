from noyau.models import File

try :
    from PIL import Image
except ImportError :
    import Image
import pytesseract


def extract_text_in_image ( page_index: int = -1 , file: File = None , page_image_path: str = '' ) :
    """
    Extract the textual content of a page for building a chunk. \
    """
    try :
        page_context = pytesseract.image_to_string ( Image.open ( page_image_path ) )
        return page_context
    except :
        print ( f'An Error Occurs during the page {page_index + 1} content extraction of {file.name} ' )
        return ''
