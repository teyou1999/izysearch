from background.utils.es_index_builder import format_pages_for_es
from background.utils.folder_utils import get_pages_to_index , get_all_pages
from noyau import Memory
from noyau.models import Folder, Log , PageIndex
from noyau.repositories.db import get_one_with_params
from noyau.repositories.folder_helper import get_children_folder


class ChunkIndexer ( ) :

    def __init__ ( self , folder_id , parent_log_id ) :
        folder = Folder.objects.get ( id = folder_id )
        self.folder = folder
        self.folders = get_children_folder ( folder )
        self.log = Log.objects.get ( id = parent_log_id )
        m = Memory.getInstance ( )
        self.es_client = m.es_chunk_client
        self.preprocessor = m.text_processor

    def index_folder ( self ) :
        """
        Indexation of a Folder
        :return:
        """
        self.__index_folder__ ( self.folder )

    def __index_folder__ ( self , folder ) :
        """
        Index pages of a folder. <br/>
        :param folder:
        :return:
        """
        page_index = get_one_with_params ( PageIndex , folder = folder )
        existing_index = False
        if page_index :
            if not self.es_client.index_exists ( page_index.es_index ) :
                index_name = f'{folder.name}_{folder.id}'.lower ( )
                page_index.es_index = index_name
                page_index.save ( )
            else :
                index_name = page_index.es_index
                existing_index = True
        else :
            index_name = f'{folder.name}_pages_{folder.id}'.lower ( )
            # Delete the index if its exists
            self.es_client.delete_index ( index_name , user = self.log.account.username )
            # Create the index
            self.es_client.create_index ( index_name , user = self.log.account.username )

        if existing_index :
            pages = get_pages_to_index ( folder )
        else :
            # Indexation from Scratch
            pages = get_all_pages ( folder )

        print ( f'Number of pages in {folder.name} : {len ( pages )}' )

        if not pages :
            return

        pages_to_index = format_pages_for_es ( pages , index_name , '_doc' , self.preprocessor )
        # Insert Docs
        self.es_client.insert_doc_in_index ( pages_to_index , index_name , '_doc' , doc_size = len ( pages ) ,
                                             user = self.log.account.username )

        if not page_index :
            PageIndex.objects.create (
                es_index = index_name ,
                folder = folder ,
            )
