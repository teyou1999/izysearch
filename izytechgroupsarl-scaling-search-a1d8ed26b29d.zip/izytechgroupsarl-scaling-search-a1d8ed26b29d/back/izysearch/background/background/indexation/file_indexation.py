from background.utils.es_index_builder import format_files_for_es
from background.utils.folder_utils import get_files_to_index
from noyau import Memory
from noyau.models import Folder , Log , DocIndex
from noyau.repositories.db import get_one_with_params
from noyau.repositories.folder_helper import get_children_folder , get_children_files , get_file_text


class FileIndexer ( ) :

    def __init__ ( self , folder_id , parent_log_id ) :
        folder = Folder.objects.get ( id = folder_id )
        self.folder = folder
        self.folders = get_children_folder ( folder )
        self.log = Log.objects.get ( id = parent_log_id )
        m = Memory.getInstance ( )
        self.es_client = m.es_client
        self.preprocessor = m.text_processor

    def index_folder ( self ) :
        """
        Indexation of a Folder
        :return:
        """
        self.__index_folder__ ( self.folder )

    def __index_folder__ ( self , folder ) :
        """
        Index a Folder files in elastic Search
        :param folder:
        :return:
        """
        doc_index = get_one_with_params ( DocIndex , folder = folder )
        existing_index = False
        if doc_index :
            if not self.es_client.index_exists ( doc_index.es_index ) :
                index_name = f'{folder.name}_{folder.id}'.lower ( )
                doc_index.es_index = index_name
                doc_index.save ( )
            else :
                index_name = doc_index.es_index
                existing_index = True
        else :
            index_name = f'{folder.name}_{folder.id}'.lower ( )
            # Delete the index if its exists
            self.es_client.delete_index ( index_name , user = self.log.account.username )
            # Create the index
            self.es_client.create_index ( index_name , user = self.log.account.username )

        if existing_index :
            children_files = get_files_to_index ( folder )
        else :
            children_files = get_children_files ( folder )

        if not children_files :
            return

        for file_ in children_files :
            file_text = get_file_text ( file_ )
            file_text = self.preprocessor.preprocess_string ( file_text )

            # Get the logical name to the chunk text
            if not hasattr ( file_ , 'display_name' ) :
                doc_title = file_.display_name.split ( '.' )[0]
                doc_title = doc_title.replace ( '_' , ' ' ).replace ( '-' , ' ' )
                doc_title = self.preprocessor.preprocess_string ( doc_title )
                file_.logical_name = doc_title

            file_.text = file_text

        # Save all this in ElasticSearch
        docs_to_index = format_files_for_es ( children_files , index_name , '_doc' , self.preprocessor )

        # Insert Docs
        self.es_client.insert_doc_in_index ( docs_to_index , index_name , '_doc' , doc_size = len ( children_files ) ,
                                             user = self.log.account.username )

        if not doc_index :
            DocIndex.objects.create (
                es_index = index_name ,
                folder = folder ,
            )
