import os

import pdfkit
from background.spliting.abstract_spliter import AbstractPDFSpliter
from bs4 import BeautifulSoup
from noyau.models import File , Log
from noyau.utils.folder_utils import escaped_file_or_folder_name


class HTMLSpliter(AbstractPDFSpliter):

    def __init__(self,
                 file:File,
                 parent_log:Log):
        AbstractPDFSpliter.__init__(self, file, parent_log)


    def create_pdf_file( self ):
        """
        Create a PDF file from the doc file to easily process the content. \
        :return:
        """
        # Create the temp_pdf field in the file object
        self.make_temp_pdf_path()

        # Modify the HTML content before converting
        # TODO : Regarder comment renamer
        # self.rename_fields_content(self.file.path)

        # Convert Html to PDF
        options = {
            'page-size': 'Letter',
            'margin-top': '0.75in',
            'margin-right': '0.75in',
            'margin-bottom': '0.75in',
            'margin-left': '0.98in',
            'encoding': "UTF-8",
            'custom-header' : [
                ('Accept-Encoding', 'gzip')
            ],
            'no-outline': None
        }

        try:
            pdfkit.from_file(self.file_path, self.file.temp_pdf, options)
            # Wait while the File is Created
            while not os.path.exists(self.file.temp_pdf):
                pdfkit.from_file(self.file_path, self.file.temp_pdf, options)
        except:
            print(f'Problem While converting the HTML to pdf : {self.file_path}')


    def rename_fields_content(self, html_file, tags=["href", "src"]):
        """
        This function modifies the inside links on system files, in order to be consistent with the renamed ones on the disk. <br/>
        :param html_file:
        :param tags:
        :return:
        """
        # aim is to modify the inside of the html in order to be consistent with the renaming done on the disk
        file_content = open(html_file,"r").read()
        soup = BeautifulSoup(file_content, 'html.parser')
        for tag in tags:
            dic_params = {tag:True}
            for elt in soup.find_all([], **dic_params):
                # we care only about the ressources on disk -> ignoring outside ressources
                if elt[tag][:4] != "http" and elt[tag][:6] != 'mailto' and elt[tag][:5] != 'data:':
                    new_name = escaped_file_or_folder_name(elt[tag])
                    extension = new_name.split('.')[-1]
                    elt[tag] = f"{new_name[0]}{'_'.join(new_name[1:].split('.')[:-1])}.{extension}"
        with open(html_file, "w") as file:
            file.write(str(soup))

