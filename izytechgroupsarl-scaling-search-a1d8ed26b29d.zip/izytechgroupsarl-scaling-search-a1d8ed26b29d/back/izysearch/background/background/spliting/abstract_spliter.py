import os
from background.ocrizing.ocr_page import extract_text_in_image
from background.spliting.spliter import Spliter
from bs4 import BeautifulSoup
from subprocess import Popen , PIPE
from noyau.models import File , Log , Page
from noyau.repositories.db import insert_by_batch
from pdf2image import convert_from_path
from izysearch.settings import MIN_BEFORE_OCR , IMAGE_DPI


class AbstractPDFSpliter ( Spliter ) :

    def __init__ ( self ,
                   file: File ,
                   parent_log: Log ) :
        """
        file is an instance of the File Object so that we can retrieve its path on the file system. <br/>
        :param file:
        :param temp_pdf : Path of the PDF file constructed based on the original one
        """
        Spliter.__init__ ( self , file )
        self.parent_log = parent_log
        self.make_temp_pdf_path ( )

    def save_pages ( self ) :
        """
        Save all the pages extracted from a file
        :return:
        """
        # Save the image
        insert_by_batch ( Page , self.pages )

    def split_file ( self ) :
        """
        This function split the file into pages. <br/>
        This return True id the operation is successful
        :return:
        """
        # Parse the HTML parsed File
        successfull = self._parse_content ( )

        # Save the pages and the LOGs
        if successfull :
            # Save the pages
            self.save_pages ( )

        if self.file_temp_html and os.path.exists ( self.file_temp_html ) :
            self._remove_processed_page ( )

        self.parent_log.success = True
        self.parent_log.save ( )

        return successfull

    def _parse_pdf_to_html ( self ) :
        """
        Parse PDF to HTML using Poppler .\
        :return:
        """
        cmd = "pdftotext -bbox-layout {} {}".format ( self.file_temp_pdf , self.file_temp_html )

        process = Popen ( cmd , shell = True , stdout = PIPE , stderr = PIPE )
        try :
            process.wait ( timeout = 500 )
        except :
            print ( 'killing' )
            self.kill ( process.pid )

    def _to_html ( self ) :
        """
         Read an HTML file and return the corresponding string
        :return:
        """
        html_string = ""
        with open ( self.file_temp_html , 'r' ) as f :
            html_string = f.read ( )
        return html_string

    def _remove_processed_page ( self ) :
        """
        This function removed the file created for easily parses the pdf
        :return:
        """
        cmd = "rm {}".format ( self.file_temp_html )
        process = Popen ( cmd , shell = True , stdout = PIPE , stderr = PIPE )
        process.wait ( )

    def get_page_text ( self , page ) :
        """
        This function create the string corresponding to a page text. \
        :param line:
        :return:
        """
        blocks = page.findAll ( 'block' )
        if blocks is None or len ( blocks ) == 0 :
            return ''

        page_text = ''
        for block in blocks :
            block_text = ''
            lines = block.find_all ( 'line' )
            for line in lines :
                line_text = line.getText ( )
                block_text += (' ' + line_text.replace ( "\n" , " " ))
            page_text += (' ' + block_text)
        return page_text

    def _create_image ( self , page_index=0 ) :
        """
        Create the image file for a page. \
        :param page_index:
        :return:
        """
        dirname = os.path.dirname ( os.path.abspath ( self.file_temp_pdf ) )
        basename = os.path.basename ( self.file_temp_pdf )

        if basename[0] != '.' :
            path = dirname + '/.' + os.path.splitext ( basename )[0] + '_' + str ( page_index ) + '.jpg'
        else :
            path = dirname + '/' + os.path.splitext ( basename )[0] + '_' + str ( page_index ) + '.jpg'

        return path

    def _create_images ( self ) :
        """
        Create one image for each pages of the pdf. \
        :return:
        """
        pages_images = { }
        try :
            batch = 50
            step = 0
            convert = True
            while convert :
                start = step * batch + 1
                to = (step + 1) * batch
                print ( f'Parse from page {start} - {to}' )
                pages = convert_from_path ( self.file_temp_pdf , IMAGE_DPI , first_page = start , last_page = to )
                step += 1
                if not pages or len ( pages ) == 0 :
                    convert = False
                else :
                    for i , page in enumerate ( pages ) :
                        img_index = start + i
                        image_file = self._create_image ( img_index )
                        pages_images[str ( img_index )] = image_file
                        # Do not create the file if it exists
                        if os.path.exists ( image_file ) :
                            continue
                        page.save ( image_file , 'JPEG' )
            return pages_images
        except :
            print ( "error with the pdf page count" )
            return pages_images

    def _parse_content ( self ) :
        """
        Parse The PDF corresponding to the parse file.<br/>
        :return:
        """
        # try:
        if not os.path.exists ( self.file_temp_pdf ) :
            return False

        # Create temp PDF file on the
        self._parse_pdf_to_html ( )
        # Get the HTML content
        html_string = self._to_html ( )

        if html_string == '' :
            return True

        self.soup = BeautifulSoup ( self._to_html ( ) , 'html.parser' )
        body = self.soup.body

        # Create images
        page_images = self._create_images ( )

        # Get the pages content and create page objects.
        pages = body.find_all ( 'page' )

        for pos , page in enumerate ( pages ) :
            page_text = self.get_page_text ( page )

            page_image = page_images[str ( pos + 1 )]

            nb_tokens = len ( page_text.strip ( ).split ( ' ' ) )

            if nb_tokens < MIN_BEFORE_OCR :
                # Apply OCR to Extract image Text
                page_text = extract_text_in_image ( pos , self.file , page_image )
                if page_text.strip ( ) != "" :
                    self.create_page ( text = page_text , page = pos , image = page_image )
            else :
                self.create_page ( text = page_text , page = pos , image = page_image )

        if not self.pages :
            pos = 0
            page_image = page_images[str ( pos + 1 )]
            page_text = self.file.display_name
            self.create_page ( text = page_text , page = pos , image = page_image )
        return True
