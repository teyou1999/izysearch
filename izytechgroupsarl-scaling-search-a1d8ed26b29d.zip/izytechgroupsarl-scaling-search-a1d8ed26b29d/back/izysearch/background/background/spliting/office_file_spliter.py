import os
from subprocess import Popen , PIPE
from background.spliting.abstract_spliter import AbstractPDFSpliter
from noyau.models import File , Log

from izysearch.settings import TEMP_PDF_DIR


class OfficeSpliter ( AbstractPDFSpliter ) :

    def __init__ ( self ,
                   file: File ,
                   parent_log: Log ) :
        AbstractPDFSpliter.__init__ ( self , file , parent_log )

    def create_pdf_file ( self ) :
        """
        Create a PDF file from a MS office file to easily process the content. \
        :return:
        """
        # Create the temp_pdf field in the file object
        self.make_temp_pdf_path ( )

        # Convert the doc document in PDF using Libre Office
        dirname = TEMP_PDF_DIR
        basename = os.path.basename ( self.file_path )

        temp_converter_file = dirname + '/' + os.path.splitext ( basename )[0] + '.pdf'

        # use unoconv for the pdf creation
        i = 0
        while i < 4 and not os.path.exists ( self.file.temp_pdf ) :
            i += 1
            print ( f'Conversion Iteration : {i}' )
            try :
                cmd = "libreoffice --convert-to pdf --outdir {} {}".format ( dirname , self.file_path )
                process = Popen ( cmd , shell = True )
                try :
                    process.wait ( timeout = 5000 )
                except :
                    self.kill ( process.pid )
                    print ( f"Killing conversion of Doc* to PDF of : {self.file_path}" )
                    return
                cmd = "mv {} {}".format ( temp_converter_file , self.file.temp_pdf )
                process = Popen ( cmd , shell = True , stdout = PIPE , stderr = PIPE )
                process.wait ( )
            except Exception :
                print ( f"Problem during the conversion of Office* to PDF of : {self.file_path}" )
                return
