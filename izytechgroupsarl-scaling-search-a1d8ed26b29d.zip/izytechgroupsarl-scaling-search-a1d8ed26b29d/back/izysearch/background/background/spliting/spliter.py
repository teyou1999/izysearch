import os
import string
from noyau.models import Page , Image , File
import psutil as psutil
from noyau.repositories.db import get_one_with_params

printable = list ( string.printable ) + ["â" , "ä" , "ç" , "é" , "è" , "ê" , "ë" , "î" , "ï" , "ô" , "ö" , "ù" , "û" ,
                                         "ü" , "ÿ" , "À" , "Â" , "Ä" , "Ç" , "É" , "È" , "Ê" , "Ë" , "Î" , "Ï" , "Ô" ,
                                         "Ö" , "Ù" , "Û" , "Ü" , "Ÿ" , "Œ" , "œ" , "é" , "É" , "ë" , "Ë" , "ê" , "Ê" ,
                                         "è" , "È" , "ç" , "Ç" , "à" , "À" , "ù" , "Ù" , "ö" , "Ö" , "ô" , "Ô" , "û" ,
                                         "Û" , "ü" , "Ü" , "ï" , "Ï" , "î" , "Î" , "ä" , "Â" , "â" , "Â" , "," , ";" ,
                                         ":" , "(" , ")" , "^" , "$" , "=" , "#" , "-" , "\\" , "\'" , "&" , "[" , "]" ,
                                         "'" , "`" , "‘" , "’"]


class Spliter :

    def __init__ ( self , file ) :
        self.file = file
        self.pages = []
        self.file_path = str ( self.file.path )
        self.file_temp_pdf = ''
        self.file_temp_html = ''

    def kill ( self , proc_pid ) :
        process = psutil.Process ( proc_pid )
        for proc in process.children ( recursive = True ) :
            proc.kill ( )
        process.kill ( )

    def make_temp_pdf_path ( self ) :
        """
        Make the HTML file used in Chunking Process. <br/>
        The name of this file is based on path of the Processed file. <br/>
        :return:
        """
        dirname = os.path.dirname ( os.path.abspath ( self.file_path ) )
        basename = os.path.basename ( self.file_path )

        if self.file.extension.lower ( ) == '.pdf' :
            self.file_temp_pdf = self.file_path
        else :
            self.file_temp_pdf = dirname + '/.' + os.path.splitext ( basename )[0] + '.pdf'
            existing_pdf = get_one_with_params ( File , temp_pdf = self.file_temp_pdf )
            if existing_pdf :
                self.file_temp_pdf = f"{dirname}/.{os.path.splitext ( basename )[0]}_{self.file.id}.pdf"

        self.file_temp_html = dirname + '/.' + os.path.splitext ( basename )[0] + '.html'

        self.file.temp_pdf = self.file_temp_pdf
        self.file.temp_html = self.file_temp_html

        self.file.save ( )

    def make_chunk_title ( self , chunk_text ) :
        """
        This function helps to generate the title of a Chunk based on its content. <br/>
        :param chunk_text:
        :return:
        """
        return str ( " ".join ( chunk_text.split ( )[:20] ) )

    def make_url ( self , page_index ) :
        """
        Build the file to display for a chunk
        :param page_index:
        :return:
        """
        return self.file.temp_pdf + "#page=" + str ( page_index ).strip ( )

    def create_page ( self , text , page=None , image=None ) :
        """
        Creation of a new Page with attributes given as parameter. <br/>
        Some attributes like the url and sometimes the title are calculated. <br/>
        :param text:
        :param ref:
        """
        # Do not create this chunk twice
        page_obj = get_one_with_params ( Page , file = self.file , page = page )
        if page_obj :
            return None

        img = get_one_with_params ( Image , path = image , page_num = page )

        if not img :
            img = Image.objects.create (
                path = image ,
                page_num = page
            )

        # Reformat chunk text
        text = ''.join ( [c for c in text if c in printable] )

        page = Page (
            text = text ,
            title = self.make_chunk_title ( text ) ,
            url = self.make_url ( page + 1 ) ,
            page = page ,
            image = img ,
            file = self.file
        )

        self.pages.append ( page )
