from background.spliting.abstract_spliter import AbstractPDFSpliter
from noyau.models import File , Log


class PDFSpliter(AbstractPDFSpliter):

    def __init__(self,
                 file:File,
                 parent_log:Log):
        AbstractPDFSpliter.__init__(self, file, parent_log)
