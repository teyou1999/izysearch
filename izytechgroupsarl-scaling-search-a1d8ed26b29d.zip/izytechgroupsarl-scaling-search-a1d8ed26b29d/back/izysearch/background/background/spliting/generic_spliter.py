from background.spliting.html_file_spliter import HTMLSpliter
from background.spliting.image_spliter import ImageSpliter
from background.spliting.office_file_spliter import OfficeSpliter
from background.spliting.pdf_file_spliter import PDFSpliter
from noyau.models import File , Log


class GenericSpliter ( ) :
    __slots__ = ('file' , 'parent_log')

    def __init__ ( self , file: File , parent_log: Log ) :
        self.file = file
        self.parent_log = parent_log

    def analyze ( self ) :
        """
        This function analyzes the content of a file according to its extension. \
        :return:
        """
        if self.file.extension in ['.docx' , '.doc' , '.odt' , '.rtf' , '.docm' ,
                                   '.pptx' , '.ppt' , '.pptm' , '.odd' , 'ods' ,
                                   '.xls' , '.xlsx' , '.xlsm' '.odp'
                                   ] :
            spliter = OfficeSpliter ( self.file , self.parent_log )
            spliter.create_pdf_file ( )
            return spliter.split_file ( )

        if self.file.extension in ['.pdf'] :
            spliter = PDFSpliter ( self.file , self.parent_log )
            return spliter.split_file ( )

        if self.file.extension in ['.html' , '.xhtml'] :
            spliter = HTMLSpliter ( self.file , self.parent_log )
            spliter.create_pdf_file ( )
            return spliter.split_file ( )

        if self.file.extension in ['.jpg' , '.jpeg' , '.png'] :
            spliter = ImageSpliter ( self.file , self.parent_log )
            spliter.create_pdf_file ( )
            return spliter.split_file ( )
