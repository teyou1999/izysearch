from background.spliting.abstract_spliter import AbstractPDFSpliter
from fpdf import FPDF
from noyau.models import File , Log


class ImageSpliter ( AbstractPDFSpliter ) :

    def __init__ ( self ,
                   file: File ,
                   parent_log: Log ) :
        AbstractPDFSpliter.__init__ ( self , file , parent_log )

    def create_pdf_file ( self ) :
        """
        Create a PDF file from the image file to easily process the content. \
        :return:
        """
        # Create the temp_pdf field in the file object
        self.make_temp_pdf_path ( )
        # self.file_path is the source image file path
        # self.file.temp_pdf is the temp pdf file

        pdf = FPDF ( )
        pdf.add_page ( )
        pdf.image ( self.file_path , x = 2 , y = 2 , w = 180 , h = 280 )
        pdf.output ( self.file_temp_pdf , "F" )
