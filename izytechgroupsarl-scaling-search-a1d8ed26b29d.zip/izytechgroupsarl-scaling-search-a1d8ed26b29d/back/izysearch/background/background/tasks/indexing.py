from background.indexation.page_indexation import ChunkIndexer
from background.indexation.file_indexation import FileIndexer
from background.utils import FILE_INDEXING_WEIGTH , PAGE_INDEXING_WEIGTH
from celery import shared_task
from noyau.models import Folder , Job, Log
from noyau.repositories.db import get_one_with_params
from noyau.utils.organisation_utils import get_organisation_root_folder


def index_folder(folder_id, parent_log_id):
    """
    Lexical and Neural Indexation of folder documents in ElasticSearch. \
    :param folder_id:
    :param parent_log:
    :return
    """
    log = get_one_with_params(Log, id=parent_log_id)
    folder = get_one_with_params(Folder, id=folder_id)

    jobs = []
    # Get The root Folder of this organisation
    root_folder = get_one_with_params(Folder, uuid=folder.organisation.root_folder)

    doc_indexation = folder_files_indexation.delay(root_folder.id,  parent_log_id)
    doc_indexation_job = Job.objects.create(
                process_id=doc_indexation.id,
                log=log,
                weigth=FILE_INDEXING_WEIGTH
    )
    jobs.append(doc_indexation_job)

    page_indexation = folder_chunks_indexation.delay(root_folder.id,  parent_log_id)
    page_indexation_job = Job.objects.create(
                process_id=page_indexation.id,
                log=log,
                weigth=PAGE_INDEXING_WEIGTH
    )
    jobs.append(page_indexation_job)

    return jobs

@shared_task
def folder_files_indexation(folder_id, parent_log_id):
    """
    Lexical Indexation of folder documents in ElasticSearch. \
    :param folder_id:
    :param parent_log_id:
    :return:
    """
    folder = get_one_with_params(Folder, id=folder_id)
    root_folder = get_organisation_root_folder(folder.organisation)
    try:
        indexer = FileIndexer(root_folder.id, parent_log_id)
        indexer.index_folder()
    except:
        print(f"Document indexing failure of : {folder.name}")



@shared_task
def folder_chunks_indexation(folder_id, parent_log_id):
    """
    Lexical Indexation of folder Chunks this force the indexing of all orga\
    :param folder_id:
    :param parent_log_id:
    :return:
    """
    folder = get_one_with_params(Folder, id=folder_id)
    root_folder = get_organisation_root_folder(folder.organisation)
    try:
        chunk_indexer = ChunkIndexer(root_folder.id, parent_log_id)
        chunk_indexer.index_folder()
    except:
        print(f"Lexical indexing failure of : {folder.name}")
