import os
import time

from background.spliting.generic_spliter import GenericSpliter
from background.utils import CHUNKING_WEIGTH
from celery import shared_task
from django.utils.timezone import get_current_timezone
from noyau.models import Page , File , Log , Folder
from noyau.models.job import Job
from noyau.repositories.db import get_one_with_params , get_all
from noyau.repositories.folder_helper import get_children_files
from noyau.repositories.log_helper import delete_log
from datetime import datetime
from izysearch.settings import SPLITING_TIMEOUT


def delete_temp_data ( file: File ) :
    """
    Delete all the temps info created while parsing a doc :
    temp_pdf, temp_html, pages, image
    temp_pdf
    :param file:
    :return:
    """
    pages = get_all ( Page , file = file )
    for page in pages :
        delete_log ( 'Chunk' , page.id )
        page.delete ( )

        if os.path.exists ( file.temp_html ) :
            os.remove ( file.temp_html )

        if os.path.exists ( file.temp_pdf ) and file.extension == '.pdf' :
            os.remove ( file.temp_pdf )


@shared_task ( soft_time_limit = SPLITING_TIMEOUT )
def split_single_file ( file_id , parent_log_id ) :
    """
    Split a document given it ID
    :param file_id:
    :param parent_log_id:
    :return:
    """
    file = get_one_with_params ( File , id = file_id )
    # Delete Old Pages
    pages = get_all ( Page , file = file )
    for page in pages :
        delete_log ( 'Page' , page.id )
        page.delete ( )

    # Create new chunks
    successfull = True
    log = get_one_with_params ( Log , id = parent_log_id )

    try :
        spliter = GenericSpliter ( file , log )
        successfull = spliter.analyze ( )

        if not successfull :
            delete_temp_data ( file )
            # delete
            print ( f'An Error occurs during the spliting of {file.path}' )
            file.is_analyzed = False
        else :
            file.is_analyzed = True
            file.nb_pages = len ( get_all ( Page , file = file ) )
            file.last_analyzed_date = datetime.now ( tz = get_current_timezone ( ) )
    except :
        file.is_analyzed = False
        logs = get_all ( Log , parent_log_id = parent_log_id )

        for log in logs :
            if log.object_type == 'Chunk' :
                page = get_one_with_params ( Page , id = log.object_id )
                if page :
                    page.delete ( )
    finally :
        file.save ( )


def split_files ( folder_id , files_to_split_ids , parent_log_id ) :
    """
    Split a list of files
    :param folder_id:
    :param files_to_split_ids:
    :param parent_log_id:
    :return:
    """
    log = get_one_with_params ( Log , id = parent_log_id )
    folder = get_one_with_params ( Folder , id = folder_id )
    files_id = [file.id for file in get_children_files ( folder , processable = True )]
    jobs = []
    nb_files = len ( files_to_split_ids )
    for file_id in files_id :
        if file_id not in files_to_split_ids :
            continue

        file_chunking = split_single_file.delay ( file_id , parent_log_id )
        job = Job.objects.create (
            process_id = file_chunking.id ,
            log = log ,
            weigth = CHUNKING_WEIGTH / nb_files
        )
        jobs.append ( job )

    # Cas where there is no indexing Job
    if not jobs :
        empty_task_process = empty_task.delay ( )
        jobs.append ( Job.objects.create (
            process_id = empty_task_process.id ,
            log = log ,
            weigth = CHUNKING_WEIGTH
        ) )

    return jobs


@shared_task
def empty_task () :
    time.sleep ( 5 )
