from datetime import datetime

import requests
from background.tasks.celery_helper import jobs_finished
from background.tasks.file_splitting import split_files
from background.tasks.indexing import index_folder
from background.utils.folder_utils import get_files_to_split_ids
from celery import shared_task
from django.utils.timezone import get_current_timezone
from noyau.models import Folder , File
from noyau.repositories.db import get_one_with_params , update_by_batch , get_all
from noyau.repositories.folder_helper import get_children_files , get_children_folder , count_folder_files_and_pages , \
    count_folder_sub_folders
from izysearch.settings import QUERYING_SERVER


@shared_task
def split_and_index(folder_id, parent_log_id):
    folder = get_one_with_params(Folder, id=folder_id)

    # Splitting documents
    files_to_split_ids = get_files_to_split_ids(folder)

    print(f'Number of files to process : {len(files_to_split_ids)}')
    spliting_jobs = split_files(folder_id, files_to_split_ids, parent_log_id)

    # Wait splitting to finish
    while not jobs_finished(spliting_jobs):
        pass

    # indexing Files and page chunks
    indexation_jobs = index_folder(folder_id, parent_log_id)
    # Wait splitting to finish
    while not jobs_finished(indexation_jobs):
        pass

    # Update the last splitting date
    folder.is_analyzed = True
    folder.is_indexed = True
    folder.last_spliting_date = datetime.now(tz=get_current_timezone())
    folder.last_index_date = datetime.now(tz=get_current_timezone())
    folder.nb_files, folder.nb_pages = count_folder_files_and_pages(folder)
    folder.nb_folders = count_folder_sub_folders(folder)
    children_f = get_children_files(folder, processable=True)
    folder.size = sum(file_.size for file_ in children_f)
    folder.save()

    # Update files Status
    processed_files = get_all(File, id__in=files_to_split_ids)
    for f in processed_files:
        if f.is_analyzed:
            f.is_indexed = True
            f.last_analyzed_date = datetime.now(tz=get_current_timezone())
            f.last_index_date = datetime.now(tz=get_current_timezone())

    update_by_batch(processed_files, 100)

    sub_folders = get_children_folder (folder)
    for sub_folder in sub_folders:
        sub_folder.is_analyzed = True
        sub_folder.is_indexed = True
        sub_folder.last_spliting_date = datetime.now(tz=get_current_timezone())
        sub_folder.last_indexing_date = datetime.now(tz=get_current_timezone())
        sub_folder.nb_files, sub_folder.nb_pages = count_folder_files_and_pages(sub_folder)
        sub_folder.nb_folders = count_folder_sub_folders(sub_folder)
        children = get_children_files(sub_folder, processable=True)
        folder.size = sum(file_.size for file_ in children)

    update_by_batch(sub_folders, 100)

    index_updater = QUERYING_SERVER + 'update/memory'

    folder.indexing = False
    folder.save()

    # Update indices
    res = requests.post(index_updater,
                        json = {'organisation': str(folder.organisation.uuid)},
                        verify=False)
