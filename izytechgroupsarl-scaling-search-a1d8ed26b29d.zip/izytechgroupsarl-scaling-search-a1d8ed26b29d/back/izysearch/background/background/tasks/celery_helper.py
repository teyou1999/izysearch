from celery.result import AsyncResult


def job_is_finished ( job ) :
    """
    Check if a job is finished or not.
    A job is finished if and only if its status is FAILURE or SUCCESS. \
    :param job:
    :return:
    """
    res = AsyncResult ( job.process_id )
    if res.status in ['FAILURE' , 'SUCCESS'] :
        return True

    return False


def jobs_finished ( jobs ) :
    """
    Check if a set of jobs is finished or not. <br/>
    :param jobs:
    :return:
    """

    total = len ( jobs )
    completed = 0
    for job in jobs :
        res = AsyncResult ( job.process_id )
        if res.status in ['FAILURE' , 'SUCCESS'] :
            completed += 1
    return total == completed
