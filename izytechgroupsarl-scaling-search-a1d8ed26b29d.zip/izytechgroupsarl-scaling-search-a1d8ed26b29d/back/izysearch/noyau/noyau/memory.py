class Memory:
    """
    Here we create a Singleton class for storing the indexes. <br/>
    """
    __instance = None
    indexes = {}
    folders = []
    is_celery = False
    text_processor = None
    es_client = None
    es_chunk_client = None

    @staticmethod
    def getInstance():
        """
        Get the permanent state of the memory. <br/>
        :return:
        """
        if Memory.__instance == None:
            Memory()
        return Memory.__instance


    def __init__(self):
        """
        Virtual private Constructor
        """
        if Memory.__instance != None:
            raise Exception("This class is a singleton !")
        else:
            Memory.__instance = self
