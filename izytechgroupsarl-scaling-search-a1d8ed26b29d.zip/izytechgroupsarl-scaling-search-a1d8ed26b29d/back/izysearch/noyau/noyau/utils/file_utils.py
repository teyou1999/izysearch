import os
from izysearch.settings import FILE_MAX_SIZE, FILE_MIN_SIZE
from noyau.utils.folder_utils import escaped_file_or_folder_name


def get_extension(path):
    """
    Get the extension of a file base on its gloabal path
    :param path:
    :return:
    """
    return os.path.splitext(path)[1] if len(os.path.splitext(path)) > 1 else ''


def get_extension(path):
    """
    Get the extension of a file base on its gloabal path
    :param path:
    :return:
    """
    ext = os.path.splitext(path)[1] if len(os.path.splitext(path)) > 1 else ''
    return escaped_file_or_folder_name(ext).lower()


def get_name_from_path(path):
    """
    Get the base name of a File
    :param path:
    :return:
    """
    return os.path.basename(path)


def exceededFileSize(file):
    """
    Check if a file size is greather than the required oe
    :param file:
    :return:
    """
    size = file.size
    if size > FILE_MAX_SIZE * 1024 * 1024:
        return False

    return True


def smallFileSize(file):
    """
    Check if a file size is lest than a threshold
    :param file:
    :return:
    """
    size = file.size
    if size < FILE_MIN_SIZE * 1024:
        return False

    return True
