import os
import shutil
import unidecode
from izysearch.settings import ESCAPED_CHARS
from noyau.repositories.db import get_one_with_params


def create_directory(path):
    if not os.path.exists(path):
        os.mkdir(path)

def delete_folder(path, folder):
    to_delete = get_one_with_params(folder, path=path)
    if (to_delete.path):
        if (os.path.isdir(to_delete.path)):
            shutil.rmtree(to_delete.path)

def escaped_file_or_folder_name(name):
    """
    Replace all the escaped characters by and underscore
    :param name:
    :return:
    """
    name = unidecode.unidecode(name)
    for char in ESCAPED_CHARS:
        name = name.replace(char, '_')
    name = name.replace(' ', '_').replace('\t', '_')

    intab = "éëêèçàçùöôûüïîäâ,;:()^$=# -' &"
    outtab = "eeeecacuoouuiiaa_____________e"
    trantab = str.maketrans ( intab , outtab )
    name = name.translate ( trantab )

    return name

def valid_file_or_folder(name):
    """
    Test if a file or folder name is valid
    :param name:
    :return:
    """
    # If the file name contains caracter to avoid
    for char in ESCAPED_CHARS:
        if char.lower() in name.lower():
            return False
    return True
