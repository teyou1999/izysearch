import os, shutil
from noyau.utils.folder_utils import escaped_file_or_folder_name
from noyau.repositories.db import get_one_with_params
from noyau.models import Folder
from izysearch.settings import MEDIA_ROOT


def create_root_dir(org):
    """
    Creation of the default Folder for an organisation
    :param org:
    :return:
    """
    name = str(escaped_file_or_folder_name(org.name))
    path = MEDIA_ROOT + name

    if not os.path.exists(path):
        os.mkdir(path)
    else:
        # Delete this folder in the database
        existing_folder = get_one_with_params(Folder, path=path)

        if existing_folder:
            existing_folder.delete()

        shutil.rmtree(path)
        os.mkdir(path)

    folder = Folder.objects.create(
        name = name,
        path = path,
        organisation = org
    )

    return str(folder.uuid)


def get_organisation_root_folder(org):
    """
    Get An organisation Root Folder
    :param org:
    :return:
    """
    return  get_one_with_params(Folder, uuid=org.root_folder)
