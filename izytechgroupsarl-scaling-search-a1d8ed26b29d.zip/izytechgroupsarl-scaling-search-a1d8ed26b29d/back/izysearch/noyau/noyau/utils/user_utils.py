from re import sub
from noyau.models import User , Organisation


def get_connected_user ( header ) :
    """
    Get the connected User Account
    :param token:
    :return:
    """
    try :
        token = sub ( 'Token ' , '' , header )
        user = User.objects.get ( api_token = token )
        return user
    except :
        return None


def get_connected_user_organisation ( token ) :
    """
    Get the organisation of a user based on its token. <br/>
    :param token:
    :return:
    """
    account = get_connected_user ( token )
    org = None
    if account :
        org = Organisation.objects.get ( uuid = account.org )
    return org
