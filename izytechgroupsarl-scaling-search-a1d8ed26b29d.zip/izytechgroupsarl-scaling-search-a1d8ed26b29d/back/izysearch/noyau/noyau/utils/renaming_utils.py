import os
import glob
import string

def get_file_correct_name(namefile, folder=True):
    """
    Build the correct name of a file using several rules. <br/>
    :param namefile:
    :param folder:
    :return:
    """
    file_name = namefile.split ( "/" )[-1]
    intab = "éëêèçàçùöôûüïîäâ,;:()^$=# -' &"
    outtab = "eeeecacuoouuiiaa_____________e"
    trantab = str.maketrans ( intab , outtab )
    file_name = file_name.translate ( trantab )
    printable = set ( string.printable )
    if folder is not True :
        file_ext = os.path.splitext ( file_name )[1].replace ( "." , "" )
        file_name = "".join ( filter ( lambda x : x in printable , file_name.split ( file_ext )[0] ) ).strip ( )
    else :
        file_name = "".join ( filter ( lambda x : x in printable , file_name ) ).strip ( )

    if folder is not True :
        newName = "/".join ( namefile.split ( "/" )[:-1] ) + "/" + file_name + "" + file_ext
    else :
        newName = "/".join ( namefile.split ( "/" )[:-1] ) + "/" + file_name
    return newName.replace(' ', '_')


def rename_item ( namefile , folder=True, updated_names = {}, all_names = {}) :
    """
    Rename an OS item base on Linux compliances. <br/>
    If this item is a folder, folder param is set to true.
    :param namefile:
    :param folder:
    :param updated_names:
    :return:
    """
    newName = get_file_correct_name(namefile, folder)

    try:
        os.rename ( namefile , newName )

        all_names[namefile] = newName

        if namefile in updated_names:
            updated_names[namefile] = newName
    except Exception:
        return updated_names, all_names

    return updated_names, all_names



def rename_folder ( folder_path , updated_names = {}, all_names={}) :
    """
    Rename a folder and all its contained files and folders. <br/>
    :param folder_path:
    :param updated_names: the dictionary to map update name before and after the renaming
    :param all_names: The dictionary to map a filename in the folder an its new name
    :return:
    """
    try:
        folders = [a[0] for a in os.walk ( folder_path )]
        folders.reverse ( )
        for f in folders :
            updated_names, all_names = rename_item ( f, updated_names=updated_names, all_names = all_names)

        # If the folder name has been renamed
        if folder_path in all_names:
            folder_path = all_names[folder_path]

        files = glob.glob ( folder_path + '/**/*.*' , recursive = True )
        newFiles = []
        for i , f in enumerate ( files ):
            if f.split ( "/" )[-1][:2] == "~$" :
                os.remove ( f )
            else :
                newFiles.append ( f )
            for f in newFiles :
                updated_names, all_names = rename_item ( f , False , updated_names=updated_names, all_names = all_names)

        return updated_names, all_names
    except Exception:
        print('An error occurs during the folder renaming ...')
        return updated_names, all_names


