import os, shutil
from stat import * # ST_SIZE etc
import unidecode
import zipfile
from noyau.models import File, Folder, Log
from izysearch.settings import CUSTOM, ESCAPED_CHARS
from django.core.files import File as FileObj
from datetime import datetime
from app.serializers.file_serializer import FileSerializer
from app.serializers.folder_serializer import FolderSerializer
from noyau.repositories.db import get_one_with_params
from noyau.repositories.file_helper import get_basename
from noyau.utils.folder_utils import escaped_file_or_folder_name
from noyau.utils.renaming_utils import get_file_correct_name , rename_folder
from noyau.repositories.folder_helper import count_folder_files , get_children_folder , get_children_files , \
    count_folder_sub_folders


def get_all(dir_path):
    """
    Get all the files and directories for an other directory given its path. <br/>
    :param dir_path:
    :return:
    """
    files = []
    dirs = []
    for root, _dirs, _files in os.walk(dir_path):
        files = _files
        dirs = _dirs
        break
    return (files, dirs)


def list_all(dir_path):
    files_arr = []
    dirs_arr = []
    for root, dirs, files in os.walk(dir_path):
       for name in files:
          files_arr.append(os.path.join(root, name))
       for name in dirs:
          dirs_arr.append(os.path.join(root, name))
    return (files_arr, dirs_arr)


def populate_physical_file(path, folder_object, parent_log, updated_files, all_names):
    """
    Add a single physical file in a folder Object. <br/>
    This operation is performed during the physical folder population. <br/>
    :param path:
    :param folder_object:
    :param parent_log:
    :return:
    """
    existing_file = get_one_with_params(File, path=path)

    if existing_file:
        if path in updated_files:
            existing_file.created_at = datetime.now()
            existing_file.updated_at = datetime.now()
            existing_file.save()
    else:
        populate_single_file(path, folder_object, parent_log, all_names)


def populate_file_from_zip(file, folder_object, parent_log,  all_names):
    """
    Populate File comming from a Zip
    :param file:
    :param folder_object:
    :param parent_log:
    :return:
    """
    path = folder_object.path + "/" + escaped_file_or_folder_name(file)
    populate_single_file(path, folder_object, parent_log, all_names)


def _get_logical_name(new_name, all_names):
    """
    Get the logical name of a file
    :param new_name:
    :param all_names:
    :return:
    """
    for name in all_names:
        if all_names[name] == new_name:
            return get_basename(name)
    return None


def populate_single_file(path, folder_object, parent_log, all_names):
    """
    Populate a single file. <br/>
    all_names variable is used to mape logical_name with the one store in the database.
    :param path:
    :param folder_object:
    :param parent_log:
    :param all_names:
    :return:
    """
    # Make sure that the base name is unique
    full_base_name = escaped_file_or_folder_name(os.path.basename(str(path)))
    basename = full_base_name.split('.')[0]
    extension = full_base_name.split('.')[1]

    similar_filenames = File.objects.filter(name__icontains=basename+'.', folder=folder_object)

    if similar_filenames:
        old_path = path
        new_basename = f'{basename}_{len(similar_filenames)}.{extension}'
        path = os.path.join(os.path.dirname(str(path)), new_basename)
        shutil.move(old_path, path)

    if not os.path.exists(path):
        return 

    f = open(path)
    to_test = FileObj(f)
    f.close()
    serializer = FileSerializer(data={
                                    'path': to_test,
                                    'folder': folder_object.uuid
                                },
                                partial=True)

    if (serializer.is_valid()):
        file_object = File(path=path, folder=folder_object, logical_name=_get_logical_name(path, all_names))
        file_object.save()
        # Log this folder creation
        Log.objects.create(
                name = 'Zip File Decompression File Creation',
                description = 'Creation of a file in a Zip decompression',
                account = parent_log.account,
                success = True,
                object_type = 'File',
                object_id = file_object.id,
                parent = parent_log
            )
    else:
        os.remove(path)

def populate_database_physically(files_path, parent, organisation, parent_log, updated_files, all_names={}):
    """
    For Physical Upload
    :param files_path:
    :param parent:
    :param organisation:
    :param parent_log:
    :return:
    """
    # try:
    files, dirs = get_all(files_path)
    # Create the Folder Object For The zip Folder
    if parent != None:
        folder_obj = {
            'name': os.path.basename(files_path),
            'path': files_path,
            'organisation': organisation.id,
            'parent': parent.uuid
        }
    else:
        folder_obj = {
            'name': os.path.basename(files_path),
            'path': files_path,
            'organisation': organisation.id
        }
    folder_serializer = FolderSerializer(data=folder_obj, partial=True)

    renamed_path = get_file_correct_name(files_path, folder=True)
    existing_folder = get_one_with_params(Folder, path=renamed_path)


    if existing_folder:
        for directory in dirs:
            populate_database_physically(os.path.join(files_path, directory),
                            existing_folder, organisation, parent_log, updated_files, all_names)
        for file in files:
            path = os.path.join(files_path, file)
            populate_physical_file(path, existing_folder, parent_log, updated_files, all_names)

    elif not existing_folder and folder_serializer.is_valid() :
        folder_object = Folder(name=os.path.basename(files_path),
                            organisation=organisation,
                            path=files_path,
                            parent=parent)
        folder_object.save()

        for directory in dirs:
            populate_database_physically(os.path.join(files_path, directory),
                            folder_object, organisation, parent_log, updated_files, all_names)
        for file in files:
            path = os.path.join(files_path, file)
            populate_physical_file(path, folder_object, parent_log, updated_files, all_names)

    else:
        print('Another serialization problem ...')
        False
    return True


def populate_database(files_path, parent, organisation, parent_log, all_names):
    """
    For Zip Upload
    :param files_path:
    :param parent:
    :param organisation:
    :param parent_log:
    :return:
    """

    try:
        files, dirs = get_all(files_path)
        # Create the Folder Object For The zip Folder
        if parent:
            folder_obj = {
                'name': os.path.basename(files_path),
                'path': files_path,
                'organisation': organisation.id,
                'parent': parent.uuid
            }
        else:
            folder_obj = {
                'name': os.path.basename(files_path),
                'path': files_path,
                'organisation': organisation
            }
        folder_serializer = FolderSerializer(data=folder_obj, partial=True)
        if (folder_serializer.is_valid()):
            folder_object = Folder(name=os.path.basename(files_path),
                                organisation=organisation,
                                parent=parent)
            folder_object.save()

            # Log this folder creation
            Log.objects.create(
                    name = 'Zip File - Decompress Folder Creation',
                    description = 'Creation of a Folder in a Zip decompression',
                    account = parent_log.account,
                    success = True,
                    object_type = 'Folder',
                    object_id = folder_object.id,
                    parent = parent_log
                )

            for directory in dirs:
                populate_database(folder_object.path
                                + '/' + escaped_file_or_folder_name(directory),
                                folder_object, organisation, parent_log, all_names)
            for file in files:
                populate_file_from_zip(file, folder_object, parent_log, all_names)

        return True

    except Exception:
        print('The Zip Upload failed')
        # Get all the Logs created with this operation as parent
        logs = Log.objects.filter(parent=parent_log.id)
        for log in logs:
            if log.object_type == 'File':
                file = get_one_with_params(Folder, id=log.object_id)
                file.delete()

            if log.object_type == 'Folder':
                folder = get_one_with_params(Folder, id=log.object_id)
                if folder:
                    folder.delete()
            log.delete()

        # Delete the parent
        parent_log.delete()

        # Return Error
        return False


def escape_fullpath_name(name):
    """
    Replace all the escaped characters by and underscore
    :param name:
    :return:
    """
    name = unidecode.unidecode(name)
    for char in ESCAPED_CHARS:
        if char == '/':
            continue
        name = name.replace(char, '_')
    name = name.replace(' ', '_').replace('\t', '_')

    return name

def rename_files(files_path):
    # Get All folders and rename
    files, folders = list_all(files_path)
    for folder in folders + files:
        old_name = escape_fullpath_name(
                    os.path.abspath(os.path.join(folder, os.pardir)))
        new_name = escape_fullpath_name(folder)
        os.rename(old_name + '/' + os.path.basename(folder), new_name)


def _get_copy_version(existing_copies, copy_path):
    """
    Given a list of folder built based on a copy of another one,
    we want to get the lastest version. <br/>
    :param existing_copies:
    :param copy_path: Regex representing the copy base path.
    :return:
    """
    versions = []
    for copy in existing_copies:
        copy_parts = copy.path.split(copy_path)
        if len(copy_parts) > 1:
            extension = copy_parts[-1].split('/')[0]
            versions.append(int(extension))

    return max(versions)


def unzip(path):
    """
    Unzip a file referenced by its path. <br/>
    If a folder has already been created with this same name, we just create a copy. <br/>
    :param path:
    :return:
    """
    zip_ob = zipfile.ZipFile(path)
    files_path = os.path.splitext(path)[0]

    existing_folder = get_one_with_params(Folder, path=files_path)
    if existing_folder:
        copy_path = existing_folder.path + '_copy_'
        existing_copies = Folder.objects.filter(path__contains=copy_path)
        if existing_copies:
            last_copy = _get_copy_version(existing_copies, copy_path)
        else:
            last_copy = 0

        files_path = f"{files_path}_copy_{int(last_copy) + 1}"

    zip_ob.extractall(files_path)
    zip_ob.close()
    return files_path



def upload(model, parent_log):
    path = (str(model['folder']) + '/'
            + escaped_file_or_folder_name(str(model['path'])))
    organisation = model['folder'].organisation
    files_path = unzip(path)

    # Rename all the Folders and Files it contains
    updated_names, all_names = rename_folder(files_path, all_names={})
    succes = populate_database(files_path, model['folder'], organisation, parent_log, all_names)
    return succes


def mv_contain(origin_folder, destination):
    """
    Move all the contain of a directory in another one. <br/>
    :param origin_folder:
    :param destination:
    :return:
    """
    files, dirs = list_all(origin_folder)
    all_ = files
    for d in dirs:
        all_.append(d)
    for el in all_:
        shutil.move(el, destination)


def populate_folder(new_path, folder_path, parent, parent_log):
    """
    Populate the database with files of a folder located in another directory
    :param folder: folder Object created
    :param folder_path: path of the input folder
    :param parent_log: parent Log
    :return:
    """
    # Move folder form its original path to the new one.
    updated_files, all_files, deleted_dirs = mv_folder(folder_path, new_path)

    updated_names = {}
    all_names = {}
    deleted_dir_names = {}

    # Updated names for renaming
    for name in updated_files:
        updated_names[name] = name

    # All files for renaming
    for name in all_files:
        all_names[name] = name

    # Delete dirs
    for name in deleted_dirs:
        deleted_dir_names[name] = name

    # Rename all the Folders and Files it contains
    updated_names, all_names = rename_folder(new_path,  updated_names, all_names)

    # Get the updated files rename
    updated_files = [updated_names[key] for key in updated_names]
    all_files = [all_names[key] for key in all_names]
    deleted_dirs = [deleted_dir_names[key] for key in deleted_dir_names]

    # Populate files in the database
    succes = populate_database_physically(new_path, parent, parent.organisation, parent_log, updated_files, all_names)


    # Update all folder information
    if succes:
        folder = get_one_with_params(Folder, path=new_path)
        folder.nb_files = count_folder_files(folder, processable = True)
        children = get_children_files(folder, processable=True)
        folder.size = sum(file_.size for file_ in children)
        folder.save()

        children_folders = get_children_folder(folder)
        for child_folder in children_folders:
            child_folder.nb_files = count_folder_files(child_folder, processable = True)
            child_folder.nb_folders = count_folder_sub_folders(child_folder)
            children = get_children_files(child_folder, processable=True)
            child_folder.size = sum(file_.size for file_ in children)
            child_folder.save()

    # Delete all the files that has been remove for CA
    if CUSTOM:
        folder = get_one_with_params(Folder, path=new_path)
        if not folder:
            return succes
        all_existing_files = [str(file_.path) for file_ in get_children_files(folder, processable=False)]
        deleted_files = list(set(all_existing_files) - set(all_files))

        if deleted_files:
            # files_to_delete = get_all(File, path__in=deleted_files)
            files_to_delete = File.objects.filter(path__in=deleted_files)

            if files_to_delete:
                files_to_delete.delete()

        if deleted_dirs:
            # dir_to_delete = get_all(Folder, path__in=deleted_dirs)
            dir_to_delete = Folder.objects.filter(path__in=deleted_dirs)
            if dir_to_delete:
                dir_to_delete.delete()
    return succes


def get_info(file):
    """
    Get the last modification date of a file
    :param file:
    :return:
    """
    try:
        st = os.stat(file)
    except IOError:
        print("failed to get information about", file)
        return None
    else:
        return st[ST_MTIME]


def mv_folder(path, moveto):
    """
    Move information from a dir to another. <br/>
    If a file or a folder in the source is new it will be created
    Otherwise, we check the last updated date before moving. <br/>
    We return the list of all the updated files. <br/>
    :param path:
    :param moveto:
    :return:
    """
    updated_files = []
    all_files = []
    deleted_dirs = []
    src_folders = [a[0] for a in os.walk(path)]

    # Create not existing folders
    for folder in src_folders:
        folder = os.path.relpath(folder, start=path)
        folder = '' if folder == '.' else folder
        dst = os.path.join(moveto, folder)
        if not os.path.exists(dst):
            os.mkdir(dst)

    # Reverse for creating the files
    src_folders.reverse()

    for folder in src_folders:
        # Remove the root
        folder = os.path.relpath(folder, start=path)
        folder = '' if folder == '.' else folder
        src = os.path.join(path, folder)
        dst = os.path.join(moveto, folder)

        # Move all the files
        new_updated_files, new_all_files, new_deleted_dirs = process_folder_files(src, dst)
        updated_files = updated_files + new_updated_files
        all_files = all_files + new_all_files
        deleted_dirs = deleted_dirs + new_deleted_dirs

    # Remove empty folder
    folder_to_rm = [a[0] for a in os.walk(path)]
    folder_to_rm.reverse()
    for f in folder_to_rm:
        shutil.rmtree(f)

    return updated_files, all_files, deleted_dirs


def _get_relative_path(folder, file, is_folder=True):
    """
    Get the relative path of a file
    :param folder:
    :param file:
    :return:
    """
    new_name = get_file_correct_name(os.path.join(folder, file), is_folder)
    new_folder = get_file_correct_name(folder)
    folder = os.path.relpath(new_name, start=new_folder)
    folder = '' if folder == '.' else folder
    return folder


def process_folder_files(src_folder, dst_folder):
    """
    Move files of a folder to another one. <br/>
    :param src_folder:
    :param dst_folder:
    :return: All the updated files, all the files in this directory and all the deleted dirs.
    """
    updated_files = []
    all_files = []
    # src_folder and destination in absolute path
    files = [f for f in os.listdir(src_folder) if os.path.isfile(os.path.join(src_folder, f))]

    new_dst_files = [_get_relative_path(src_folder, f, False) for f in os.listdir(src_folder) if os.path.isfile(os.path.join(src_folder, f))]
    old_dst_files = [_get_relative_path(dst_folder, f, False) for f in os.listdir(dst_folder) if os.path.isfile(os.path.join(dst_folder, f))]

    new_dst_dirs = [_get_relative_path(src_folder, f, True) for f in os.listdir(src_folder) if not os.path.isfile(os.path.join(src_folder, f))]
    old_dst_dirs = [_get_relative_path(dst_folder, f, True) for f in os.listdir(dst_folder) if not os.path.isfile(os.path.join(dst_folder, f))]


    deleted_files = list(set(old_dst_files) - set(new_dst_files))
    # Rebuild deleted files and deleted dirs
    deleted_files = [os.path.join(dst_folder, file_) for file_ in deleted_files]
    delete_dirs = list(set(old_dst_dirs) - set(new_dst_dirs))
    delete_dirs = [os.path.join(dst_folder, file_) for file_ in delete_dirs]

    for file in files:
        src = os.path.join(src_folder, file)
        dst = os.path.join(dst_folder, file)
        src_date = get_info(src)
        if not os.path.exists(dst):
            shutil.move(src,dst)
        else:
            # if exists in dst and not in source, delete
            dst_date = get_info(dst)
            if src_date and dst_date and src_date > dst_date:
                shutil.move(src,dst)
                updated_files.append(dst)

        all_files.append(dst)

    # delete the deleted files, if we ar on speacil Genius
    # Delete all the files that has been remove for CA
    if CUSTOM:
        for file_ in deleted_files:
            os.remove(file_)

    return updated_files, all_files, delete_dirs
