from django.db import models
from noyau.models import User
import uuid as uuid


class Log ( models.Model ) :
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    name = models.CharField ( max_length = 255 , null = False )
    description = models.TextField ( null = True , default = None )
    success = models.BooleanField ( default = False )
    created_at = models.DateTimeField ( auto_now_add = True )
    updated_at = models.DateTimeField ( auto_now = True )
    account = models.ForeignKey ( User , on_delete = models.CASCADE , null = True )
    object_type = models.CharField ( max_length = 255 , null = True )
    object_id = models.IntegerField ( null = True , default = None )
    nb_tasks = models.IntegerField ( default = 0 )
    parent = models.ForeignKey ( 'self' , on_delete = models.CASCADE , to_field = 'uuid' , null = True )

    def __str__ ( self ) :
        return "{}".format ( self.name )
