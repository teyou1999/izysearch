from django.db import models
from django.contrib.auth.models import AbstractUser
from .role import Role
import uuid as uuid


class User(AbstractUser):
    role = models.ForeignKey(Role, on_delete=models.CASCADE, null=True, to_field='uuid')
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    api_token = models.CharField(max_length=255, null=True, default=None, unique=True)
    org = models.CharField(max_length=255, default=None)
    email = models.EmailField(max_length=255, unique=True)
    debug = models.BooleanField(default=False)
