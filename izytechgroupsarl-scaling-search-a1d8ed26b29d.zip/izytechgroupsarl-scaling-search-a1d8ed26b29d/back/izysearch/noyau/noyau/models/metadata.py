import uuid as uuid
from django.db import models
from noyau.models import File, Organisation


class MetadataType(models.Model):
    """
    Type of a metadata
    """
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255, unique=True)
    type = models.IntegerField (default=0, null = False)
    description = models.TextField(null=True, default = None)
    created_at = models.DateTimeField(auto_now_add=True, null = True)
    updated_at = models.DateTimeField(auto_now=True, null = True)


class Metadata(models.Model):
    """
    Metadata for an organisation
    """
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    type = models.ForeignKey(MetadataType, on_delete=models.CASCADE, null=False, to_field='uuid')
    organisation = models.ForeignKey(Organisation, on_delete=models.CASCADE, null=False, to_field='uuid')
    name = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True, null = True)
    updated_at = models.DateTimeField(auto_now=True, null = True)


class MetadataValue(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    metadata = models.ForeignKey(Metadata, on_delete=models.CASCADE, null=False, to_field='uuid')
    value = models.CharField(max_length=255)
    min_value = models.FloatField(null= True, default=-999999999999999)
    max_value = models.FloatField(null= True, default=999999999999999)
    min_date = models.DateField(auto_now = False, auto_now_add = False, null = True, default = None)
    max_date = models.DateField(auto_now = False, auto_now_add = False, null = True, default = None)
    source = models.CharField(max_length = 255, default = 'Izysearch')
    file = models.ForeignKey(File, on_delete=models.CASCADE, null=True, to_field='uuid')
