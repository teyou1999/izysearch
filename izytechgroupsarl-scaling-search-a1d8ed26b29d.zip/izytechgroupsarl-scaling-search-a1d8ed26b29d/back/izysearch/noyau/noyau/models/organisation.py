import uuid as uuid
from django.core.validators import validate_email
from django.db import models
from noyau.models.constants import STATUS_CHOICES


class Organisation(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255, unique=True)
    address = models.CharField(max_length=255, null=True, default = None)
    root_folder = models.CharField(max_length = 255, null=True, default = None)
    email = models.CharField(max_length=255, null=True, validators = [validate_email], default = None)
    description = models.TextField(null=True, default = None)
    status = models.CharField(max_length=255, choices=STATUS_CHOICES, default='Pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

