from django.db import models
from noyau.models import User , Organisation , Folder
import uuid as uuid

class Query(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, to_field='uuid')
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    organisation = models.ForeignKey(Organisation, on_delete=models.CASCADE, null=True, blank=True, to_field='uuid')
    folder = models.ForeignKey(Folder, on_delete=models.CASCADE, null=True, blank=True, to_field='uuid')
    date = models.DateTimeField(auto_now_add=True)
    query = models.TextField(null=True)
    message = models.CharField(max_length=255, null=True)
    type = models.CharField(max_length=255, null=True)
    filters = models.TextField(null=True)
    results = models.TextField(null=True)
    success = models.BooleanField(default=False)
    debug = models.BooleanField(default=False)
