import os
import uuid as uuid
from django.db import models
from django.db.models.signals import pre_delete
from django.dispatch.dispatcher import receiver
from noyau.models import Organisation , Folder , File
from noyau.models.constants import TOKEN_TYPES
from noyau.utils.folder_utils import delete_folder


class ConnectorType ( models.Model ) :
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    name = models.CharField ( max_length = 255 , unique = True )
    description = models.TextField ( null = True , default = None )
    active = models.BooleanField ( default = False )
    created_at = models.DateTimeField ( auto_now_add = True , null = True )
    updated_at = models.DateTimeField ( auto_now = True , null = True )


class TempConnector ( models.Model ) :
    """
    Temp connector When 2 Fact Authentication is required
    """
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    type = models.ForeignKey ( ConnectorType , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    organisation = models.ForeignKey ( Organisation , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    state = models.CharField ( max_length = 255 , null = False , unique = True )
    auth_url = models.TextField ( null = True , default = None )
    credential_file = models.TextField ( null = True , default = None )


class Connector ( models.Model ) :
    """
    A Connector Model for mapping objects from an outside platform
    """
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    type = models.ForeignKey ( ConnectorType , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    organisation = models.ForeignKey ( Organisation , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    root_folder = models.ForeignKey ( Folder , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    url = models.TextField ( max_length = 255 , null = True )
    signin_url = models.CharField ( max_length = 255 , null = True )
    signout_url = models.CharField ( max_length = 255 , null = True )
    api_url = models.CharField ( max_length = 255 , null = True )
    login = models.CharField ( max_length = 255 , null = True )
    password = models.CharField ( max_length = 255 , null = True )
    client_id = models.CharField ( max_length = 255 , null = True )
    secret = models.CharField ( max_length = 255 , null = True )
    token_type = models.CharField ( max_length = 255 , choices = TOKEN_TYPES , default = 'Bearer' )
    token = models.CharField ( max_length = 255 , null = True )
    access_token = models.CharField ( max_length = 255 , null = True )
    refresh_token = models.CharField ( max_length = 255 , null = True )
    authentication_token = models.CharField ( max_length = 255 , null = True )
    expire_in = models.IntegerField ( default = 0 , null = True )
    scope = models.CharField ( max_length = 255 , null = True )
    credential_file = models.CharField ( max_length = 255 , null = True )
    credentials = models.BinaryField ( )
    last_auth = models.DateTimeField ( null = True )
    last_synchro = models.DateTimeField ( null = True )
    created_at = models.DateTimeField ( auto_now_add = True , null = True )
    updated_at = models.DateTimeField ( auto_now = True , null = True )


@receiver ( pre_delete , sender = Connector )
def submission_delete ( sender , instance , **kwargs ) :
    if instance.root_folder and instance.root_folder.path :
        delete_folder ( instance.root_folder.path , Folder )

    if os.path.exists ( str ( instance.credential_file ) ) :
        os.remove ( str ( instance.credential_file ) )


class ConnectorFolder ( models.Model ) :
    """
    Create a link Between Connector and folder on the file System
    """
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    connector = models.ForeignKey ( Connector , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    folder = models.ForeignKey ( Folder , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    id_resource = models.CharField ( max_length = 255 , null = False )
    md5checksum = models.CharField ( max_length = 255 , null = True )
    uri = models.TextField ( null = True , default = None )
    last_auth = models.DateTimeField ( null = True )
    last_synchro = models.DateTimeField ( null = True )
    created_time = models.DateTimeField ( null = True )
    update_time = models.DateTimeField ( null = True )
    created_at = models.DateTimeField ( auto_now_add = True , null = True )
    updated_at = models.DateTimeField ( auto_now = True , null = True )


class ConnectorFile ( models.Model ) :
    """
    Create a link Between Connector and file on the file System
    """
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    connector = models.ForeignKey ( Connector , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    file = models.ForeignKey ( File , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    id_resource = models.CharField ( max_length = 255 , null = False )
    uri = models.TextField ( null = True , default = None )
    last_auth = models.DateTimeField ( null = True )
    md5checksum = models.CharField ( max_length = 255 , null = True )
    last_synchro = models.DateTimeField ( null = True )
    created_time = models.DateTimeField ( null = True )
    update_time = models.DateTimeField ( null = True )
    created_at = models.DateTimeField ( auto_now_add = True , null = True )
    updated_at = models.DateTimeField ( auto_now = True , null = True )
