import os
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch.dispatcher import receiver
import uuid as uuid


class Image(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    path = models.CharField(max_length = 255, null = False, unique = True)
    page_num = models.IntegerField(null = True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


@receiver(post_delete, sender=Image)
def submission_delete(sender, instance, **kwargs):
    if os.path.isfile(str(instance.path)):
        os.remove(str(instance.path))
