import os
import uuid as uuid
from django.db import models
from django.dispatch import receiver
from django.db.models.signals import post_delete
from django.core.files.storage import FileSystemStorage
from noyau.repositories.file_helper import compute_file_size
from noyau.utils.folder_utils import escaped_file_or_folder_name
from .organisation import Organisation
from .folder import Folder
from noyau.utils.file_utils import get_extension

fs = FileSystemStorage ( )


def save ( self , instance ) :
    return self.folder.path + '/' + escaped_file_or_folder_name ( str ( self.path ) )


class File ( models.Model ) :
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    name = models.CharField ( max_length = 255 , null = True )
    temp_pdf = models.CharField ( max_length = 255 , null = True , default = None )
    temp_html = models.CharField ( max_length = 255 , null = True , default = None )
    display_name = models.CharField ( max_length = 255 , null = True , default = None )
    logical_name = models.CharField ( max_length = 255 , null = True , default = None )
    creator_name = models.CharField ( max_length = 255 , null = True , default = None )
    updater_name = models.CharField ( max_length = 255 , null = True , default = None )
    owner_name = models.CharField ( max_length = 255 , null = True , default = None )
    path = models.FileField ( storage = fs , upload_to = save , unique = True , max_length = 255 )
    extension = models.CharField ( max_length = 255 , null = True , default = None )
    created_at = models.DateTimeField ( auto_now_add = True )
    nb_pages = models.IntegerField ( default = 0 )
    size = models.FloatField ( default = 0.0 )
    updated_at = models.DateTimeField ( auto_now = True )
    created_time = models.DateTimeField ( null = True )
    update_time = models.DateTimeField ( null = True )
    organisation = models.ForeignKey ( Organisation , on_delete = models.CASCADE , null = True , to_field = 'uuid' )
    folder = models.ForeignKey ( Folder , on_delete = models.CASCADE , to_field = 'uuid' )
    cover = models.CharField ( max_length = 255 , null = True )
    last_analyzed_date = models.DateTimeField ( null = True )
    last_index_date = models.DateTimeField ( null = True )
    is_analyzed = models.BooleanField ( default = False )
    is_indexed = models.BooleanField ( default = False )

    def __str__ ( self ) :
        return "{}".format ( str ( self.path ) )

    def save ( self , *args , **kwargs ) :
        if not self.name :
            self.name = escaped_file_or_folder_name ( os.path.basename ( str ( self.path ) ) )
        # Set The Extension
        if not self.extension :
            self.extension = get_extension ( str ( self.name ) )

        if not self.display_name :
            display_name = os.path.basename ( str ( self.path ) )
            display_name = display_name.split ( '.' )[0]
            self.display_name = display_name.replace ( '_' , ' ' ).replace ( '-' , ' ' )

        if not self.organisation :
            self.organisation = self.folder.organisation

        if not self.size :
            try :
                if os.path.exists ( str ( self.path ) ) :
                    self.size = compute_file_size ( str ( self.path ) )
                else :
                    self.size = int ( self.path.file.size ) / (1204 * 1024)
            except :
                print ( f'An error occurs during Size computing of : {str ( self.path )}' )
        super ( ).save ( *args , **kwargs )


@receiver ( post_delete , sender = File )
def submission_delete ( sender , instance , **kwargs ) :
    if os.path.isfile ( str ( instance.path ) ) :
        os.remove ( str ( instance.path ) )

    if os.path.isfile ( str ( instance.temp_pdf ) ) :
        os.remove ( str ( instance.temp_pdf ) )

    if os.path.isfile ( str ( instance.temp_html ) ) :
        os.remove ( str ( instance.temp_html ) )
