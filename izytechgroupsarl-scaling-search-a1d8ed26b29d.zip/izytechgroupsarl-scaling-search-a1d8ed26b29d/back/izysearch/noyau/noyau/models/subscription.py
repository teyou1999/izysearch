import uuid as uuid
from django.db import models
from noyau.models import Organisation
from noyau.models.constants import VALIDITY_CHOICES , SUBSCRIPTION_CHOICES


class Formula(models.Model):
    """
    Subscription Formula on Izysearch
    """
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255, null=False, unique=True)
    description = models.TextField(null=True, default = None)
    validity = models.CharField(max_length=255, choices=VALIDITY_CHOICES, default='Month')
    max_users = models.IntegerField(default = 5)
    max_size = models.FloatField(default=100.0) # Size in MB
    max_queries = models.IntegerField(default=10000)
    price = models.FloatField(default = 0.0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)


class Subscription(models.Model):
    """
    Subscription of an Organisation in Izysearch
    """
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    start_date = models.DateTimeField(null=True)
    end_date = models.DateTimeField(null=True)
    max_users = models.BigIntegerField (default = 1)
    current_users = models.BigIntegerField (default = 1)
    max_size = models.FloatField (default=100.0)
    current_size = models.FloatField(default=0.0)
    max_queries = models.BigIntegerField (default=10000)
    current_queries = models.BigIntegerField (default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    status = models.CharField(max_length=255, choices=SUBSCRIPTION_CHOICES, default='Active')
    organisation = models.ForeignKey(Organisation, on_delete=models.CASCADE, null=True, to_field='uuid')
    formula = models.ForeignKey(Formula, on_delete=models.CASCADE, null=True, to_field='uuid')


class SubscriptionHistory(models.Model):
    """
    Subscription of an Organisation in Izysearch
    """
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    start_date = models.DateTimeField(null=True)
    end_date = models.DateTimeField(null=True)
    max_users = models.BigIntegerField(default = 1)
    used_users = models.BigIntegerField(default = 1)
    max_size = models.FloatField(default=100.0)
    used_size = models.FloatField(default=0.0)
    max_queries = models.BigIntegerField(default=10000)
    used_queries = models.BigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    validity = models.CharField(max_length=255, choices=VALIDITY_CHOICES, default='Month')
    formula = models.CharField(max_length=255)
    status = models.CharField(max_length=255, choices=SUBSCRIPTION_CHOICES, default='Expired')
    organisation = models.ForeignKey(Organisation, on_delete=models.CASCADE, null=True, to_field='uuid')
