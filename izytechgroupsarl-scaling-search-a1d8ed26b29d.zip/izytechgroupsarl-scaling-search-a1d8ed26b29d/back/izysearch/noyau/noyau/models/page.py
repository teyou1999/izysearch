import uuid as uuid
from django.db import models
from django.db.models.signals import post_delete
from django.dispatch.dispatcher import receiver

from .image import Image
from .file import File


class Page ( models.Model ) :
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    text = models.TextField ( null = True , default = None )
    title = models.TextField ( null = True , default = None )
    url = models.CharField ( max_length = 255 , null = True , default = None )
    page = models.IntegerField ( null = True )
    created_at = models.DateTimeField ( auto_now_add = True )
    updated_at = models.DateTimeField ( auto_now = True )
    file = models.ForeignKey ( File , on_delete = models.CASCADE , to_field = 'uuid' )
    image = models.ForeignKey ( Image , on_delete = models.CASCADE , to_field = 'uuid' )

    def __str__ ( self ) :
        return "{}".format ( self.title )

    class Meta :
        indexes = [
            models.Index ( fields = ['file'] , name = 'file_idx' )
        ]


@receiver ( post_delete , sender = Page )
def submission_delete ( sender , instance , **kwargs ) :
    try :
        if instance.image :
            instance.image.delete ( )
    except :
        print ( f"An error occurs during Image deletion" )
