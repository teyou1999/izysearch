from django.db import models
from django.db.models.signals import pre_delete
from django.dispatch.dispatcher import receiver
from noyau import Memory
from noyau.models import Folder
import uuid as uuid


class PageIndex ( models.Model ) :
    uuid = models.UUIDField ( default = uuid.uuid4 , editable = False , unique = True )
    created_at = models.DateTimeField ( auto_now_add = True )
    updated_at = models.DateTimeField ( auto_now = True )
    es_index = models.CharField ( max_length = 255 , null = True , unique = True )
    folder = models.ForeignKey ( Folder , on_delete = models.CASCADE , null = False , to_field = 'uuid' )

    def __str__ ( self ) :
        return "{}".format ( self.es_index )


@receiver ( pre_delete , sender = PageIndex )
def submission_delete ( sender , instance , **kwargs ) :
    m = Memory.getInstance ( )
    m.es_chunk_client.delete_index ( instance.es_index )
