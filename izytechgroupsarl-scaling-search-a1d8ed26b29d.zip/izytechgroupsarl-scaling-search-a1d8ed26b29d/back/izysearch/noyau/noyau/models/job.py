from django.db import models
from noyau.models import Log


class Job(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    nb_tasks = models.IntegerField(default=1)
    weigth = models.FloatField(default=0.0)
    log = models.ForeignKey(Log, on_delete=models.CASCADE, null=True, to_field='uuid')
    process_id = models.CharField(max_length = 255, null = False, unique = True)


    def __str__(self):
        return "{}".format(self.process_id)


    class Meta:
        indexes = [
            models.Index(fields=['log'], name='log_idx')
        ]
