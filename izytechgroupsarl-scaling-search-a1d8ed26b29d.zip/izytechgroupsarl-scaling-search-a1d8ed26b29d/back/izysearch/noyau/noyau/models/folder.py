import uuid as uuid
import os
from django.db import models
from izysearch.settings import BASE_DIR, MEDIA_ROOT
from noyau.utils.folder_utils import escaped_file_or_folder_name
from django.dispatch import receiver
from django.db.models.signals import pre_delete
from noyau.utils.folder_utils import delete_folder
from noyau.utils.folder_utils import create_directory
from .organisation import Organisation


class Folder(models.Model):
    uuid = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    name = models.CharField(max_length=255, null=False)
    path = models.CharField(max_length=255, null=True, unique=True)
    creator_name = models.CharField(max_length=255, null=True, default=None)
    updater_name = models.CharField(max_length=255, null=True, default=None)
    is_analyzed = models.BooleanField(default=False)
    is_indexed = models.BooleanField(default=False)
    indexing = models.BooleanField(default=False)
    nb_pages = models.IntegerField(default = 0)
    nb_files = models.IntegerField(default = 0)
    nb_folders = models.IntegerField(default = 0)
    size = models.FloatField(default = 0.0)
    description = models.TextField(null=True, default = None)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    last_spliting_date = models.DateTimeField(null=True)
    last_index_date = models.DateTimeField(null=True)
    organisation = models.ForeignKey(Organisation,
                                    on_delete=models.CASCADE,
                                    null=True, blank=True, to_field='uuid')
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True,
                            to_field='uuid')
    def __str__(self):
        return "{}".format(self.path)

    def save(self, *args, **kwargs):
        # Reformat The name
        self.name = escaped_file_or_folder_name(self.name)
        if self.parent and not self.path:
            self.path = self.parent.path + "/" + self.name
        elif not self.path:
            # Get the organisation Root Folder
            root_folder_code = self.organisation.root_folder
            if not root_folder_code:
                self.path = MEDIA_ROOT + self.name
            else:
                root_folder = Folder.objects.get(uuid=root_folder_code)
                self.path = root_folder.path + "/" + self.name
                self.parent = root_folder

        if(not os.path.isdir(self.path)):
            create_directory(self.path)
        super().save(*args, **kwargs)

@receiver(pre_delete, sender=Folder)
def submission_delete(sender, instance, **kwargs):
    delete_folder(instance, sender)
