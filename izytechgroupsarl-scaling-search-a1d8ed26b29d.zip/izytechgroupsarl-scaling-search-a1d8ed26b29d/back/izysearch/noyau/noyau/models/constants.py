STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Active', 'Active'),
        ('Inactive', 'Inactive')
    )


SUBSCRIPTION_CHOICES = (
        ('Suspended', 'Suspended'),
        ('Active', 'Active'),
        ('Expired', 'Expired')
    )

VALIDITY_CHOICES = (
        ('Month', 'Month'),
        ('Quarter', 'Quarter'),
        ('Semester', 'Semester'),
        ('Annual', 'Annual'),
        ('Unlimited', 'Unlimited')
    )

TOKEN_TYPES = (
        ('Bearer', 'Month'),
        ('Token', 'Quarter')
    )
