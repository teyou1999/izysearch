from dateutil.relativedelta import relativedelta
from django.utils.timezone import get_current_timezone
from noyau.models import User , Organisation , Role
from noyau.models.connector import ConnectorType
from noyau.models.metadata import MetadataType
from noyau.models.subscription import Formula , Subscription
from noyau.utils.organisation_utils import create_root_dir


def create_super_user ( org ) :
    role = Role.objects.create (
        name = 'Super Admin' ,
        description = 'The Super Admin of The Izytech Platform'
    )

    return User.objects.create_user (
        username = "super_admin" ,
        first_name = "Super" ,
        password = 'secret' ,
        last_name = "Admin" ,
        email = "super_admin@izyechgroup.com" ,
        role = role ,
        org = org.uuid ,
        is_active = True ,
        is_superuser = True
    )


def create_super_organisation () :
    org = Organisation.objects.create (
        name = 'Izytech Group SARL' ,
        address = "Route de l'Université, Ngoa-Ekelle, Yaoundé" ,
        email = "admin@zyechgroup.com" ,
        status = 'Active'
    )

    super_admin = create_super_user ( org )
    root_dir = create_root_dir ( org )
    org.root_folder = root_dir
    org.admin = super_admin
    org.save ( )

    return org


def create_formulas () :
    return Formula.objects.create (
        name = 'Free' ,
        description = 'Evaluation Formula, 1 month free with 100 Mb, 10k queries and 5 users'
    )


from datetime import datetime


def create_subscriptions ( org , formula ) :
    subscription = Subscription.objects.create (
        formula = formula ,
        current_users = 1000000000000 ,
        organisation = org ,
        max_users = 100000000000000000 ,
        max_size = 100000000000000000 ,
        max_queries = 100000000000000000 ,
        start_date = datetime.now ( tz = get_current_timezone ( ) ) ,
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 6000 )
    )


def create_others_roles () :
    Role.objects.create (
        name = 'Organisation Admin' ,
        description = 'The Admin of a single Organisation'
    )

    Role.objects.create (
        name = 'User' ,
        description = 'A simple User of the platform'
    )


def create_connector_type () :
    ConnectorType.objects.create (
        name = 'OneDrive'
    )

    ConnectorType.objects.create (
        name = 'Google Drive' ,
        active = True
    )
    ConnectorType.objects.create (
        name = 'Sharepoint'
    )

    ConnectorType.objects.create (
        name = 'DropBox'
    )


def create_metadate_type () :
    MetadataType.objects.create (
        name = 'Chaîne de caractères' ,  # Int, Float, String
        type = 1 ,
        description = 'Texte correspondant par exemple à un numero de box'
    )

    MetadataType.objects.create (
        name = 'Date' ,
        type = 2 ,
        description = 'Date au format ISO (yyyy-mm-dd)'
    )

    MetadataType.objects.create (
        name = 'Intervalle Numérique' ,  # Of base int or float
        type = 3 ,
        description = 'Intervalle décrit par deux bornes réels'
    )
    MetadataType.objects.create (
        name = 'Intervalle de Dates' ,  # Of base int or float
        type = 4 ,
        description = 'Intervalle de Date au format ISO (yyyy-mm-dd)'
    )

    MetadataType.objects.create (
        name = 'Liste de Chaînes' ,  # Int, Float, String
        type = 5 ,
        description = "Liste de chaîne de caractères pour le cas d'une propriétés multivaluées"
    )


print ( 'Seeding the super Admin Organisation ...' )
org = create_super_organisation ( )
create_others_roles ( )
formula = create_formulas ( )
create_subscriptions ( org , formula )
create_connector_type ( )
create_metadate_type ( )
