import regex
import re
from nltk import word_tokenize
import string
from gensim.utils import to_unicode


class TextPreprocessor:
    """
    This class is dedicated to the pre-processing of Chunk and query texts. <br/>
    """

    def __init__(self, lang='french'):
        self.list_stopwords = []
        self.RE_PUNCT = re.compile(
            r'([%s])+' % re.escape(string.punctuation), re.UNICODE)
        self.RE_TAGS = re.compile(r"<([^>]+)>", re.UNICODE)
        self.RE_NONALPHA = re.compile(r"\W", re.UNICODE)
        self.digit_regex = re.compile(r"^\d*\.?\d")

        self.STOPWORDS = ['d', 'l', 'qui', 'quoi', 'où', 'comment', 'que', 'qu\'', 'lequel', 'laquelle', 'lesquels',
                           'lesquelles', 'auquel', 'à laquelle, auxquels', 'auxquelles', 'duquel', 'quand', 'à', 'au',
                           'là', 'cependant', 'mais', 'où', 'comme', 'donc', 'or', 'ni', 'le', 'quels', 'les', 'de', 'des', 'pourquoi', 'en',
                           'mais', 'où', 'donc', 'or', 'ni']


    def remove_stopwords(self, s):
        s = to_unicode(s)
        return " ".join(w for w in word_tokenize(s.replace("'", " ")) if w not in self.STOPWORDS)

    def strip_punctuation(self, s):
        s = to_unicode(s)
        return self.RE_PUNCT.sub(" ", s)

    def strip_tags(self, s):
        s = to_unicode(s)
        return self.RE_TAGS.sub("", s)

    def strip_non_alphanum(self, s):
        s = to_unicode(s)
        return self.RE_NONALPHA.sub(" ", s)

    def correct_sentence(self, s):
        """
        Correct some mistakes in a sentences
        Removing special characters and digits
        :param s:
        :return:
        """
        s = s.replace('.', ' . ')
        s = s.replace(',', ' ')
        s = s.replace('+', ' + ')
        s = s.replace('\n', ' ')
        # Remove number
        s = re.sub(r'\b\d+(?:\.\d+)?\s+', '', s)
        return s


    def preprocess_string(self, text_):
        # tokenize and preprocess chunks
        text = text_.lower()
        intab = "éëêèçàçùöôûüïîäâ,;:()^$=# -'"
        outtab = "eeeecacuoouuiiaa            "
        trantab = str.maketrans(intab, outtab)
        remove = regex.compile(
            r'[\p{C}|\p{M}|\p{P}|\p{S}|\p{Z}]+', regex.UNICODE)
        new_text = remove.sub(u" ", text).strip()
        new_text = new_text.translate(trantab)
        new_text = self.remove_stopwords(new_text)
        return new_text


    def preprocess_metadata(self, text_):
        # tokenize and preprocess chunks
        text = text_.lower()
        intab = "éëêèçàçùöôûüïîäâ,;:()^$=# -'"
        outtab = "eeeecacuoouuiiaa            "
        trantab = str.maketrans(intab, outtab)
        remove = regex.compile(
            r'[\p{C}|\p{M}|\p{P}|\p{S}|\p{Z}]+', regex.UNICODE)
        new_text = remove.sub(u" ", text).strip()
        new_text = new_text.translate(trantab)
        return new_text
