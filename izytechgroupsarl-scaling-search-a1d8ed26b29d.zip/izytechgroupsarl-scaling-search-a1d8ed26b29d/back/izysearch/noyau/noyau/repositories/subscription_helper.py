from datetime import datetime
from dateutil.relativedelta import relativedelta
from django.utils.timezone import get_current_timezone
from noyau.models import Organisation , Formula , Subscription , User
from noyau.models.subscription import SubscriptionHistory
from noyau.repositories.db import get_all , get_one_with_params , insert_by_batch


def get_subscription_end_date ( formula ) :
    """
    Get the end date of a subscription
    :param formula:
    :return:
    """
    end_date = None

    if formula.validity == 'Month' :
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 1 )

    if formula.validity == 'Quarter' :
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 3 )

    if formula.validity == 'Semester' :
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 6 )

    if formula.validity == 'Annual' :
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 12 )

    if formula.validity == 'Unlimited' :
        end_date = datetime.now ( tz = get_current_timezone ( ) ) + relativedelta ( months = 600 )

    return end_date


def organisation_subscription_renew ( organisation: Organisation ) :
    """
    Update Organisation subscription
    :param organisation:
    :return:
    """
    subscription = get_one_with_params ( Subscription , organisation = organisation )

    # Generate an history
    history = create_subscription_history ( subscription )
    history.save ( )

    subscription.current_queries = 0
    subscription.end_date = get_subscription_end_date ( subscription.formula )
    subscription.save ( )
    return subscription


def create_subscription_history ( subscription: Subscription , status=None ) :
    """
    Create subscription history.
    This will be generated each time an organisation subscription is renewed or changed
    :param subscription:
    :return:
    """
    if not status :
        status = "Expired"

    history = SubscriptionHistory (
        formula = subscription.formula.name ,
        validity = subscription.formula.validity ,
        used_users = subscription.current_users ,
        used_size = subscription.current_size ,
        used_queries = subscription.current_queries ,
        organisation = subscription.organisation ,
        max_users = subscription.formula.max_users ,
        max_size = subscription.formula.max_size ,
        max_queries = subscription.formula.max_queries ,
        start_date = subscription.start_date ,
        end_date = subscription.end_date ,
        status = status
    )
    return history


def create_subscription ( formula: Formula , organisation: Organisation ) :
    """
    This function creates a validity subscription for an organisation
    :param formula:
    :param organisation:
    :return:
    """
    # get Existing subscription
    subscriptions = get_all ( Subscription , organisation = organisation )
    if subscriptions :
        history_items = []
        for sub in subscriptions :
            history_items.append ( create_subscription_history ( sub ) )
        subscriptions.delete ( )
        insert_by_batch ( SubscriptionHistory , history_items , 100 )

    # Get organisation users
    current_users = 0
    users = get_all ( User , org = str ( organisation.uuid ).replace ( '-' , '' ) )
    if users :
        current_users = len ( users )

    subscription = Subscription.objects.create (
        formula = formula ,
        current_users = current_users ,
        organisation = organisation ,
        max_users = formula.max_users ,
        max_size = formula.max_size ,
        max_queries = formula.max_queries ,
        start_date = datetime.now ( tz = get_current_timezone ( ) ) ,
        end_date = get_subscription_end_date ( formula )
    )

    return subscription
