from noyau.models import Log


def delete_log(instance, model_id):
    """
    Delete all logs related to a model. <br/>
    :param instance:
    :param model_id:
    :return:
    """
    Log.objects.filter(object_id=model_id, object_type=instance).delete()
