from django.db import transaction
from uuid import UUID


def get_one_with_params ( instance , **kwargs ) :
    """
    Get one Object from de BD using filter params. <br/>
    :param instance:
    :param kwargs:
    :return:
    """
    try :
        obj = instance.objects.get ( **kwargs )
    except instance.DoesNotExist :
        obj = None
    return obj


def is_uuid(uuid):
    """
    Test if a string is an valid UUID
    :param uuid:
    :return:
    """
    try:
        v = UUID(uuid).version
        return True
    except ValueError:
        return False


def get_all_exclude(instance, **kwargs):
    """
    Get All Objects from the instance type, excluding those filter by params. <br/
    :param instance:
    :param kwargs:
    :return:
    """
    try:
        if len(kwargs.items()) == 0:
            objects = instance.objects.all()
        else:
            objects = instance.objects.exclude(**kwargs)

        if objects is None or len(objects) == 0:
            return []
        else:
            return objects
    except:
        return []


def is_valid_uuid(uuid_to_test, version=4):
    """
    Check if uuid_to_test is a valid UUID.

    Parameters
    ----------
    uuid_to_test : str
    version : {1, 2, 3, 4}

    Returns
    -------
    `True` if uuid_to_test is a valid UUID, otherwise `False`.

    Examples
    --------
    >>> is_valid_uuid('c9bf9e57-1685-4c89-bafb-ff5af830be8a')
    True
    >>> is_valid_uuid('c9bf9e58')
    False
    """
    if len(str(uuid_to_test)) == len('c9bf9e5716854c89bafbff5af830be8a') and '-' not in str(uuid_to_test):
        return True

    try:
        uuid_obj = UUID(uuid_to_test, version=version)
    except ValueError:
        return False

    return str(uuid_obj) == uuid_to_test


def insert_by_batch(instance, obj_list, batch_size=100):
    """
    Insert a set a Object in the database by Batch. <br/>
    :param instance:
    :param obj_list:
    :param batch_size:
    :return:
    """
    for i in range(0, len(obj_list), batch_size):
        batch = obj_list[i:i+batch_size]
        instance.objects.bulk_create(batch)


def get_all(instance, **kwargs):
    """
    Filter all an Instance objects using a set of params. <br/>
    :param instance:
    :param kwargs:
    :return:
    """
    try:
        if len(kwargs.items()) == 0:
            objects = instance.objects.all()
        else:
            objects = instance.objects.filter(**kwargs)

        if objects is None or len(objects) == 0:
            return []
        else:
            return objects
    except:
        return []


def get_objects_in_order(instance, field='id', values=[]):
    """
    This fuction helps to extract all the objects of the instance type, where the field values are in the values list. \
    Here we want the objects to be retrieved with the same order as the values. \
    :param instance:
    :param field:
    :param values:
    :return:
    """
    if not values:
        return []

    clauses = ' '.join(['WHEN %s=%s THEN %s' % (field, id, i)
                            for i, id in enumerate(values)])
    ordering = 'CASE %s END' % clauses
    objects = instance.objects.filter(id__in=values).extra(
        select={'ordering': ordering}, order_by=('ordering',))
    return objects


def update_by_batch(obj_list, batch_size):
    """
    Update a set of Objects by batch using transactions. <br/>
    :param obj_list:
    :param batch_size:
    :return:
    """
    for i in range(0, len(obj_list), batch_size):
        batch = obj_list[i:i+batch_size]
        with transaction.atomic():
            for obj in batch:
                obj.save()


def delete_by_batch(obj_list, batch_size):
    """
    Delete a set of Objects by batch using transactions. <br/>
    :param obj_list:
    :param batch_size:
    :return:
    """
    for i in range(0, len(obj_list), batch_size):
        batch = obj_list[i:i+batch_size]
        with transaction.atomic():
            for obj in batch:
                obj.delete()

