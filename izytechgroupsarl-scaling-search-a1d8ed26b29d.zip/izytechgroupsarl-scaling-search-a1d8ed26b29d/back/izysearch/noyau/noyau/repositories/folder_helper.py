import shutil

from noyau.repositories.db import get_one_with_params , get_all
from izysearch.settings import PROCESSED_FORMATS
from noyau.models import File , Page , Folder , Organisation
from noyau.utils.folder_utils import escaped_file_or_folder_name


def is_organisation_root ( folder ) :
    """
    Check if the folder given as parameter is root for an organisation. <br/>
    :param folder:
    :return:
    """
    if get_one_with_params ( Organisation , root_folder = folder.uuid ) :
        return True

    return False


def count_folder_files ( folder , processable=True ) :
    """
    Count the number of files in a folder. <br/>
    :return:
    """
    # Get all the children files
    children_files = get_children_files ( folder , processable = processable )
    return len ( children_files )


def count_folder_sub_folders ( folder ) :
    """
    Count the number of sub folders in a folder. <br/>
    :return:
    """
    # Get all the children files
    sub_folders = get_children_folder ( folder )
    return len ( sub_folders )


def count_folder_files_and_pages ( folder ) :
    """
    Coumpute at the same time, the number of files and the number of pages. <br/>
    :param folder:
    :return:
    """
    children_files = get_children_files ( folder , processable = True )
    # Get the corresponding pages
    pages = get_all ( Page , file__in = children_files )
    return len ( children_files ) , len ( pages )


def get_children_files ( current_dir , processable=False ) :
    """
    Get all the files contained in a given folder. <br/>
    We can filter only those which are processable like PDF, DOC and avoid ZIP or RAR. <br/>
    :param current_dir:
    :param processable:
    :return:
    """
    if processable :
        children_files = File.objects.filter ( folder = current_dir , extension__in = PROCESSED_FORMATS )
    else :
        children_files = File.objects.filter ( folder = current_dir )

    children = Folder.objects.filter ( parent = current_dir )

    if not children :
        return children_files

    for child in children :
        child_files = get_children_files ( child , processable )
        children_files = concat_querset_list ( children_files , child_files )

    return children_files


def get_children_folder ( current_dir ) :
    """
    Get all the Children folders of a given folder
    :param current_dir:
    :return:
    """
    children = Folder.objects.filter ( parent = current_dir )
    children_folders = [e for e in children]

    if not children or len ( children ) == 0 :
        return children_folders

    # Add This
    for child in children :
        child_folders = get_children_folder ( child )
        children_folders = concat_querset_list ( children_folders , child_folders )

    return children_folders


def mv_file ( src , dst ) :
    """
    Alters the path of folders contained within moved directory
    :param parent directory of files:
    :param path of new parent directory:
    """
    old_files = File.objects.filter ( folder = src )
    for old_file in old_files :
        new_path = (dst + '/'
                    + str ( escaped_file_or_folder_name ( old_file.display_name ) ))
        old_file.path.name = new_path
        old_file.save ( )


def folder_in_folders ( folder_id , folders ) :
    """
    Check if a Folder is in a set of folders
    :param folder_id:
    :param folders:
    :return:
    """
    for f in folders :
        if int ( folder_id ) == int ( f.id ) :
            return True
    return False


def concat_querset_list ( l1 , l2 ) :
    """
    Concatenate two collections
    :param l1:
    :param l2:
    :return:
    """
    concatened = [e for e in l1]

    for e in l2 :
        concatened.append ( e )
    return concatened


def get_file_text ( file ) :
    """
    Get the row text of a file. \
    :param file:
    :return:
    """
    pages = get_all ( Page , file = file )

    file_text = ""
    for page in pages :
        file_text += (" " + str ( page.text ))

    return file_text


def get_all_org_root_folders ( root_org_id ) :
    """
    Get all the root folders related to organisations
    :param org:
    :return:
    """
    organisations = get_all ( Organisation )

    root_folders = []
    for organisation in organisations :
        if organisation.id == root_org_id :
            continue
        root_folder = get_one_with_params ( Folder , uuid = organisation.root_folder )
        root_folders.append ( root_folder )

    return root_folders


def compute_folder_size ( folder ) :
    """
    Compute Size of a folder
    :param folder:
    :return:
    """
    children = get_children_files ( folder , processable = True )
    return sum ( file_.size for file_ in children )


def mv_folder ( src , dst , count ) :
    """
    Recursively alter the path of directory in db.
    :param src: path of the source folder
    :param dst: path of the destination
    """
    folder = Folder.objects.get ( uuid = dst )
    old_file = Folder.objects.get ( uuid = src )
    new_path = (folder.path + '/' + escaped_file_or_folder_name ( old_file.name ))
    if (count == 0) :
        shutil.move ( str ( old_file.path ) , new_path )
    old_file.path = new_path
    old_file.save ( )
    mv_file ( old_file , new_path )
    children = Folder.objects.filter ( parent = src )
    for child in children :
        mv_folder ( child.uuid , old_file.uuid , 1 )
    if (count == 0) :
        return (old_file.path , folder.uuid)
