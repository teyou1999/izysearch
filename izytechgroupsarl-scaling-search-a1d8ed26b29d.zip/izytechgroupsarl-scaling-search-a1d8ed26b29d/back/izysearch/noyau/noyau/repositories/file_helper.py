import os


def get_basename(filename):
    """
    Get the basename of a File
    :param filename:
    :return:
    """
    tokens = filename.split('.')
    basename = ''
    for i in range(len(tokens)-1):
        basename += (tokens[i] + ' ')
    return basename


def compute_file_size(file_path):
    """
    Compute a file size based on it Path.
    the unit is MB.
    :param file_path:
    :return:
    """
    with open(file_path) as f:
        size_bytes = os.fstat(f.fileno()).st_size
        return int(size_bytes)/(1204*1024)
