import json
import traceback
from elasticsearch import Elasticsearch
from elasticsearch.helpers import bulk
from izysearch.settings import (
    ES_SERVER,
    ES_PORT,
    ES_USERNAME,
    ES_PASSWORD,
    ES_INSERT_BATCH_SIZE,
    ES_RETRIEVE_BATCH_SIZE
)

from itypes import List



class ElasticSearchHelper():

    __slots__ = ('client', 'config')

    def __init__(self, mapping_file):
        self.client = Elasticsearch(
            [ES_SERVER],
            port=ES_PORT,
            http_auth = (ES_USERNAME, ES_PASSWORD)
        )

        def _load_es_config():
           with open(mapping_file) as f:
                return json.load(f)

        self.config = _load_es_config()


    def create_index(self, index_name:str, user = None)->bool:
        """
        Creation an ElasticSearch Index with a name given as parameter. \
        :param index_name:
        :param user:
        :return:
        """
        if not self.client:
            return False

        try:
            if not self.index_exists(index_name):
                self.client.indices.create(
                    index = index_name,
                    body=self.config,
                    ignore=[400, 404]
                )
            return True
        except:
            traceback.print_exc()
            print(f'Problem creating ElasticSearch Index : {index_name}')
            return False


    def delete_index(self, index_name:str, user = None)->bool:
        """
        Delete An Index by name. \
        :param index_name:
        :param user:
        :return:
        """
        if not self.client:
            return False

        try:
            if self.index_exists(index_name):
                self.client.indices.delete(
                    index = index_name,
                    ignore=[400, 404]
                )
            return True
        except:
            traceback.print_exc()
            return False


    def get_suggestion(self, word, index_name:str)->list:
        """
        Retrieve all the words of the index close to the one given as parameter. \
        :param query:
        :param index_name:
        :param doc_type:
        :param K:
        :param user:
        :return:
        """
        if not self.client:
            return []

        try:
            results = self.client.search(
                    index=index_name,
                    body=word,
                    size = 5
                )
            return results['suggest']["q"]
        except:
            traceback.print_exc()
            return []



    def insert_doc_in_index(self, docs:List, index_name:str, doc_type:str,doc_size:int, user=None)->bool:
        """
        Insert a list of well structured documents in a index. \
        These documents should already been formated with the index type, and the documents types.
        :param docs:
        :param index_name:
        :param doc_type:
        :param doc_size:
        :param user:
        :return:
        """
        if not self.client:
            return False

        try:
            # Insert elements By Batch
            start = 0
            added = 0
            successfull = True
            while start <= len(docs):
                end = min(len(docs), start + ES_INSERT_BATCH_SIZE)
                success, failed = bulk(self.client, docs[start:end])
                added = end-start
                successfull = added==success
                start = start + ES_INSERT_BATCH_SIZE

            return successfull
        except:
            traceback.print_exc()
            return False


    def retrieve_docs(self, query, index_name:str, doc_type:str, K:int=100, user=None)->list:
        """
        Retrieve all the top K documents mapping a Query give as parameter. \
        :param query:
        :param index_name:
        :param doc_type:
        :param K:
        :param user:
        :return:
        """
        if not self.client:
            return []

        try:
            results = self.client.search(
                    index=index_name,
                    body=query,
                )
            top_k = max(len(results['hits']['hits']), K)
            return results['hits']['hits'][:top_k]
        except:
            traceback.print_exc()
            return []

    def count_docs(self, query, index_name:str)->int:
        """
        Count Docs of an index Matching a query. \
        :param query:
        :param index_name:
        :param doc_type:
        :param K:
        :param user:
        :return:
        """
        if not self.client:
            return 0

        try:
            results = self.client.count(
                    index=index_name,
                    body=query,
                )
            return results['count']
        except:
            traceback.print_exc()
            print(f"And error Occurs during the counting of doc in {index_name}")
            return 0


    def update_by_query(self, query, index_name:str)->int:
        """
        Update docs Matching a query. \
        :param query:
        :param index_name:
        :return:
        """
        if not self.client:
            return False
        try:
            self.client.update_by_query(
                    index=index_name,
                    body=query,
                )
            self.client.indices.refresh(index=index_name)
            return True
        except:
            traceback.print_exc()
            print(f"And error Occurs during the updating of docs in {index_name}")
            return False


    def retrieve_docs_with_scroll(self, query, index_name:str, doc_type:str)->list:
        """
        Retrieve all document in the index with scroll. \
        :param query:
        :param index_name:
        :param doc_type:
        :param K:
        :param user:
        :return:
        """
        if not self.client:
            return []


        try:
            data = self.client.search(
                index=index_name,
                doc_type=doc_type,
                scroll='2m',
                body=query
            )
            return data
        except:
            traceback.print_exc()
            return []


    def index_exists(self, index_name:str):
        """
        Returns whether an index exists or not
        :param index_name:
        :return:
        """
        if not self.client:
            return False
        try:
            res = self.client.search(index=index_name)
            if 'hits' not in res:
                return False
            return True
        except:
            return False


    def delete_documents(self, index_name:str, query_body:dict, user = None)->bool:
        """
        Delete all documents in an index matching a query. \
        :param index_name:
        :param user:
        :return:
        """
        if not self.client:
            return False

        try:
            if self.index_exists(index_name):
                self.client.delete_by_query(
                    index = index_name,
                    body=query_body
                )
            return True
        except:
            traceback.print_exc()
            return False
