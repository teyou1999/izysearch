from noyau.elasticsearch.client import ElasticSearchHelper
from noyau.memory import Memory
from izysearch.settings import ES_DOC_MAPPING, ES_PAGE_MAPPING
from noyau.repositories.text_helper import TextPreprocessor

m = Memory.getInstance()

print('Intilializing ElasticSearch connector ...')
m.es_client = ElasticSearchHelper(ES_DOC_MAPPING)
m.es_chunk_client = ElasticSearchHelper(ES_PAGE_MAPPING)
m.text_processor = TextPreprocessor()
