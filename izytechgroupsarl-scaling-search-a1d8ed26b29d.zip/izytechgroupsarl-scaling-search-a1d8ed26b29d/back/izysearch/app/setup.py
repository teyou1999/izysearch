from setuptools import setup

version = '0.0.1'

setup(
    name="app",
    version=version,
    description='Izysearch Kernel for app',
    url='www.izytechgroup.com',
    author='Armel Fotsoh',
    author_email='armel@izytechgroup.com',
    include_package_data=True,
    packages=['app']
)
