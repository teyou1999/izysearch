from rest_framework import serializers
from noyau.models import Organisation , User


class OrganisationSerializer ( serializers.ModelSerializer ) :
    admin = serializers.PrimaryKeyRelatedField ( queryset = User.objects.all ( ) )

    class Meta :
        model = Organisation
        fields = ('id' , 'uuid' , 'name' , 'address' , 'email' , 'description' , 'status' , 'admin' , 'root_folder')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'admin')
        depth = 3

    def validate ( self , data ) :
        """
        Validations for an Organisation
        - The name is required
        - The admin also
        :param data:
        :return:
        """
        if 'name' not in data :
            raise serializers.ValidationError ( "Organisation name must be fullfilled !" )

        if data['name'] == None or data['name'] == "" :
            raise serializers.ValidationError ( "Organisation name cannot be empty !" )
        return data


class GetOrganisationSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    root_folder = serializers.SerializerMethodField ( )

    class Meta :
        model = Organisation
        fields = ('id' , 'uuid' , 'name' , 'address' , 'email' , 'description' , 'status' , 'root_folder')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'admin')
        depth = 3

    def get_root_folder ( self , organisation ) :
        return (str ( organisation.root_folder ).replace ( '-' , '' ))

    def get_uuid ( self , organisation ) :
        return (str ( organisation.uuid ).replace ( '-' , '' ))


class GetOrganisationRootSerializer ( serializers.ModelSerializer ) :
    root_folder = serializers.SerializerMethodField ( )
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = Organisation
        fields = ('root_folder' ,)

    def get_root_folder ( self , org ) :
        if org.root_folder :
            return org.root_folder.replace ( '-' , '' )
        else :
            return 'undefined'

    def get_uuid ( self , organisation ) :
        return (str ( organisation.uuid ).replace ( '-' , '' ))
