from noyau.models.subscription import Formula
from rest_framework import serializers


class FormulaSerializer (serializers.ModelSerializer ) :

    class Meta :
        model = Formula
        fields = ('name' , 'description' , 'validity' , 'max_users' , 'max_size' ,
                  'max_queries', 'price')

    def validate(self, data):
        """
        Validate teh file name
        :param data:
        :return:
        """
        if 'name' not in data:
            raise serializers.ValidationError("The Formula Name is Required !")


        return data


class GetFormulaSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = Formula
        fields = ('name', 'uuid', 'description' , 'validity' , 'max_users' , 'max_size' ,
                  'max_queries', 'price', 'created_at', 'updated_at')
        read_only_fields = ('id' ,)

    def get_uuid(self, formula):
        return(str(formula.uuid).replace('-', ''))
