from app.serializers.formula_serializer import GetFormulaSerializer
from app.serializers.organisation_serializer import GetOrganisationSerializer
from noyau.models.subscription import Subscription , SubscriptionHistory
from rest_framework import serializers


class SubscriptionSerializer (serializers.ModelSerializer ) :

    class Meta :
        model = Subscription
        fields = ('max_users' , 'start_date' , 'max_size' ,
                  'max_queries', 'end_date')


class GetSubscriptionSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    organisation = GetOrganisationSerializer()
    formula = GetFormulaSerializer()

    class Meta :
        model = Subscription
        fields = ('start_date', 'uuid', 'end_date' , 'current_queries' , 'max_users' , 'max_size' ,
                  'max_queries', 'current_users', 'current_size', 'created_at', 'updated_at', 'organisation',
                  'formula', 'status')
        read_only_fields = ('id' ,)

    def get_uuid(self, formula):
        return(str(formula.uuid).replace('-', ''))



class GetSubscriptionHistorySerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    organisation = GetOrganisationSerializer()

    class Meta :
        model = SubscriptionHistory
        fields = ('start_date', 'uuid', 'end_date' , 'used_queries' , 'max_users' , 'max_size' ,
                  'max_queries', 'used_users', 'used_size', 'created_at', 'updated_at', 'organisation',
                  'formula', 'status')
        read_only_fields = ('id' ,)

    def get_uuid(self, formula):
        return(str(formula.uuid).replace('-', ''))

