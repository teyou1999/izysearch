from noyau.repositories.folder_helper import get_children_files
from rest_framework import serializers
from noyau.models import Organisation, Folder
from noyau.utils.folder_utils import valid_file_or_folder
from app.serializers.organisation_serializer import GetOrganisationSerializer


class FolderSerializer(serializers.ModelSerializer):
    organisation = serializers.PrimaryKeyRelatedField(queryset=Organisation.objects.all())

    class Meta:
        model = Folder
        fields = ('id', 'uuid', 'name', 'description', 'created_at', 'path',
                  'updated_at', 'organisation', 'parent')
        read_only_fields = ('id', 'uuid', 'created_at', 'updated_at', 'path')

    def validate(self, data):
        """
        Validate teh file name
        :param data:
        :return:
        """
        if 'name' not in data:
            raise serializers.ValidationError("The name is mandatory")

        if 'path' in data:
            raise serializers.ValidationError("The path is not allow as parameter here")

        if 'name' in data:
            if not valid_file_or_folder(data['name']):
                raise serializers.ValidationError("The folder name must be Unix compliant !")
        return data


class GetFolderSerializer(serializers.ModelSerializer):
    organisation = GetOrganisationSerializer()
    uuid = serializers.SerializerMethodField()
    size = serializers.SerializerMethodField()
    nb_folders = serializers.SerializerMethodField()
    folder = serializers.SerializerMethodField()
    current_index = serializers.SerializerMethodField()

    class Meta:
        model = Folder
        fields = ('id', 'uuid', 'name', 'path', 'description', 'created_at', 'last_index_date', 'last_spliting_date', 'current_index',
                  'updated_at', 'organisation', 'parent', 'is_analyzed', 'is_indexed', 'nb_pages',
                  'nb_files', 'nb_folders', 'folder', 'size')
        read_only_fields = ('id', 'uuid', 'created_at', 'updated_at', 'organisation')

    def get_uuid(self, folder):
        return(str(folder.uuid).replace('-', ''))

    def get_nb_folders( self, folder ):
        if  hasattr(folder, 'nb_folders'):
            return folder.nb_folders
        return 0

    def get_size( self, folder ):
        children = get_children_files(folder, processable=True)
        return sum(file_.size for file_ in children)

    def get_folder( self, folder ):
        if  hasattr(folder, 'folder'):
            return folder.folder
        return True

    def get_current_index( self, folder ):
        if  hasattr(folder, 'current_index'):
            return folder.current_index
        return False

class GetRemoteFolderSerializer(serializers.ModelSerializer):
    """
    Folder Coming from remote source like Drive and others.
    """
    organisation = GetOrganisationSerializer()
    uuid = serializers.SerializerMethodField()
    size = serializers.SerializerMethodField()
    nb_folders = serializers.SerializerMethodField()
    folder = serializers.SerializerMethodField()
    current_index = serializers.SerializerMethodField()
    connector_name = serializers.SerializerMethodField()
    last_synchronisation = serializers.SerializerMethodField()
    parent = GetFolderSerializer()

    class Meta:
        model = Folder
        fields = ('id', 'uuid', 'name', 'path', 'description', 'created_at', 'last_index_date', 'last_spliting_date', 'current_index',
                  'updated_at', 'organisation', 'parent', 'is_', 'is_indexed', 'nb_pages',
                  'nb_files', 'nb_folders', 'folder', 'size', 'last_synchronisation', 'connector_name')
        read_only_fields = ('id', 'uuid', 'created_at', 'updated_at', 'organisation')

    def get_uuid(self, folder):
        return(str(folder.uuid).replace('-', ''))

    def get_nb_folders( self, folder ):
        if  hasattr(folder, 'nb_folders'):
            return folder.nb_folders
        return 0

    def get_size( self, folder ):
        children = get_children_files(folder, processable=True)
        return sum(file_.size for file_ in children)

    def get_folder( self, folder ):
        if  hasattr(folder, 'folder'):
            return folder.folder
        return True

    def get_current_index( self, folder ):
        if  hasattr(folder, 'current_index'):
            return folder.current_index
        return False

    def get_connector_name( self, folder ):
        return folder.connector_name

    def get_last_synchronisation( self, folder ):
        return folder.last_synchronisation
