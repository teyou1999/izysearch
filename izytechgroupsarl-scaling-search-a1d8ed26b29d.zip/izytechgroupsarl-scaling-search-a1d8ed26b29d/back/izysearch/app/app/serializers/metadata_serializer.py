from app.repositories.string_helper import deduplicate_string_list
from noyau.repositories.db import get_all
from rest_framework import serializers
from noyau.models import MetadataType , Metadata , MetadataValue


class MetadataTypeSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = MetadataType
        fields = ('id' , 'name' , 'uuid' , 'description')
        read_only_fields = ('id' ,)

    def get_uuid ( self , role ) :
        return str ( role.uuid ).replace ( '-' , '' )


class MetadataSerializer ( serializers.ModelSerializer ) :
    class Meta :
        model = Metadata
        fields = ('name' , 'organisation' , 'type')

    def validate ( self , data ) :
        """
        Validate teh file name
        :param data:
        :return:
        """
        if 'organisation' not in data :
            raise serializers.ValidationError ( "The Organisation is Required !" )

        if 'type' not in data :
            raise serializers.ValidationError ( "The Type is Required !" )

        if 'name' not in data :
            raise serializers.ValidationError ( "The Name is Required !" )

        return data


class GetMetadataSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    type = serializers.SerializerMethodField ( )
    values = serializers.SerializerMethodField ( )
    meta_type = serializers.SerializerMethodField ( )

    class Meta :
        model = Metadata
        fields = ('name' , 'uuid' , 'type' , 'organisation' , 'meta_type' , 'values' , 'created_at' , 'updated_at')
        read_only_fields = ('id' ,)

    def get_uuid ( self , metadata ) :
        return str ( metadata.uuid ).replace ( '-' , '' )

    def get_type ( self , metadata ) :
        return str ( metadata.type.name )

    def get_meta_type ( self , metadata ) :
        return str ( metadata.type.type )

    def get_values ( self , metadata ) :
        values = None
        if metadata.type.type in [1] :
            values = get_all ( MetadataValue , metadata = metadata )
            values = [item.value for item in values]
            values = deduplicate_string_list ( values )

        if metadata.type.type in [2] :
            values = 'Date'

        if metadata.type.type in [3] :
            values = 'ValueInRange'

        if metadata.type.type in [4] :
            values = 'ValueInDateRange'

        if metadata.type.type in [5] :
            values = get_all ( MetadataValue , metadata = metadata )
            vals = []
            for val in values :
                vals += val.value.split ( '@' )

            values = deduplicate_string_list ( vals )

        return values


class GetMetadataValueSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    name = serializers.SerializerMethodField ( )
    type = serializers.SerializerMethodField ( )
    meta_type = serializers.SerializerMethodField ( )
    value = serializers.SerializerMethodField ( )
    min_value = serializers.SerializerMethodField ( )
    max_value = serializers.SerializerMethodField ( )

    class Meta :
        model = MetadataValue
        fields = ('id' , 'uuid' , 'name' , 'value' , 'min_value' , 'max_value' ,
                  'min_date' , 'max_date' , 'source' , 'type' , 'meta_type')
        read_only_fields = ('id' ,)

    def get_uuid ( self , metadata ) :
        return str ( metadata.uuid ).replace ( '-' , '' )

    def get_name ( self , metadata ) :
        return metadata.metadata.name

    def get_type ( self , metadata ) :
        return metadata.metadata.type.name

    def get_meta_type ( self , metadata ) :
        return metadata.metadata.type.type

    def get_min_value ( self , metadata ) :
        return metadata.min_value

    def get_max_value ( self , metadata ) :
        return metadata.max_value

    def get_value ( self , metadata ) :
        if metadata.metadata.type.type != 5 :
            return metadata.value

        return metadata.value.split ( '@' )
