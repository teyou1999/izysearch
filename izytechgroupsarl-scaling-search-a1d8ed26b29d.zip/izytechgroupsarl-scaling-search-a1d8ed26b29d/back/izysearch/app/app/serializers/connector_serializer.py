from app.serializers.folder_serializer import GetFolderSerializer
from noyau.models import ConnectorType , Connector
from rest_framework import serializers


class GetConnectorTypeSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = ConnectorType
        fields = ('name', 'uuid', 'description')
        read_only_fields = ('id' ,)

    def get_uuid(self, connector_type):
        return str(connector_type.uuid).replace('-', '')


class GetConnectorSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )
    name = serializers.SerializerMethodField ( )
    type = GetConnectorTypeSerializer()
    root_folder = GetFolderSerializer()

    class Meta :
        model = Connector
        fields = ('name', 'uuid', 'organisation', 'last_synchro', 'created_at', 'type', 'root_folder')
        read_only_fields = ('id' ,)

    def get_uuid(self, connector):
        return str(connector.uuid).replace('-', '')

    def get_name(self, connector):
        return connector.type.name
