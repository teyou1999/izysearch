from rest_framework import serializers
from noyau.models import Role

class RoleSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = Role
        fields = ('id' , 'name', 'uuid')
        read_only_fields = ('id' ,)

    def get_uuid(self, role):
        return(str(role.uuid).replace('-', ''))
