import json
from app.serializers.user_serializer import GetUserSerializer
from app.serializers.folder_serializer import GetFolderSerializer
from app.serializers.organisation_serializer import GetOrganisationSerializer
from noyau.models import Query
from rest_framework import serializers

class QuerySerializer ( serializers.ModelSerializer ) :
    # uuid = serializers.SerializerMethodField ( )
    # results = serializers.SerializerMethodField ( )
    # filters = serializers.SerializerMethodField ( )
    organisation = GetOrganisationSerializer()
    folder = GetFolderSerializer()
    user = GetUserSerializer()

    class Meta :
        model = Query
        fields = ('id' ,  'user' , 'organisation' , 'folder' , 'date' , 'query' , 'message',
                  'type', 'results', 'success', 'debug')
        read_only_fields = ('id' ,)

    # def get_uuid(self, account):
    #     return(str(account.uuid).replace('-', ''))

    # def get_results(self, results):
    #     return json.loads(results)

    # def get_filters(self, filters):
    #     return json.loads(filters)
