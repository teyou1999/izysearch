from rest_framework import serializers
from noyau.models import User , Role
from app.serializers.role_serializer import RoleSerializer


class UserSerializer ( serializers.ModelSerializer ) :
    role = serializers.PrimaryKeyRelatedField ( queryset = Role.objects.all ( ) )

    class Meta :
        model = User
        fields = ('username' , 'first_name' , 'password' , 'last_name' , 'email' ,
                  'role' , 'org')
        read_only_fields = ('date_joined' ,)

    def validate ( self , data ) :
        """
        Validate teh file name
        :param data:
        :return:
        """
        if 'role' not in data :
            raise serializers.ValidationError ( "The Role is Required !" )

        if 'username' not in data :
            raise serializers.ValidationError ( "The Username is Required !" )

        return data


class UpdateUserSerializer ( serializers.ModelSerializer ) :
    role = serializers.PrimaryKeyRelatedField ( queryset = Role.objects.all ( ) )

    class Meta :
        model = User
        fields = ('username' , 'first_name' , 'last_name' , 'email' ,
                  'role')
        read_only_fields = ('date_joined' ,)

    def validate ( self , data ) :
        """
        Validate teh file name
        :param data:
        :return:
        """
        if 'role' not in data :
            raise serializers.ValidationError ( "The Role is Required !" )

        if 'username' not in data :
            raise serializers.ValidationError ( "The Username is Required !" )

        return data


class GetUserSerializer ( serializers.ModelSerializer ) :
    role = RoleSerializer ( )
    uuid = serializers.SerializerMethodField ( )
    uuid = serializers.SerializerMethodField ( )
    org = serializers.SerializerMethodField ( )

    class Meta :
        model = User
        fields = ('id' , 'uuid' , 'username' , 'role' , 'org' , 'first_name' , 'last_name' , 'email')
        read_only_fields = ('id' ,)

    def get_uuid ( self , account ) :
        return str ( account.uuid ).replace ( '-' , '' )

    def get_org ( self , account ) :
        return str ( account.org ).replace ( '-' , '' )
