from app.repositories.document_querier_helper import get_server_path
from noyau.models import Page
from rest_framework import serializers


class GetPageSerializer ( serializers.ModelSerializer ) :
    img = serializers.SerializerMethodField ( )
    url = serializers.SerializerMethodField ( )
    uuid = serializers.SerializerMethodField ( )
    file_temp_pdf = serializers.SerializerMethodField ( )
    raw_file = serializers.SerializerMethodField ( )
    thumbnail = serializers.SerializerMethodField ( )
    score = serializers.SerializerMethodField ( )
    folder_name = serializers.SerializerMethodField ( )
    file_name = serializers.SerializerMethodField ( )

    class Meta :
        model = Page
        fields = ('id' , 'text' , 'title' , 'url' , 'page' , 'img' , 'thumbnail' , 'file_temp_pdf' ,
                  'raw_file' , 'created_at' , 'updated_at' , 'uuid' , 'score' , 'file_name' ,
                  'folder_name')

        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'file')

    def get_img ( self , page ) :
        return get_server_path ( str ( page.image.path ) )

    def get_url ( self , page ) :
        return get_server_path ( str ( page.url ) )

    def get_file_temp_pdf ( self , page ) :
        return get_server_path ( str ( page.file.temp_pdf ) )

    def get_raw_file ( self , page ) :
        return get_server_path ( str ( page.file.path ) )

    def get_thumbnail ( self , page ) :
        return get_server_path ( str ( page.image.path ) )

    def get_score ( self , page ) :
        return page.score

    def get_folder_name ( self , page ) :
        return page.file.folder.name

    def get_file_name ( self , page ) :
        return page.file.name

    def get_uuid ( self , page ) :
        return (str ( page.uuid ).replace ( '-' , '' ))
