import os
from app.repositories.document_querier_helper import get_server_path
from app.serializers.metadata_serializer import GetMetadataValueSerializer
from noyau.repositories.db import get_one_with_params , get_all
from rest_framework import serializers
from noyau.models import File , ConnectorFolder , Connector , MetadataValue
from noyau.utils.file_utils import get_extension
from noyau.utils.folder_utils import escaped_file_or_folder_name
from noyau.utils.renaming_utils import get_file_correct_name
from noyau.utils.file_utils import smallFileSize , exceededFileSize
from izysearch.settings import FILE_MAX_SIZE , PROCESSED_FORMATS , FILE_MIN_SIZE , COMPRESS_FORMATS
from noyau.utils.folder_utils import valid_file_or_folder


class RetrieveFileSerializer ( serializers.ModelSerializer ) :
    path = serializers.SerializerMethodField ( )
    metadata = serializers.SerializerMethodField ( )
    temp_pdf = serializers.SerializerMethodField ( )
    text = serializers.SerializerMethodField ( )
    image = serializers.SerializerMethodField ( )
    folder_name = serializers.SerializerMethodField ( )
    score = serializers.SerializerMethodField ( )
    uuid = serializers.SerializerMethodField ( )
    organisation = serializers.SerializerMethodField ( )
    folder = serializers.SerializerMethodField ( )

    class Meta :
        model = File
        fields = (
        'id' , 'uuid' , 'name' , 'path' , 'extension' , 'display_name' , 'created_at' , 'temp_pdf' , 'metadata' ,
        'updated_at' , 'folder' , 'organisation' , 'is_analyzed' , 'is_indexed' , 'size' ,
        'last_analyzed_date' , 'last_index_date' , 'nb_pages' , 'text' , 'image' , 'folder_name' , 'score')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'extension' ,
                            'organisation')

    def get_path ( self , file ) :
        return get_server_path ( str ( file.path ) )

    def get_image ( self , file ) :
        return get_server_path ( str ( file.image ) )

    def get_temp_pdf ( self , file ) :
        return get_server_path ( str ( file.temp_pdf ) )

    def get_text ( self , file ) :
        return file.text

    def get_folder_name ( self , file ) :
        return file.folder_name

    def get_organisation ( self , file ) :
        return str ( file.organisation.uuid ).replace ( '-' , '' )

    def get_score ( self , file ) :
        return file.score

    def get_folder ( self , file ) :
        return str ( file.folder.uuid ).replace ( '-' , '' )

    def get_uuid ( self , file ) :
        return str ( file.uuid ).replace ( '-' , '' )

    def get_metadata ( self , file ) :
        metadata = get_all ( MetadataValue , file = file )
        return GetMetadataValueSerializer ( metadata , many = True ).data


class GetFileSerializer ( serializers.ModelSerializer ) :
    path = serializers.SerializerMethodField ( )
    temp_pdf = serializers.SerializerMethodField ( )
    uuid = serializers.SerializerMethodField ( )
    metadata = serializers.SerializerMethodField ( )

    class Meta :
        model = File
        fields = ('id' , 'uuid' , 'name' , 'path' , 'extension' , 'display_name' , 'created_at' , 'temp_pdf' ,
                  'updated_at' , 'folder' , 'organisation' , 'is_analyzed' , 'is_indexed' ,
                  'last_analyzed_date' , 'last_index_date' , 'nb_pages' , 'size' , 'metadata')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'extension' ,
                            'organisation')

    def get_uuid ( self , file ) :
        return (str ( file.uuid ).replace ( '-' , '' ))

    def get_path ( self , file ) :
        return get_server_path ( str ( file.path ) )

    def get_temp_pdf ( self , file ) :
        return get_server_path ( str ( file.temp_pdf ) )

    def get_metadata ( self , file ) :
        metadata = get_all ( MetadataValue , file = file )
        return GetMetadataValueSerializer ( metadata , many = True ).data


class FileSerializer ( serializers.ModelSerializer ) :
    uuid = serializers.SerializerMethodField ( )

    class Meta :
        model = File
        fields = ('id' , 'uuid' , 'name' , 'path' , 'extension' , 'display_name' , 'created_at' ,
                  'updated_at' , 'folder' , 'organisation')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'extension' ,
                            'organisation')

    def get_uuid ( self , file ) :
        if hasattr ( file , "uuid" ) :
            return str ( file.uuid ).replace ( '-' , '' )

    def validate ( self , data ) :
        connector = get_one_with_params ( Connector , root_folder = data['folder'] )

        if connector :
            raise serializers.ValidationError ( 'You cannot Upload in A Connector Folder' )
        f_connector = get_one_with_params ( ConnectorFolder , folder = data['folder'] )

        if f_connector :
            raise serializers.ValidationError ( 'You cannot Upload in An External Folder' )

        validated_data = validate_file ( data )
        path = data['folder'].path + '/' + escaped_file_or_folder_name ( str ( data['path'] ) )

        file = File.objects.filter ( path = path )
        if len ( file ) > 0 :
            raise serializers.ValidationError ( 'The file already exists, Please Delete it first !' )
        ext = get_extension ( str ( validated_data['path'] ) )
        if ext.lower ( ) not in PROCESSED_FORMATS :
            raise serializers.ValidationError ( 'The file must be one of the allowed format !' )

        return validated_data


class ZipFileSerializer ( serializers.ModelSerializer ) :
    class Meta :
        model = File
        fields = ('uuid' , 'name' , 'path' , 'display_name' , 'extension' , 'created_at' ,
                  'updated_at' , 'folder' , 'organisation')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'extension' ,
                            'organisation')

    def validate ( self , data ) :
        validated_data = validate_file ( data )

        # Delete all the previous upload of this file
        path = os.path.join ( data['folder'].path , str ( data['path'] ) )
        path = get_file_correct_name ( path )
        files = File.objects.filter ( path = path )
        for file in files :
            file.delete ( )

        ext = get_extension ( str ( validated_data['path'] ) )
        if ext not in COMPRESS_FORMATS :
            raise serializers.ValidationError ( 'The file must be a zip file !' )

        if not smallFileSize ( data['path'] ) :
            raise serializers.ValidationError ( 'The file size must be at least ' + str ( FILE_MIN_SIZE ) + ' KB !' )

        return validated_data


def validate_file ( data ) :
    """
    A Generic function to validate data related to a File record
    :param data:
    :return:
    """
    if data['path'] is None or data['path'] == "" :
        raise serializers.ValidationError ( 'The file name cannot be empty !' )

    if not exceededFileSize ( data['path'] ) :
        raise serializers.ValidationError ( 'The file size must be least than ' + str ( FILE_MAX_SIZE ) + ' MB !' )

    return data


class UpdateFileSerializer ( serializers.ModelSerializer ) :
    class Meta :
        model = File
        fields = ('id' , 'uuid' , 'name' , 'path' , 'extension' , 'created_at' ,
                  'display_name' , 'updated_at' , 'folder' , 'organisation')
        read_only_fields = ('id' , 'uuid' , 'created_at' , 'updated_at' , 'extension' ,
                            'organisation')

    def validate ( self , data ) :
        if 'display_name' in data :
            if not valid_file_or_folder ( str ( data['display_name'] ) ) :
                raise serializers.ValidationError ( "The display name must be Unix compliant, rename before upload !" )
            if data['display_name'] == "" :
                raise serializers.ValidationError ( 'The display name cannot be empty !' )
        return data
