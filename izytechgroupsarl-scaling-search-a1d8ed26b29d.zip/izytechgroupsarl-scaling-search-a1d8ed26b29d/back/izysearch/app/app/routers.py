from rest_framework import routers
from app.api.admin.folder_controller import CreateFolder
from app.api.admin.file_controller import UploadZip, UploadFile

router = routers.DefaultRouter()
router.register(r'^api/organisation/folder/store', CreateFolder)
router.register(r'^api/organisation/folder/upload', UploadZip)
router.register(r'^api/organisation/files/upload', UploadFile)
