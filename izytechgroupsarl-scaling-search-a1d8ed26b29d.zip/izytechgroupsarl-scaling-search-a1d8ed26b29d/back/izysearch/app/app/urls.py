from app.api.admin import index_controller , operation_controller , connector_controller , metadata_controller , \
    background_controller , dashboard_controller , user_controller , folder_controller
from app.api.admin.metadata_controller import MetadataTypeList , MetadataCreateView , MetadataDeleteView , \
    MetadataListView , MetadataShowView , MetadataUpdateView
from app.api.search import file_filtering_views , chunk_filtering_views , query_controller
from app.api.search.folder_filtering_views import QueriableFolders
from app.api.super_admin.formula_controller import FormulaCreateView , FormulaListView , FormulaShowView , \
    FormulaUpdateView , FormulaDeleteView
from app.api.super_admin.subscription_controller import SubscriptionUpdateView
from django.conf.urls import url
from app.api.admin.folder_controller import FolderList, FolderUpdate, ShowFolders, DeleteFolder, OrgRootFolder, FolderTree
from app.api.auth import login_controller
from app.api.admin.file_controller import ShowFile, FileUpdate, FileDelete
from app.api.admin.role_controller import RoleList
from app.api.super_admin import organisation_controller
from app.api.super_admin import subscription_controller
from app.api.admin.user_controller import UserCreateView, UserListView, UserShowView, UserUpdateView, UserDeleteView, SelfView
from django.conf.urls.static import static
from izysearch.settings import MEDIA_URL, MEDIA_ROOT

urlpatterns = [
    # Authentication Route
    url(r'^login', login_controller.login, name="authentication"),

    # Role Routes
    url(r'^roles/list', RoleList.as_view(), name='list_roles'),

    # Folder Routes
    url(r'^api/organisation/folder/list', FolderList.as_view(), name='list_folders'),
    url(r'^api/organisation/root$', OrgRootFolder.as_view(), name='root_folder'),
    url(r'^api/organisation/folder/(?P<uuid>[0-9a-z]+)/show$', ShowFolders.as_view(), name='show_folders'),
    url(r'^api/organisation/folder/(?P<uuid>[0-9a-z]+)/delete$', DeleteFolder.as_view(), name='delete_folder'),
    url(r'^api/organisation/folder/(?P<uuid>[0-9a-z]+)/directory', FolderTree.as_view(), name='folder_tree'),
    url(r'^api/organisation/folder/(?P<uuid>[0-9a-z]+)/edit$', FolderUpdate.as_view(), name='update_folder'),
    url(r'^api/organisation/folder/(?P<uuid>[0-9a-z]+)/indexing', folder_controller.change_indexing_status, name='foder_indexing'),

    # File Routes
    url(r'^api/organisation/files/(?P<uuid>[0-9a-z]+)/show$', ShowFile.as_view(), name='show_files'),
    url(r'^api/organisation/files/(?P<uuid>[0-9a-z]+)/edit$', FileUpdate.as_view(), name='update_files'),
    url(r'^api/organisation/files/(?P<uuid>[0-9a-z]+)/delete$', FileDelete.as_view(), name='delete_files'),

    # Account Routes
    url(r'^api/accounts/store$', UserCreateView.as_view(), name="create_account"),
    url(r'^api/accounts/list$', UserListView.as_view(), name="list_account"),
    url(r'^api/accounts/(?P<pk>[0-9]+)/show$', UserShowView.as_view(), name="show_account"),
    url(r'^api/accounts/(?P<pk>[0-9]+)/update$', UserUpdateView.as_view(), name="update_account"),
    url(r'^api/accounts/(?P<pk>[0-9]+)/delete$', UserDeleteView.as_view(), name="delete_account"),
    url(r'^api/accounts/me', SelfView.as_view(), name="get_self"),
    url(r'^api/accounts/reset/password' , user_controller.reset_password , name= "reset_password" ),

    # Organisation Routes
    url(r'^api/admin/organisations/store$' , organisation_controller.store , name= "create_org"),
    url(r'^api/admin/organisations/index$' , organisation_controller.index , name= "list_org"),
    url(r'^api/admin/organisations/(?P<pk>[0-9]+)/show$' , organisation_controller.show , name= "show_org"),
    url(r'^api/admin/organisations/(?P<pk>[0-9]+)/update' , organisation_controller.update , name= "update_org"),
    url(r'^api/admin/organisations/(?P<pk>[0-9]+)/delete' , organisation_controller.delete , name= "delete_org"),
    url(r'^api/admin/organisations/statistics' , dashboard_controller.statistics , name= "stats_org"),

    # Subscription Formula Routes
    url(r'^api/admin/formula/store$', FormulaCreateView.as_view(), name="create_formula"),
    url(r'^api/admin/formula/list$', FormulaListView.as_view(), name="list_formula"),
    url(r'^api/admin/formula/(?P<uuid>[0-9a-z]+)/show$', FormulaShowView.as_view(), name="show_formula"),
    url(r'^api/admin/formula/(?P<uuid>[0-9a-z]+)/update$', FormulaUpdateView.as_view(), name="update_formula"),
    url(r'^api/admin/formula/(?P<uuid>[0-9a-z]+)/delete$', FormulaDeleteView.as_view(), name="delete_formula"),
    url(r'^api/admin/subscription/(?P<uuid>[0-9a-z]+)/update$', SubscriptionUpdateView.as_view(), name="update_subscription"),

    # Super Admin Subscription
    url(r'^api/organisation/subscriptions/(?P<uuid>[0-9a-z]+)/renew', subscription_controller.renew_subscription, name="renew_subscription"),
    url(r'^api/organisation/subscriptions/(?P<uuid>[0-9a-z]+)/history', subscription_controller.list_organisation_subscription_historic, name='organisation_history'),
    url(r'^api/organisation/subscriptions/(?P<uuid>[0-9a-z]+)/current', subscription_controller.current_organisation_subscription, name='current_subscription'),
    url(r'^api/organisation/subscriptions/(?P<uuid>[0-9a-z]+)/change', subscription_controller.change_subscription, name="change_subscription"),
    url(r'^api/organisation/subscriptions/(?P<uuid>[0-9a-z]+)/formula', subscription_controller.get_possible_formula, name="possible_formula"),

    # Indexation
    url(r'^api/organisation/folder/(?P<folder_uuid>[0-9a-z]+)/index', index_controller.index_folder, name='index_folder'),

    # Information Retrieval
    url(r'^api/organisation/documents/filter', file_filtering_views.filter_docs, name='doc_filtering'),
    url(r'^api/organisation/pages/filter', chunk_filtering_views.filter_pages, name='page_filtering'),
    url(r'^api/organisation/folders/searchable', QueriableFolders.as_view(), name='searchable_folder'),

    # Get query Details
    url(r'^api/organisation/query/details', query_controller.index, name='query_details'),

    # Connectors
    url(r'^api/organisation/connector/types', connector_controller.list_connector_types, name='connector_types'),
    url(r'^api/organisation/connector/list', connector_controller.list_organisation_connectors, name='organisation_connectors'),
    url(r'^api/organisation/connector/delete', connector_controller.destroy_connector, name='connector_destruction'),
    url(r'^api/organisation/connector/gdrive/create', connector_controller.create_googledrive_connector, name='create_gdrive_connector'),
    url(r'^api/organisation/connector/gdrive/folders', connector_controller.list_organisation_gdrive_connector_folders, name='all_gdrive_folders'),
    url(r'^api/organisation/connector/gdrive/synchronize/folders', connector_controller.synchronize_gdrive_folders, name='synhcronize_gdrive_folders'),
    url(r'^api/organisation/connector/synchronized/gdrive/folders', connector_controller.get_synchronize_gdrive_folders, name='synhcronized_gdrive_folders'),
    url(r'^api/organisation/connector/gdrive/desynchronize/folders', connector_controller.desynchronize_gdrive_folders, name='desynhcronize_gdrive_folders'),

    # Metadata
    url(r'^api/organisation/metadata/store$', MetadataCreateView.as_view(), name="create_metadata"),
    url(r'^api/organisation/metadata/list$', MetadataListView.as_view(), name="list_metadata"),
    url(r'^api/organisation/metadata/(?P<uuid>[0-9a-z]+)/show$', MetadataShowView.as_view(), name="show_metadata"),
    url(r'^api/organisation/metadata/(?P<uuid>[0-9a-z]+)/update$', MetadataUpdateView.as_view(), name="update_metadata"),
    url(r'^api/organisation/metadata/(?P<uuid>[0-9a-z]+)/delete$', MetadataDeleteView.as_view(), name="delete_metadata"),
    url(r'^api/organisation/metadata/types', MetadataTypeList.as_view(), name='metadata_types'),
    url(r'^api/organisation/metadata/save', metadata_controller.create_file_metadata, name='metadata_save'),
    url(r'^api/organisation/metadata/remove', metadata_controller.remove_metadata_file, name='metadata_removal'),

    # Update Memory
    url(r'^update/memory', background_controller.update_memory, name='update_memory_after_indexing'),
    url(r'^gdrive/auth', background_controller.google_drive_oauth2, name='gdrive_oauth'),

    # Operation Progress
    url(r'^api/organisation/operations/(?P<op_id>[0-9]+)/status$', operation_controller.get_operation_status,
        name='operation_status'),

] + static(MEDIA_URL, document_root=MEDIA_ROOT)

