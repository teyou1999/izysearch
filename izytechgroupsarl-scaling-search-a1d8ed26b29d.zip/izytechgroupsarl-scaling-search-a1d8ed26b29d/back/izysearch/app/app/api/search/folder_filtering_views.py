from app.repositories.folder_querier_helper import process_duplicate_names
from app.serializers.folder_serializer import GetFolderSerializer
from noyau.models import Folder
from noyau.repositories.db import get_all
from noyau.utils.user_utils import get_connected_user_organisation , get_connected_user
from rest_framework import generics
from izysearch.settings import SUPER_ADMIN_ROLE


class QueriableFolders(generics.ListAPIView):
    """
     Get a list of folders that the user has access to. \
    """
    serializer_class = GetFolderSerializer

    def get_queryset(self):

        account = get_connected_user(
            self.request.META.get('HTTP_AUTHORIZATION'))
        org = get_connected_user_organisation(
            self.request.META.get('HTTP_AUTHORIZATION'))

        if account.role.id == SUPER_ADMIN_ROLE:
            folder_list = get_all(Folder).order_by('-nb_files')
        else:
            folder_list = get_all(Folder, organisation=org).order_by('-nb_files')

        folder_list = [f for f in folder_list if f.nb_files != 0 and f.is_indexed]
        return process_duplicate_names(folder_list)


