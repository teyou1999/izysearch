import json

from app.repositories.document_querier_helper import construct_es_params , \
    retrieve_filtered_paginate_pages , retrieve_filtered_paginate_docs , add_infos
from app.repositories.index_loading_helper import load_indexes
from app.serializers.file_serializer import RetrieveFileSerializer
from app.serializers.page_serializer import GetPageSerializer
from django.utils.timezone import get_current_timezone
from noyau import Memory
from noyau.models import Folder , Page , Subscription , File
from noyau.models.query import Query
from datetime import datetime
from noyau.repositories.db import get_one_with_params , get_all , get_objects_in_order
from noyau.repositories.folder_helper import get_children_folder
from noyau.utils.organisation_utils import get_organisation_root_folder
from noyau.utils.user_utils import get_connected_user_organisation, get_connected_user
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from izysearch.settings import NB_PAGES, SUPER_ADMIN_ROLE, PAGINATE_SIZE, DEFAULT_OFFSET


@api_view(['POST'])
def filter_pages(request):
    """

    :param request:
    :return:
    """
    # If First query, Load the indexes
    m = Memory.getInstance()
    if not list(m.indexes.keys()):
        load_indexes()

    token = request.META.get('HTTP_AUTHORIZATION', None)
    org = get_connected_user_organisation(token)
    subscription = get_one_with_params(Subscription, organisation=org)
    account = get_connected_user(request.META.get ( 'HTTP_AUTHORIZATION' ) )

    query_log = Query(
        user = account,
        organisation = org,
        date = datetime.now(tz=get_current_timezone()),
        type = 'Page'
    )

    if account.role.id != SUPER_ADMIN_ROLE:

        if not subscription:
            query_log.message = 'A Subscription is required for your organisation'
            query_log.save()
            return Response(
                    {'errors': 'A Subscription is required for your organisation'},
                    status=status.HTTP_401_UNAUTHORIZED
                )

        if subscription.current_queries >= subscription.max_queries:
            query_log.message = 'Your Organisation Query Quota is reached !'
            query_log.save()
            return Response(
                    {'errors': 'Your Organisation Query Quota is reached !'},
                    status=status.HTTP_401_UNAUTHORIZED
                )

    folder = get_organisation_root_folder(org)

    is_super_admin = False
    if 'folder' in request.data and request.data['folder'] != []:
        folders = get_all(Folder, uuid__in=request.data['folder'])
        if not folders and account.role.id != 1:
            query_log.message = 'The required folders do not exist'
            query_log.save()
            return Response(
                {'errors': 'The required folders do not exist'},
                status=status.HTTP_404_NOT_FOUND
            )
        else:
            all_folders = []
            for f in folders:
                all_folders.append(f)
                all_folders += get_children_folder(f)

            folder_items = [folder.id for folder in all_folders if folder.is_indexed]
            is_super_admin = account.role.id == 1
    else:
        if account.role.id == 1:
            sub_folders = get_all(Folder)
            folder_items = [folder.id for folder in sub_folders if folder.is_indexed]
            is_super_admin = True
        else:
            sub_folders = get_children_folder(folder)
            folder_items = [folder.id for folder in sub_folders if folder.is_indexed]
            folder_items.append(folder.id)
    nb_pages = NB_PAGES
    query_log.folder = folder
    # Build the params for the query
    params = construct_es_params(folder, request)
    query_log.filters = params

    if 'query' in params:
        query_log.query = params['query'].lower()
    else:
        query_log.query = ''

    # Apply the filter
    pages = retrieve_filtered_paginate_pages(params, nb_pages, folder_items, is_super_admin)
    page_ids = []
    scores = []
    for page in pages:
        page_ids.append(page['_source']['page_id'])
        scores.append(page['_score'])

    page_objects = get_objects_in_order(Page, field='id', values=page_ids)

    for page, score in zip(page_objects, scores):
        page.score = score

    if max(scores) == 1.0:
        page_objects = []
        query_log.results = "[]"
        query_log.success = True
        query_log.save()

    retrieved_pages = []

    for page in page_objects:
        if page.score > 1.0:
            retrieved_pages.append(page)

    if account.role.id != SUPER_ADMIN_ROLE:
        subscription.current_queries += 1
        subscription.save()

    pages = GetPageSerializer( retrieved_pages , many = True ).data

    docs_size = PAGINATE_SIZE
    offset = DEFAULT_OFFSET

    docs, scores, nb_matching_docs = retrieve_filtered_paginate_docs(params, docs_size, offset, folder_items, is_super_admin)

    if not docs:
        query_log.results = "[]"
        query_log.success = True
        query_log.save()
        return Response([], status=status.HTTP_200_OK)

    file_ids = [doc['file_id'] for doc in docs]
    docs = get_objects_in_order(File, field='id', values=file_ids)
    docs = add_infos(docs, params, scores)
    docs = RetrieveFileSerializer( docs , many = True ).data

    if account.debug:
        query_log.results = json.dumps(pages, ensure_ascii = 'utf8')
        query_log.debug = True
    else:
        query_log.results = "[]"

    query_log.message = 'Successful Query'
    query_log.success = True
    query_log.save()

    response = {
        'pages': pages,
        'docs': docs
    }
    return Response(response, status=status.HTTP_200_OK)
