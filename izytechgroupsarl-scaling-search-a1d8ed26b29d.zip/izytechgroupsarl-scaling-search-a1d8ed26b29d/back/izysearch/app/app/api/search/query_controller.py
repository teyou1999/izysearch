from app.serializers.query_serializer import QuerySerializer
from django.db.models.query_utils import Q
from noyau.models import Organisation, User, Query, Folder
from noyau.repositories.db import get_one_with_params
from noyau.utils.user_utils import get_connected_user_organisation , get_connected_user
from rest_framework.decorators import api_view
from rest_framework.response import Response
from izysearch.settings import ADMIN_IDS


@api_view ( ['GET'] )
def index ( request ) :
    """
    Retrieve all Query info,  some criteria may be specified

    :arg
      - user
      - organisation
      - folder
      - query
      - start_date
      - end_date
    :param request:
    :return:
    """
    token = request.META.get('HTTP_AUTHORIZATION', None)
    org = get_connected_user_organisation(token)
    account = get_connected_user(request.META.get ( 'HTTP_AUTHORIZATION' ) )
    q = Q()
    size = 20
    page = 1

    if 'page' in request.GET:
        page = int(request.GET['page'])

    if 'size' in request.GET:
        size = int(request.GET['size'])

    if 'organisation' in request.GET :
        organisation = get_one_with_params(Organisation, uuid=request.GET['organisation'])
        if organisation:
            q &= Q(organisation=organisation)

    else:
        q &= Q(organisation=org)

    if 'user' in request.GET :
        user = get_one_with_params(User, uuid=request.GET['user'])
        if user:
            q &= Q(user=user)
    else:
        # If not admin user, juste show his queries.
        if account.role.id not in ADMIN_IDS:
            q &= Q(user=account)

    if 'folder' in request.GET:
        folder = get_one_with_params(Folder, uuid=request.GET['folder'])
        if folder:
            q &= Q(folder=folder)

    if 'query' in request.GET:
          q &= Q(query__icontains=str(request.GET['query']).lower())

    start = (page-1)*size
    queries = Query.objects.filter(q)

    if queries:
        queries = queries.order_by("-id")[start: start+size]

    serializer = QuerySerializer ( queries , many = True )
    return Response ( serializer.data )
