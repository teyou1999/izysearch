import json

from app.repositories.document_querier_helper import construct_es_params , retrieve_filtered_paginate_docs , add_infos
from app.serializers.file_serializer import RetrieveFileSerializer
from django.utils.timezone import get_current_timezone
from noyau.models import Folder , File
from datetime import datetime
from noyau.models.query import Query
from noyau.repositories.folder_helper import get_children_folder
from noyau.repositories.db import get_one_with_params , get_all , get_objects_in_order
from noyau.utils.organisation_utils import get_organisation_root_folder
from noyau.utils.user_utils import get_connected_user_organisation , get_connected_user
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from izysearch.settings import PAGINATE_SIZE , DEFAULT_OFFSET


@api_view ( ['POST'] )
def filter_docs ( request ) :
    """
    Filter Documents based on filter and eventually a query as parameter.
    The returned list is paginated, the PAGINATE_SIZE is a param in the setting.

    Query Example :
    {
	"query": "",
	"metadata": [
            {
            "type":1,
            "name": "location",
            "selected": "Box 528/78"
            }
        ]
    }

    :param request: it contains all the filters, the request and the offset and the size
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    org = get_connected_user_organisation ( token )
    folder = get_organisation_root_folder ( org )

    account = get_connected_user ( request.META.get ( 'HTTP_AUTHORIZATION' ) )
    is_super_admin = False

    query_log = Query (
        user = account ,
        organisation = org ,
        date = datetime.now ( tz = get_current_timezone ( ) ) ,
        type = 'Document'
    )
    if 'folder' in request.data and request.data['folder'] != [] :
        folders = get_all ( Folder , uuid__in = request.data['folder'] )
        if not folders and account.role.id != 1 :
            query_log.message = 'The required folders do not exist'
            query_log.save ( )
            return Response (
                { 'errors' : 'The required folders do not exist' } ,
                status = status.HTTP_404_NOT_FOUND
            )
        else :
            all_folders = []
            for f in folders :
                all_folders.append ( f )
                all_folders += get_children_folder ( f )

            folder_items = [folder.id for folder in all_folders if folder.is_indexed]
            is_super_admin = account.role.id == 1
    else :
        if account.role.id == 1 :
            sub_folders = get_all ( Folder )
            folder_items = [folder.id for folder in sub_folders if folder.is_indexed]
            is_super_admin = True
        else :
            sub_folders = get_children_folder ( folder )
            folder_items = [folder.id for folder in sub_folders if folder.is_indexed]
            folder_items.append ( folder.id )

    docs_size = PAGINATE_SIZE
    if 'size' in request.data :
        docs_size = (int) ( request.data['size'] )

    offset = DEFAULT_OFFSET
    if 'offset' in request.data :
        offset = request.data['offset']

    # Build the params for the query
    params = construct_es_params ( folder , request )
    query_log.folder = folder
    query_log.filters = params

    if 'query' in params :
        query_log.query = params['query'].lower ( )
    else :
        query_log.query = ''
    # Apply the filter
    docs , scores , nb_matching_docs = retrieve_filtered_paginate_docs ( params , docs_size , offset , folder_items ,
                                                                         is_super_admin )

    if not docs :
        query_log.results = "[]"
        query_log.success = True
        query_log.save ( )
        return Response ( [] , status = status.HTTP_200_OK )

    file_ids = [doc['file_id'] for doc in docs]
    docs = get_objects_in_order ( File , field = 'id' , values = file_ids )
    docs = add_infos ( docs , params , scores )
    docs = RetrieveFileSerializer ( docs , many = True ).data

    if account.debug :
        query_log.results = json.dumps ( docs , ensure_ascii = 'utf8' )
        query_log.debug = True
    else :
        query_log.results = "[]"

    query_log.message = 'Successful Query'
    query_log.success = True
    query_log.save ( )
    return Response ( {
        'docs' : docs ,
        'total' : nb_matching_docs ,
        'offset' : offset ,
        'size' : docs_size
    } , status = status.HTTP_200_OK )
