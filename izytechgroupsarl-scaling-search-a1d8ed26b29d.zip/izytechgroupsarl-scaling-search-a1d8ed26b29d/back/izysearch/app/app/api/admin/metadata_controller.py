import traceback

from app.repositories.indexation_helper import update_file_metadata
from app.serializers.file_serializer import GetFileSerializer
from app.serializers.metadata_serializer import MetadataTypeSerializer , MetadataSerializer , GetMetadataSerializer
from django.db.models.query_utils import Q
from django.test.client import RequestFactory
from noyau.models import MetadataType , File , Metadata , Organisation
from noyau.models.metadata import MetadataValue
from noyau.repositories.db import get_all , get_one_with_params
from noyau.utils.user_utils import get_connected_user , get_connected_user_organisation
from rest_framework import generics , status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from dateutil import parser


class MetadataTypeList ( generics.ListAPIView ) :
    """
    GET all the metadata in the database. <br/>
    """
    serializer_class = MetadataTypeSerializer

    def get_queryset ( self ) :
        return get_all ( MetadataType )


class MetadataCreateView ( generics.CreateAPIView ) :
    """
    Create a New Metadata for an organisation. <br/>
    """
    queryset = Metadata.objects.all ( )
    serializer_class = MetadataSerializer

    def create ( self , request , *args , **kwargs ) :
        serializer = MetadataSerializer ( data = request.data )
        if serializer.is_valid ( raise_exception = True ) :
            # The name must be unique for an organisation
            existing_name = get_one_with_params ( Metadata , organisation = request.data['organisation'] ,
                                                  name = request.data['name'] )

            if existing_name :
                return Response (
                    { "errors" : "A metadata with this name already exists" } ,
                    status = status.HTTP_400_BAD_REQUEST
                )
            metadata = self.perform_create ( serializer )

            return Response ( GetMetadataSerializer ( metadata ).data ,
                              status = status.HTTP_201_CREATED )
        else :
            return Response (
                { "errors" : "Please Check the parameters" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    def perform_create ( self , serializer ) :
        instance = serializer.save ( )
        instance.save ( )
        return instance


class MetadataListView ( generics.ListAPIView ) :
    """
    Get all the Metadata of an Organisation. <br/>
    """
    queryset = Metadata.objects.all ( )
    serializer_class = GetMetadataSerializer

    def get_queryset ( self ) :
        page = 1
        size = 30
        q = Q ( )
        if 'page' in self.request.GET :
            page = int ( self.request.GET['page'] )

        if 'size' in self.request.GET :
            size = int ( self.request.GET['size'] )

        start = (page - 1) * size

        if 'organisation' in self.request.GET :
            organisation = get_one_with_params ( Organisation , uuid = self.request.GET['organisation'] )
        else :
            organisation = get_connected_user_organisation ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )

        if organisation :
            q &= Q ( organisation = organisation )

        if "type" in self.request.GET :
            print ( f"Type UUID : {self.request.GET['type']}" )
            meta_type = get_one_with_params ( MetadataType , uuid = self.request.GET["type"] )

            if meta_type :
                q &= Q ( type = meta_type )

        if 'query' in self.request.GET :
            q &= Q ( query__icontains = str ( self.request.GET['query'] ).lower ( ) )

        metadata = Metadata.objects.filter ( q )

        if metadata :
            metadata = metadata.order_by ( 'id' )[start : start + size]
        return metadata


class MetadataDeleteView ( generics.DestroyAPIView ) :
    """
    Delete a Metadata. <br/>
    """
    queryset = Metadata.objects.all ( )
    serializer_class = GetMetadataSerializer
    lookup_field = 'uuid'


class MetadataShowView ( generics.RetrieveAPIView ) :
    """
    Get a given Metadata using its uuid. <br/>
    """
    queryset = Metadata.objects.all ( )
    serializer_class = GetMetadataSerializer
    lookup_field = 'uuid'


class MetadataUpdateView ( generics.RetrieveUpdateAPIView ) :
    """
    Update a metadata information. <br/>
    """
    queryset = Metadata.objects.all ( )
    serializer_class = GetMetadataSerializer
    lookup_field = 'uuid'

    def put ( self , request , *args , **kwargs ) :
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        return self.partial_update ( data , *args , **kwargs )


@api_view ( ['POST'] )
def create_file_metadata ( request ) :
    """
    Create Metadata for file

    Query Body
    {
	"file":"6d2bffdf73b04cb08a32ecf2c42c7fa0",
	"metadata": [
		{
			"id": metadata_uuid,
			"value": "2020-05-20"
		},
		{
			"id": metadata_uuid,
			"value": ["SSSK", "ddsdsd"]
		}
		]
    }
    :param request:
    :return:
    """
    if 'file' not in request.data :
        return Response (
            { "errors" : "The File is Required" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    file = get_one_with_params ( File , uuid = request.data['file'] )
    if not file :
        return Response (
            { "errors" : "The File required file does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if 'metadata' not in request.data :
        return Response (
            { "errors" : "Added Metadata are required" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    if not isinstance ( request.data['metadata'] , list ) :
        return Response (
            { "errors" : "Metadata should be a list" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    try :
        for metadata_entry in request.data['metadata'] :
            metadata = get_one_with_params ( Metadata , uuid = metadata_entry['id'] )

            if not metadata :
                continue

            if metadata.organisation.id != file.organisation.id :
                return Response (
                    { "errors" : "You cannot Set Metadata of another Organisation" } ,
                    status = status.HTTP_401_UNAUTHORIZED
                )
            # Delete Existing Metadata on this file with the same name and the same type
            existing_metadata_values = get_all ( MetadataValue , metadata = metadata , file = file )
            if existing_metadata_values :
                existing_metadata_values.delete ( )

            metadata_value = MetadataValue (
                file = file ,
                metadata = metadata
            )

            # Base Metadata
            if metadata.type.type == 1 :
                metadata_value.value = str ( metadata_entry['value'] )

            # Date Metadata
            if metadata.type.type == 2 :
                metadata_value.min_date = parser.isoparse ( str ( metadata_entry['value'] ) )

            # Base Interval Metadata
            if metadata.type.type == 3 :
                metadata_value.min_value = float ( metadata_entry['value'] )
                if 'sup' not in metadata_entry :
                    metadata_value.max_value = 999999999999999.258899
                else :
                    metadata_value.max_value = float ( metadata_entry['sup'] )

            # Date Interval Metadata
            if metadata.type.type == 4 :
                metadata_value.min_date = parser.isoparse ( str ( metadata_entry['value'] ) )
                if 'sup' not in metadata_entry :
                    metadata_value.max_date = parser.isoparse ( '2085-01-01' )
                else :
                    metadata_value.max_date = parser.isoparse ( str ( metadata_entry['sup'] ) )

            # Base List
            if metadata.type.type == 5 :
                if not isinstance ( metadata_entry['value'] , list ) :
                    continue
                metadata_value.value = "@".join ( metadata_entry['value'] )

            metadata_value.save ( )

        # Update the file Metadata in index
        update_file_metadata ( file )

        return Response ( GetFileSerializer ( file ).data )
    except Exception as err :
        traceback.print_exc ( )
        return Response (
            { "errors" : "An Error Occurs during metadata creation" } ,
            status = status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@api_view ( ['POST'] )
def remove_metadata_file ( request ) :
    """
    Remove file metadata, these referenced by their UUIDs.
    :param request:
    :return:
    """
    if 'file' not in request.data :
        return Response (
            { "errors" : "The File is Required" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    file = get_one_with_params ( File , uuid = request.data['file'] )
    if not file :
        return Response (
            { "errors" : "The File required file does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if 'metadata' not in request.data :
        return Response (
            { "errors" : "Metadata to remove list is empty" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    if not isinstance ( request.data['metadata'] , list ) :
        return Response (
            { "errors" : "Metadata should be a list" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    try :
        metadata_to_remove = get_all ( MetadataValue , uuid__in = request.data['metadata'] )

        if metadata_to_remove :
            metadata_to_remove.delete ( )

        # Update the file Metadata in index
        update_file_metadata ( file )

        return Response ( GetFileSerializer ( file ).data )
    except :
        return Response (
            { "errors" : "An Error Occurs during metadata deletion" } ,
            status = status.HTTP_500_INTERNAL_SERVER_ERROR
        )
