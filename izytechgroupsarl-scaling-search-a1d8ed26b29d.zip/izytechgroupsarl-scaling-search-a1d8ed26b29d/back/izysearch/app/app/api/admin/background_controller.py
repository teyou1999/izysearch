from app.repositories.connector_helper import create_google_drive_connector_obj
from noyau import Memory
from noyau.models import Organisation , Folder , DocIndex , PageIndex , TempConnector
from noyau.repositories.db import get_one_with_params
from rest_framework import status
from rest_framework.decorators import authentication_classes , api_view , permission_classes , renderer_classes
from rest_framework.renderers import StaticHTMLRenderer
from rest_framework.response import Response


@api_view(['POST'])
@authentication_classes([])
@permission_classes([])
def update_memory(request):
    """ Updates the indexes in memory.
    """
    # Get the related folder
    if 'organisation' not in request.data:
        return Response(
            {'errors': 'The folder is required'},
            status=status.HTTP_404_NOT_FOUND
        )

    organisation = get_one_with_params(Organisation, uuid=request.data['organisation'])
    print(f'updating Memory for : {organisation.name}')
    m = Memory.getInstance()
    root_folder = get_one_with_params(Folder, uuid=organisation.root_folder)
    doc_index = get_one_with_params(DocIndex, folder=root_folder)
    page_index = get_one_with_params(PageIndex, folder=root_folder)

    if page_index and doc_index:
        m.indexes[str(root_folder.uuid)] = {
           'pages': page_index.es_index,
            'documents': doc_index.es_index
        }
    return Response('Index Updated', status.HTTP_200_OK)

@api_view(['GET'])
@authentication_classes([])
@permission_classes([])
@renderer_classes([StaticHTMLRenderer])
def google_drive_oauth2(request):
    if 'state' not in request.GET:
        msg = f"<html><body><h1>You deny Authorization to your drive folders.</h1></body></html>"
        return Response (msg)

    state = request.GET['state']

    temp_connector = get_one_with_params(TempConnector, state=state)
    if not temp_connector:
        msg = f"<html><body><h1>Something went wrong during the process</h1></body></html>"
        return Response (msg)

    org = temp_connector.organisation
    connector_type = temp_connector.type
    credential_file = temp_connector.credential_file
    authorization_response = request.build_absolute_uri()

    connector_creation = create_google_drive_connector_obj(org, connector_type, credential_file, authorization_response)

    if isinstance(connector_creation, int):
        if connector_creation == 1:
            temp_connector.delete()
            msg = f"<html><body><h1>Connector or Related Folder Already Exists, Delete an Retry</h1></body></html>"
            return Response (msg)

        if connector_creation == 2:
            temp_connector.delete()
            msg = f"<html><body><h1>Connection to Google Drive refused, please check the Credential file</h1></body></html>"
            return Response (msg)

        if connector_creation == 3:
            temp_connector.delete()
            msg = f"<html><body><h1>Error During the connector Creation, May be the Credential Type (must Be Web)</h1></body></html>"
            return Response (msg)

    temp_connector.delete()
    msg = f"<html><body><h1></body>Google Drive Connector Created</h1></html>"
    return Response (msg)
