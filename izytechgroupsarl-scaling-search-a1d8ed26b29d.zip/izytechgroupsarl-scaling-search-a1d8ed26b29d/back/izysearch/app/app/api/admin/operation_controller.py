from celery.result import AsyncResult
from noyau.models import Job , Log
from noyau.repositories.db import get_one_with_params , get_all
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response


@api_view ( ['GET'] )
def get_operation_status ( request , op_id ) :
    # Get all the Jobs related to this operation
    log = get_one_with_params ( Log , id = op_id )
    jobs = get_all ( Job , log = log )
    total = len ( jobs )  # smax(len(jobs), log.nb_tasks)
    if total == 0 :
        return Response (
            { "errors" : "This operation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    completed = 0.0
    failures = 0.0
    for job in jobs :
        res = AsyncResult ( job.process_id )
        if res.status in ['FAILURE' , 'SUCCESS'] :
            completed += job.weigth

        if res.status == 'FAILURE' :
            failures += job.weigth

    resp = {
        'complete' : completed ,  # Percentage of successful,
        'failure' : failures ,  # percentage of mistakes
    }
    return Response ( resp , status.HTTP_200_OK )
