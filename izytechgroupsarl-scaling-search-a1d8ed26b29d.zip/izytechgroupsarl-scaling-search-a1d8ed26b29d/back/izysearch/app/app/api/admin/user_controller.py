from django.contrib.auth.hashers import make_password
from django.test.client import RequestFactory
from rest_framework import generics , status
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view
from rest_framework.response import Response
from app.serializers.user_serializer import (
    UserSerializer ,
    GetUserSerializer ,
    UpdateUserSerializer
)
from noyau.models import User , Organisation , Subscription
from noyau.repositories.db import get_one_with_params , get_all
from noyau.utils.user_utils import get_connected_user , get_connected_user_organisation
from izysearch.settings import SUPER_ADMIN_ROLE


class UserCreateView ( generics.CreateAPIView ) :
    """
    Create a New User in the System. <br/>
    """
    queryset = User.objects.all ( )
    serializer_class = UserSerializer

    def create ( self , request , *args , **kwargs ) :
        token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
        account = get_connected_user ( token )
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        if account.role.id != 1 :
            data.data['org'] = account.org

        else :
            if 'org' not in data.data :
                return Response (
                    { "errors" : "As an Super you need to specify an organisation ! " } ,
                    status = status.HTTP_400_BAD_REQUEST
                )
            else :
                org = get_one_with_params ( Organisation , uuid = data.data['org'] )
                if not org :
                    return Response (
                        { "errors" : "The Organisation does not exist ! " } ,
                        status = status.HTTP_400_BAD_REQUEST
                    )
                else :
                    data.data['org'] = str ( org.uuid )

        org = get_one_with_params ( Organisation , uuid = data.data['org'] )

        if account.role.id != SUPER_ADMIN_ROLE :
            subscription = get_one_with_params ( Subscription , organisation = org )
            if not subscription :
                return Response (
                    { 'errors' : 'A Subscription is required for your organisation' } ,
                    status = status.HTTP_401_UNAUTHORIZED
                )

            if subscription.current_users >= subscription.current_users :
                return Response (
                    { 'errors' : 'Your Organisation Users Quota is reached !' } ,
                    status = status.HTTP_401_UNAUTHORIZED
                )

            subscription.current_users += 1
            subscription.save ( )

        serializer = UserSerializer ( data = data.data , partial = True )
        if serializer.is_valid ( raise_exception = True ) :
            self.perform_create ( serializer )
            return Response ( serializer.data ,
                              status = status.HTTP_201_CREATED )
        else :
            return Response (
                { "errors" : "Please Check the parameters" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    def perform_create ( self , serializer ) :
        instance = serializer.save ( )
        instance.set_password ( instance.password )
        instance.save ( )
        return instance


class UserListView ( generics.ListAPIView ) :
    """
    Get all the User on the system. <br/>
    """
    serializer_class = GetUserSerializer

    def get_queryset ( self ) :
        user = get_connected_user ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )
        page = 1
        size = 30
        if 'page' in self.request.GET :
            page = int ( self.request.GET['page'] )

        if 'size' in self.request.GET :
            size = int ( self.request.GET['size'] )

        start = (page - 1) * size

        if (user.role.id == 2) :
            return get_all ( User , org = user.org ).order_by ( 'id' )[start : start + size]
        else :
            return get_all ( User ).order_by ( 'id' )[start : start + size]


class UserDeleteView ( generics.DestroyAPIView ) :
    """
    Delete a User using it Primary Key. <br/>
    """
    queryset = User.objects.all ( )
    serializer_class = UserSerializer


class UserShowView ( generics.RetrieveAPIView ) :
    """
    Get a give user it is Id as primary Key. <br/>
    """
    queryset = User.objects.all ( )
    serializer_class = GetUserSerializer


class UserUpdateView ( generics.RetrieveUpdateAPIView ) :
    """
    Update a user information. <br/>
    """
    queryset = User.objects.all ( )
    serializer_class = UpdateUserSerializer

    def put ( self , request , *args , **kwargs ) :
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        return self.partial_update ( data , *args , **kwargs )


class SelfView ( generics.RetrieveAPIView ) :
    serializer_class = GetUserSerializer

    def get ( self , request ) :
        user = get_connected_user ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )
        serializer = GetUserSerializer ( user )
        return Response ( serializer.data )


@api_view ( ['POST'] )
def reset_password(request):
    """
    Reset User password.
    And orgadmin or super_admin can modify user password and it is therefore required.
    :param request:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user (token )

    if 'user' in request.data:
        account = get_one_with_params(User, uuid=request.user)

    if 'password' not in request.data or "confirm_password" not in request.data:
        return Response (
                { 'errors' : 'Password and Confirmation are required' } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    if request.data["password"] != request.data["confirm_password"]:
        return Response (
                { 'errors' : 'Password and Confirmation must match' } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    account.password = make_password(request.data["password"])
    old_token = Token.objects.filter ( user = account )
    old_token.delete()
    token , _ = Token.objects.get_or_create ( user = account )
    account.api_token = token.key

    account.save()

    return Response("Password successfully Reset", status.HTTP_200_OK)
