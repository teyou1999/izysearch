from noyau.models import Folder , Log
from noyau.repositories.db import get_one_with_params , is_uuid
from noyau.utils.user_utils import get_connected_user
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from background.tasks.tasks import split_and_index


@api_view ( ['POST'] )
def index_folder ( request , folder_uuid ) :
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )

    if not is_uuid ( folder_uuid ) :
        return Response (
            { 'errors' : 'The Given UUID is not valid' } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    folder = get_one_with_params ( Folder , uuid = folder_uuid )
    if not folder :
        return Response (
            { 'errors' : 'Folder not found' } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if folder.indexing :
        return Response (
            { 'errors' : 'The Folder is being indexing, please wait ...' } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    folder.indexing = True
    folder.save ( )

    log = Log.objects.create (
        name = 'Indexing Folder' ,
        description = 'Indexing of Folder : ' + folder.name ,
        account = account ,
        success = False ,
        object_type = 'Folder' ,
        object_id = folder.id ,
    )

    process = split_and_index.delay ( folder.id , log.id )

    return Response (
        {
            'operation' : log.id ,
            'process_id' : process.id
        } ,
        status = status.HTTP_200_OK
    )
