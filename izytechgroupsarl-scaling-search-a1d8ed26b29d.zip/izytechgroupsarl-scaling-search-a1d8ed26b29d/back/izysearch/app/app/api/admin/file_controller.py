import os
import shutil

from app.repositories.deletion_helper import delete_files_in_index
from app.repositories.indexation_helper import update_file_metadata
from django.test.client import RequestFactory
from noyau.repositories.folder_helper import compute_folder_size
from noyau.utils.organisation_utils import get_organisation_root_folder
from rest_framework import viewsets , generics , status
from app.serializers.file_serializer import FileSerializer , UpdateFileSerializer , ZipFileSerializer , \
    GetFileSerializer
from noyau.models import File , Log , Page , Image , Folder , Subscription , ConnectorFolder , Connector
from rest_framework.response import Response
from noyau.repositories.db import get_all
from noyau.utils.user_utils import get_connected_user
from noyau.utils.folder_utils import escaped_file_or_folder_name
from noyau.repositories.db import get_one_with_params
from noyau.utils.upload_utils import upload


class UploadFile ( viewsets.ModelViewSet ) :
    """
    Upload a new file in the system. <br/>
    """
    queryset = File.objects.all ( )
    serializer_class = FileSerializer

    def create ( self , request , *args , **kwargs ) :
        if 'folder' not in request.data :
            return Response (
                { 'errors' : 'The Folder is mandatory' } ,
                status = status.HTTP_400_BAD_REQUEST
            )
        folder = get_one_with_params ( Folder , uuid = request.data['folder'] )
        if not folder :
            return Response (
                { 'errors' : 'The location Folder is not found' } ,
                status = status.HTTP_404_NOT_FOUND
            )
        try :
            size = int ( request.data['path'].file.getbuffer ( ).nbytes ) / (1204 * 1024)
        except :
            print ( f"Problem while computing size of : {request.data['path']}" )
            size = 0

        organisation = folder.organisation
        subscription = get_one_with_params ( Subscription , organisation = organisation )
        if not subscription :
            return Response (
                { 'errors' : 'A Subscription is required for your organisation' } ,
                status = status.HTTP_402_PAYMENT_REQUIRED
            )

        if subscription.current_size + size > subscription.max_size :
            return Response (
                { 'errors' : 'Your Organisation Space Quota is reached !' } ,
                status = status.HTTP_402_PAYMENT_REQUIRED
            )
        try :
            request.data['logical_name'] = str ( request.data['path'] ).encode ( "utf-8" )
            serializer = FileSerializer ( data = request.data , partial = True )
            if serializer.is_valid ( ) :
                self.perform_create ( serializer )
                serializer.data['folder'] = str ( serializer.data['folder'] ).replace ( '-' , '' )
                subscription.current_size += size
                subscription.save ( )
                return Response ( serializer.data ,
                                  status = status.HTTP_201_CREATED )
            else :
                return Response (
                    { 'errors' : 'Please check the parameters' } ,
                    status = status.HTTP_400_BAD_REQUEST
                )
        except :
            return Response (
                { 'errors' : 'Upload Error : Your filename has special characters (some accents, tags, ...), please rename' } ,
                status = status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    def perform_create ( self , serializer ) :
        return serializer.save ( )


class ShowFile ( generics.RetrieveAPIView ) :
    """
    Get a specific file with its UUID. <br/>
    """
    queryset = File.objects.all ( )
    serializer_class = GetFileSerializer
    lookup_field = 'uuid'


class FileDelete ( generics.DestroyAPIView ) :
    """
    Delete a File on the System using it uuis as key. <br/>
    """
    queryset = File.objects.all ( )
    serializer_class = FileSerializer
    lookup_field = 'uuid'

    def destroy ( self , request , *args , **kwargs ) :
        instance = self.get_object ( )
        connector = get_one_with_params ( Connector , root_folder = instance.folder )

        if connector :
            return Response (
                { "errors" : "You cannot delete File coming from a connector" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        f_connector = get_one_with_params ( ConnectorFolder , folder = instance.folder )

        if f_connector :
            return Response (
                { "errors" : "You cannot delete an External File" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        self.perform_destroy ( instance )
        return Response ( { 'delete' : 'The file has been correctly deleted' } )

    def perform_destroy ( self , instance ) :
        # Delete Log
        logs = get_all ( Log , object_id = instance.id , object_type = 'File' )

        if logs :
            logs.delete ( )

        # We delete all the chunks at the same time with the miniature and normal files
        chunks = Chunk.objects.filter ( file = instance )
        for chunk in chunks :

            chunk.delete ( )

            image = Image.objects.filter ( chunk = chunk )
            if image :
                image.delete ( )

        # Update the subscription
        subscription = get_one_with_params ( Subscription , organisation = instance.organisation )
        subscription.current_size -= instance.size
        subscription.save ( )

        # Delete file in index
        delete_files_in_index ( [instance] )

        return instance.delete ( )


class FileUpdate ( generics.UpdateAPIView ) :
    """
    Update a file name or Path on the file system. <br/>
    """
    queryset = File.objects.all ( )
    serializer_class = UpdateFileSerializer
    lookup_field = 'uuid'

    def put ( self , request , *args , **kwargs ) :
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        old_file = File.objects.get ( uuid = kwargs['uuid'] )
        if 'folder' in request.data :
            folder = Folder.objects.get ( uuid = request.data['folder'] )
            new_path = (folder.path + '/'
                        + str ( escaped_file_or_folder_name ( old_file.display_name ) ))
            shutil.move ( str ( old_file.path ) , new_path )
            old_file.path.name = new_path
            data.data['path'] = old_file.path
            data.data['folder'] = folder.uuid

        if 'name' in data.data :
            display_name = data.data['name']
            display_name = display_name.split ( '.' )[0]
            data.data['display_name'] = display_name.replace ( '_' , ' ' ).replace ( '-' , ' ' )

        response = self.partial_update ( data , *args , **kwargs )
        new_file = get_one_with_params ( File , id = old_file.id )
        update_file_metadata ( new_file )
        return response


class UploadZip ( viewsets.ModelViewSet ) :
    """
    Upload a new zip on the system. <br/>
    """
    queryset = File.objects.all ( )
    serializer_class = ZipFileSerializer

    def create ( self , request , *args , **kwargs ) :
        if not request.data['folder'] :
            return Response (
                { 'errors' : 'The Folder is mandatory' } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        if 'folder' not in request.data :
            return Response (
                { 'errors' : 'The Folder is mandatory' } ,
                status = status.HTTP_400_BAD_REQUEST
            )
        folder = get_one_with_params ( Folder , uuid = request.data['folder'] )
        if not folder :
            return Response (
                { 'errors' : 'The location Folder is not found' } ,
                status = status.HTTP_404_NOT_FOUND
            )
        size = int ( os.stat ( request.data['path'].file.name ).st_size ) / (1204 * 1024)
        organisation = folder.organisation

        subscription = get_one_with_params ( Subscription , organisation = organisation )
        if not subscription :
            return Response (
                { 'errors' : 'A Subscription is required for your organisation' } ,
                status = status.HTTP_402_PAYMENT_REQUIRED
            )

        if subscription.current_size + size > subscription.max_size :
            return Response (
                { 'errors' : 'Your Organisation Space Quota is reached !' } ,
                status = status.HTTP_402_PAYMENT_REQUIRED
            )

        serializer = self.get_serializer ( data = request.data )

        if serializer.is_valid ( raise_exception = True ) :
            # Save The instance
            file = self.perform_create ( serializer )
            token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
            account = get_connected_user ( token )

            if not file :
                return Response (
                    { "errors" : "Please Check the name fo your zip file (No special charater) or upload one by one" } ,
                    status = status.HTTP_400_BAD_REQUEST
                )

            log = Log.objects.create (
                name = 'Zip File Upload' ,
                description = 'Upload of a zip File : ' + file.display_name ,
                account = account ,
                success = True ,
                object_type = 'File' ,
                object_id = file.id
            )

            success = upload ( serializer.validated_data , parent_log = log )

            file.delete ( )

            # Get the root folder and compute it size
            root_folder = get_organisation_root_folder ( organisation )
            org_disk_size = compute_folder_size ( root_folder )

            subscription.current_size = org_disk_size
            subscription.save ( )

            if not success :
                return Response (
                    { "errors" : "An error occured during the zip Upload !" } ,
                    status = status.HTTP_500_INTERNAL_SERVER_ERROR
                )
            else :
                serializer.data['folder'] = str ( serializer.data['folder'] ).replace ( '-' , '' )
                return Response ( serializer.data )
        else :
            return Response (
                { "errors" : "Please Check the parameters, File and Folder are required" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    def perform_create ( self , serializer ) :
        instance = serializer.save ( )
        return instance
