from app.repositories.deletion_helper import delete_files_in_index
from django.test.client import RequestFactory
from noyau.utils.upload_utils import mv_folder
from rest_framework import generics , viewsets , status
from app.serializers.folder_serializer import GetFolderSerializer , FolderSerializer
from noyau.models import Folder , Organisation , Log , File , Subscription , ConnectorFolder , Connector
from noyau.repositories.db import get_all , get_one_with_params
from noyau.utils.user_utils import get_connected_user , get_connected_user_organisation
from rest_framework.decorators import api_view
from rest_framework.response import Response
from noyau.repositories.folder_helper import is_organisation_root , get_all_org_root_folders , compute_folder_size , \
    get_children_files , count_folder_files_and_pages , count_folder_sub_folders
from app.serializers.file_serializer import GetFileSerializer
from izysearch.settings import SUPER_ADMIN_ROLE


class FolderList ( generics.ListAPIView ) :
    """
    GET all the folders depending whether the connected user is a super admin or as simple admin. <br/>
    """
    serializer_class = GetFolderSerializer

    def get_queryset ( self ) :
        account = get_connected_user ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )
        if account.role.id == 1 :
            return get_all ( Folder )
        else :
            org = get_connected_user_organisation ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )
            return get_all ( Folder , organisation = org )


class ShowFolders ( generics.RetrieveAPIView ) :
    """
    GET A Folder BY UUID
    """
    queryset = Folder.objects.all ( )
    serializer_class = GetFolderSerializer
    lookup_field = 'uuid'

    def get ( self , request , uuid ) :
        folder = self.get_object ( )

        if folder.nb_files == 0 or folder.nb_files == 0 or folder.nb_folders == 0 or folder.size <= 0.0 :
            folder.nb_files , folder.nb_pages = count_folder_files_and_pages ( folder )
            folder.nb_folders = count_folder_sub_folders ( folder )

            if folder.size <= 0 :
                children = get_children_files ( folder , processable = True )
                folder.size = sum ( file_.size for file_ in children )

            folder.save ( )

        serializer = GetFolderSerializer ( folder )
        return Response ( serializer.data )


class CreateFolder ( viewsets.ModelViewSet ) :
    """
    STORE a Folder and create it physically.
    """
    queryset = Folder.objects.all ( )
    serializer_class = FolderSerializer
    lookup_field = 'uuid'

    def create ( self , request , *args , **kwargs ) :
        token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
        account = get_connected_user ( token )

        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )

        if not account :
            return Response (
                { "errors" : "The Role for this user is required" } ,
                status = status.HTTP_404_NOT_FOUND
            )

        if 'parent' not in data.data :
            if account.role.id != 1 :
                org = Organisation.objects.get ( uuid = account.org )
                data.data['organisation'] = org.id
            else :
                return Response (
                    { "errors" : "Please specify the parent folder" } ,
                    status = status.HTTP_400_BAD_REQUEST
                )
        else :
            parent = get_one_with_params ( Folder , uuid = data.data['parent'] )
            if parent :
                data.data['organisation'] = parent.organisation.id
            else :
                return Response (
                    { "errors" : "Parent folder not found" } ,
                    status = status.HTTP_404_NOT_FOUND
                )
        serializer = FolderSerializer ( data = data.data , partial = True )
        if serializer.is_valid ( raise_exception = True ) :
            self.perform_create ( serializer )
            return_object = serializer.data
            if 'parent' in return_object :
                return_object['parent'] = str ( return_object['parent'] ).replace ( '-' , '' )

            return Response ( return_object ,
                              status = status.HTTP_201_CREATED )
        else :
            return Response (
                { "errors" : "Please Check the parameters" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    def perform_create ( self , serializer ) :
        serializer.save ( )


class FolderUpdate ( generics.RetrieveUpdateAPIView ) :
    """ 
    Updating Folder Information
    """
    queryset = Folder.objects.all ( )
    serializer_class = FolderSerializer
    lookup_field = 'uuid'

    def put ( self , request , *args , **kwargs ) :
        if ('parent' in request.data) :
            request.data['path'] , request.data['parent'] = mv_folder ( kwargs['uuid'] ,
                                                                        request.data['parent'] , 0 )

        return self.partial_update ( request.data , *args , **kwargs )


class DeleteFolder ( generics.DestroyAPIView ) :
    queryset = Folder.objects.all ( )
    serializer_class = FolderSerializer
    lookup_field = 'uuid'

    def destroy ( self , request , *args , **kwargs ) :
        instance = self.get_object ( )
        print ( f'In the destroy fonction of  : {instance}' )
        # If This folder is root do not delete
        if is_organisation_root ( instance ) :
            return Response (
                { "errors" : "You cannot delete your root Folder" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        subscription = get_one_with_params ( Subscription , organisation = instance.organisation )
        subscription.current_size -= compute_folder_size ( instance )

        connector = get_one_with_params ( Connector , root_folder = instance )

        if connector :
            return Response (
                { "errors" : "You cannot delete a Connector Folder" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        f_connector = get_one_with_params ( ConnectorFolder , folder = instance )

        if f_connector :
            return Response (
                { "errors" : "You cannot delete an external folder" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        self.perform_destroy ( instance )
        subscription.save ( )
        # Delete Log
        logs = get_all ( Log , object_id = instance.id , object_type = 'Folder' )
        if logs :
            logs.delete ( )

        folders = get_all ( Folder )
        serializer = GetFolderSerializer ( folders , many = True )

        return Response ( serializer.data )

    def preform_destroy ( self , instance ) :
        # Delete data in the index
        files = get_children_files ( instance )
        delete_files_in_index ( files )

        return instance.delete ( )


class OrgRootFolder ( generics.RetrieveAPIView ) :
    """
    Get the root Organisation folder related to the connected user with contained files and folders.
    If super_admin, we return all the organisation folders
    if it is simple admin, we just return the root of the target organisation
    """
    serializer_class = GetFolderSerializer

    def get ( self , request ) :
        account = get_connected_user ( self.request.META.get ( 'HTTP_AUTHORIZATION' ) )

        if not account :
            return Response (
                { "errors" : "Your account cannot be found" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        organisation = get_one_with_params ( Organisation , uuid = account.org )

        if not organisation :
            return Response (
                { "errors" : "Your organisation canno be found" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        root_folder = get_one_with_params ( Folder , uuid = organisation.root_folder )
        if not root_folder :
            return Response (
                { "errors" : "The root folder cannot be found" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

        if account.role.id == SUPER_ADMIN_ROLE :
            sub_folders = get_all_org_root_folders ( organisation.id )
            sub_files = []
            response = {
                'root' : GetFolderSerializer ( root_folder ).data ,
                'folders' : GetFolderSerializer ( sub_folders , many = True ).data ,
                'files' : GetFileSerializer ( sub_files , many = True ).data
            }
        else :
            response = {
                'root' : GetFolderSerializer ( root_folder ).data ,
                'folders' : GetFolderSerializer ( [] , many = True ).data ,
                'files' : GetFileSerializer ( [] , many = True ).data
            }

        return Response ( response )


class FolderTree ( generics.RetrieveAPIView ) :
    """
    Get A folder by uuid with all its sub-folders and sub-files. \
    """
    queryset = Folder.objects.all ( )
    serializer_class = GetFolderSerializer
    lookup_field = 'uuid'

    def get ( self , request , uuid ) :
        folder = self.get_object ( )
        sub_folders = get_all ( Folder , parent = folder )
        sub_files = get_all ( File , folder = folder )

        if sub_folders :
            sub_folders = sub_folders.order_by ( "name" )

        if sub_files :
            sub_files = sub_files.order_by ( "display_name" )

        response = {
            'root' : GetFolderSerializer ( folder ).data ,
            'folders' : GetFolderSerializer ( sub_folders , many = True ).data ,
            'files' : GetFileSerializer ( sub_files , many = True ).data
        }
        return Response ( response )


@api_view ( ['GET'] )
def change_indexing_status ( request , uuid ) :
    """
    Change indexing status of a folder.

    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    org = get_connected_user_organisation ( token )
    account = get_connected_user ( request.META.get ( 'HTTP_AUTHORIZATION' ) )

    folder = get_one_with_params ( Folder , uuid = uuid )
    if not folder :
        return Response (
            { 'errors' : "The Folder doesn't exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )
    if account.role.id != SUPER_ADMIN_ROLE and folder.organisation.id != org.id :
        return Response (
            { 'errors' : "You don't have access to this" } ,
            status = status.HTTP_403_FORBIDDEN
        )
    folder.indexing = not folder.indexing
    folder.save ( )

    return Response ( "Indexing status updated" , status.HTTP_200_OK )
