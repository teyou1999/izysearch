from rest_framework import generics
from app.serializers.role_serializer import RoleSerializer
from noyau.repositories.db import get_all
from noyau.models.role import Role
from rest_framework.decorators import permission_classes
from rest_framework.permissions import AllowAny


@permission_classes ( (AllowAny ,) )
class RoleList ( generics.ListAPIView ) :
    """
    GET all the Roles in the data base. <br/>
    """
    serializer_class = RoleSerializer

    def get_queryset ( self ) :
        return get_all ( Role )
