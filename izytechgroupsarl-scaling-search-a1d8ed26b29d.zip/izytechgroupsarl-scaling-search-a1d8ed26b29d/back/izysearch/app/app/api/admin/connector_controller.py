import os
from app.repositories import GOOGLE_DRIVE_FILEDS_GET
from app.repositories.connector_helper import create_google_drive_connector_obj , google_drive_authentication , \
    get_connector_credentials , check_request_connector_org_type , delete_inconsistent_folder , create_gdrive_folders , \
    get_gdrive_auth_url

from app.serializers.connector_serializer import GetConnectorTypeSerializer , GetConnectorSerializer
from app.serializers.file_serializer import GetFileSerializer
from app.serializers.folder_serializer import GetFolderSerializer , GetRemoteFolderSerializer
from django.core.files.storage import default_storage
from googleapiclient.discovery import build
from noyau.models import ConnectorType , Organisation , Connector , ConnectorFolder , Folder , ConnectorFile , \
    TempConnector
from noyau.repositories.db import get_all , get_one_with_params
from noyau.utils.user_utils import get_connected_user_organisation
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from izysearch.settings import SUPER_ADMIN_ROLE, CREDENTIAL_DIR


@api_view ( ['GET'] )
def list_connector_types(request):
    """
    Get all the connector type.
    :param request:
    :return:
    """
    connector_types = get_all(ConnectorType, active=True)

    response =  GetConnectorTypeSerializer(connector_types, many = True ).data
    return Response ( response )


@api_view ( ['GET'] )
def list_organisation_connectors(request):
    """
    Get all the connector type.
    :param request:
    :return:
    """
    token = request.META.get('HTTP_AUTHORIZATION', None)
    organisation = get_connected_user_organisation(token)

    if 'organisation' in request.GET:
        organisation = get_one_with_params(Organisation, uuid=request.GET['organisation'])

    connectors = get_all(Connector, organisation=organisation)
    response = GetConnectorSerializer(connectors, many=True).data
    return Response ( response )


@api_view ( ['POST'] )
def create_googledrive_connector(request):
    """
    Create a Connector for mapping Google Drive files.
    - organisation[uuid] : is mandatory
    - type[uuid] is mandatory and must correspond to Google Drive
    - credentials[JSON File] is the json obtained trough the Google maps API
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request, type='POST')
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    organisation = check_request['organisation']
    connector_type = check_request['type']

    if not connector_type:
        return Response (
            { "errors" : "The Connector Type does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if 'credentials' not in request.data:
        return Response (
            { "errors" : "Credential File is required" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)

    if connector:
        return Response (
            { "errors" : "A Such connector already exists, please delete it." } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    file = request.FILES['credentials']
    file_name = f"credentials_{request.data['organisation']}.json"
    file_path = os.path.join(CREDENTIAL_DIR, file_name)
    credentials_path = default_storage.save(file_path, file)

    authorization_url, state = get_gdrive_auth_url(credentials_path)

    if authorization_url and state:
        TempConnector.objects.create(
            type = connector_type,
            organisation = organisation,
            state = state,
            auth_url = authorization_url,
            credential_file = credentials_path
        )
        return Response (
            { "auth_url" : authorization_url } ,
            status = status.HTTP_200_OK
        )

    return Response (
        { "errors" : "Connection to Google Drive refused, please check the Credential file" } ,
        status = status.HTTP_400_BAD_REQUEST
    )


@api_view ( ['GET'] )
def list_organisation_gdrive_connector_folders(request):
    """
    List all the folders on a specific Cloud service accessible using a created connector.
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request)
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    organisation = check_request['organisation']
    connector_type = check_request['type']

    if not connector_type:
        return Response (
            { "errors" : "The Connector Type does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)

    if not connector:
        return Response (
            { "errors" : "A Such connector does not Exists please Create one." } ,
            status = status.HTTP_404_NOT_FOUND
        )

    connected = google_drive_authentication(connector)

    if not connected:
        return Response (
            { "errors" : "The Connector is out of date please. You have to delete the existing and create new one" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    credentials = get_connector_credentials(connector)
    service = build('drive', 'v3', credentials=credentials)

    results = service.files().list(q="mimeType = 'application/vnd.google-apps.folder'",
        fields=GOOGLE_DRIVE_FILEDS_GET).execute()

    items = results.get('files', [])

    return Response(items)


@api_view ( ['DELETE'] )
def destroy_connector(request):
    """
    Delete a Connector for an organisation
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request, type='DELETE')
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    organisation = check_request['organisation']
    connector_type = check_request['type']

    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)

    if not connector:
        return Response (
            { "errors" : "A Such connector does not Exists please Create one." } ,
            status = status.HTTP_404_NOT_FOUND
        )

    # Delete Folder and files related
    connector_folders = get_all(ConnectorFolder, connector=connector)
    if connector_folders:
        connector_folders.delete()

    connector_files = get_all(ConnectorFile, connector=connector)
    if connector_files:
        connector_files.delete()

    # Delete connector Root folder
    connector.root_folder.delete()

    connector.delete()

    return Response('The Connector successfully deleted')


@api_view ( ['POST'] )
def synchronize_gdrive_folders(request):
    """
    Synchronize Google Drive folders given as parameters (IDs).
    organisation, type(of the connector) and folder list is required
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request, type='POST')
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    if 'folders' not in request.data:
        return Response (
            { "errors" : "You must specify the folders you want to synchronize" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    if not isinstance(request.data['folders'], list):
        return Response (
            { "errors" : "Folders should be referenced as a list of IDs" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    organisation = check_request['organisation']
    connector_type = check_request['type']
    folder_ids = list(request.data['folders'])

    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)
    if not connector:
        return Response (
            { "errors" : "A Such connector does not Exists please Create one." } ,
            status = status.HTTP_404_NOT_FOUND
        )

    connected = google_drive_authentication(connector)
    if not connected:
        return Response (
            { "errors" : "The Connector is out of date please. You have to delete the existing and create new one" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    try:
        # get the folders
        created_folders, created_files = create_gdrive_folders(folder_ids, connector)

        response = {
            'created_folders': GetFolderSerializer(created_folders, many=True).data,
            'created_files': GetFileSerializer(created_files, many=True).data
        }

        return Response(response)

    except:
        return Response (
            { "errors" : "An Error Occurs during the Folders Synchronisation." } ,
            status = status.HTTP_500_INTERNAL_SERVER_ERROR
        )

@api_view ( ['GET'] )
def get_synchronize_gdrive_folders(request):
    """
    Get All the folders synchronised with Google drive.
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request)
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    organisation = check_request['organisation']
    connector_type = check_request['type']
    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)
    if not connector:
        return Response (
            { "errors" : "A Such connector does not Exists please Create one." } ,
            status = status.HTTP_404_NOT_FOUND
        )

    connector_folders = get_all(ConnectorFolder, connector=connector)

    folders = []
    for f_connector in connector_folders:
        folder = f_connector.folder
        folder.last_synchronisation = f_connector.last_synchro
        folder.connector_name = connector.type.name
        folders.append(folder)

    return Response(GetRemoteFolderSerializer(folders, many=True).data)


@api_view ( ['POST'] )
def desynchronize_gdrive_folders(request):
    """
    De-synchronize Google Drive folders given as parameters (Uuids).
    organisation, type(of the connector) and folder list is required
    :param request:
    :return:
    """
    check_request = check_request_connector_org_type(request, type='POST')
    if 'organisation' not in check_request and 'type' not in check_request:
        return check_request

    if 'folders' not in request.data:
        return Response (
            { "errors" : "You must specify the folders you want to de-synchronize" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    if not isinstance(request.data['folders'], list):
        return Response (
            { "errors" : "Folders should be referenced as a list of IDs" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    organisation = check_request['organisation']
    connector_type = check_request['type']
    folder_uuids = list(request.data['folders'])

    connector = get_one_with_params(Connector, organisation=organisation, type=connector_type)
    if not connector:
        return Response (
            { "errors" : "A Such connector does not Exists please Create one." } ,
            status = status.HTTP_404_NOT_FOUND
        )

    try:
        # get the folders
        existing_folders = get_all(Folder, uuid__in=folder_uuids)
        if not existing_folders:
            return Response (
                { "errors" : "Folders Not Found or selected list is Empty" } ,
                status = status.HTTP_404_NOT_FOUND
            )

        error_folders = []

        for f in existing_folders:
            try:
                f.delete()
            except:
                error_folders.append(f)

        connector_folders = get_all(ConnectorFolder, connector=connector)

        remaining_folders = []
        for f_connector in connector_folders:
            folder = f_connector.folder
            folder.last_synchronisation = f_connector.last_synchro
            folder.connector_name = connector.type.name
            remaining_folders.append(folder)

        response = {
            'error_folders': GetFolderSerializer(error_folders, many=True).data,
            'remaining_folders': GetRemoteFolderSerializer(remaining_folders, many=True).data
        }

        return Response(response)
    except:
        return Response (
            { "errors" : "An Error Occurs during the Folders Synchronisation." } ,
            status = status.HTTP_500_INTERNAL_SERVER_ERROR
        )
