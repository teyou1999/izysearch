from noyau.models import Organisation , Query , User , Metadata , Connector
from noyau.repositories.db import get_one_with_params , get_all
from noyau.repositories.folder_helper import get_children_files , count_folder_sub_folders , \
    count_folder_files_and_pages
from noyau.utils.organisation_utils import get_organisation_root_folder
from noyau.utils.user_utils import get_connected_user
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response


@api_view ( ['GET'] )
def statistics ( request ) :
    """
    Get All the statistics related to and organisation
    :param request:
    :return:
    """
    if 'organisation' not in request.GET :
        return Response (
            { "errors" : "Please you Must Select an Organisation Before" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    organisation = get_one_with_params ( Organisation , uuid = request.GET['organisation'] )
    if not organisation :
        return Response (
            { "errors" : "Please you Must Select an Organisation Before" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    root_folder = get_organisation_root_folder ( organisation )

    if root_folder.size > 0 and root_folder.nb_files != 0 and root_folder.nb_folders != 0 :
        size = root_folder.size
    else :
        children = get_children_files ( root_folder , processable = True )
        size = sum ( file_.size for file_ in children )
        root_folder.size = size
        root_folder.nb_files , root_folder.nb_pages = count_folder_files_and_pages ( root_folder )
        root_folder.nb_folders = count_folder_sub_folders ( root_folder )
        root_folder.save ( )

    nb_files = root_folder.nb_files
    nb_folders = root_folder.nb_folders
    nb_pages = root_folder.nb_pages
    nb_queries = len ( get_all ( Query , organisation = organisation ) )
    nb_users = len ( get_all ( User , org = organisation.uuid ) )
    nb_metadata = len ( get_all ( Metadata , organisation = organisation ) )
    nb_connectors = len ( get_all ( Connector , organisation = organisation ) )

    return Response ( {
        'files' : nb_files ,
        'folders' : nb_folders ,
        'pages' : nb_pages ,
        'queries' : nb_queries ,
        'users' : nb_users ,
        'metadata' : nb_metadata ,
        'connectors' : nb_connectors ,
        'size' : size / 1024
    } )
