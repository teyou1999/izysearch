from app.serializers.formula_serializer import FormulaSerializer , GetFormulaSerializer
from noyau.models.subscription import Formula
from rest_framework import generics , status
from rest_framework.response import Response
from django.test.client import RequestFactory


class FormulaCreateView ( generics.CreateAPIView ) :
    """
    Create a New Subscription Formula in the System. <br/>
    """
    queryset = Formula.objects.all ( )
    serializer_class = FormulaSerializer

    def create ( self , request , *args , **kwargs ) :
        serializer = FormulaSerializer ( data = request.data , partial = True )
        if serializer.is_valid ( raise_exception = True ) :
            self.perform_create ( serializer )

            return Response ( serializer.data ,
                              status = status.HTTP_201_CREATED )
        else :
            return Response (
                { "errors" : "Please Check the parameters of the Formula" } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    def perform_create ( self , serializer ) :
        instance = serializer.save ( )
        instance.save ( )


class FormulaListView ( generics.ListAPIView ) :
    """
    Get all the Subscription Formula on the system. <br/>
    """
    queryset = Formula.objects.all ( )
    serializer_class = GetFormulaSerializer


class FormulaDeleteView ( generics.DestroyAPIView ) :
    """
    Delete a Formula in the system. <br/>
    """
    queryset = Formula.objects.all ( )
    serializer_class = GetFormulaSerializer
    lookup_field = 'uuid'


class FormulaShowView ( generics.RetrieveAPIView ) :
    """
    Get a give Subscription formula using its uuid. <br/>
    """
    queryset = Formula.objects.all ( )
    serializer_class = GetFormulaSerializer
    lookup_field = 'uuid'


class FormulaUpdateView ( generics.RetrieveUpdateAPIView ) :
    """
    Update a user information. <br/>
    """
    queryset = Formula.objects.all ( )
    serializer_class = FormulaSerializer
    lookup_field = 'uuid'

    def put ( self , request , *args , **kwargs ) :
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        return self.partial_update ( data , *args , **kwargs )
