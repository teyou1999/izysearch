from app.repositories.index_loading_helper import load_indexes
from noyau.repositories.subscription_helper import create_subscription
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from noyau.models import Organisation , User , Folder , Formula
from noyau.utils.user_utils import get_connected_user
from app.serializers.organisation_serializer import OrganisationSerializer , GetOrganisationSerializer
from izysearch.settings import SUPER_ADMIN_ROLE
from noyau.repositories.db import get_one_with_params , get_all
from noyau.utils.organisation_utils import create_root_dir


def get_org_with_admin ( **kwargs ) :
    if len ( kwargs.items ( ) ) == 0 :
        objects = Organisation.objects.select_related ( 'admin' ).all ( )
    else :
        objects = Organisation.objects.select_related ( 'admin' ).filter ( **kwargs )

    if objects is None or len ( objects ) == 0 :
        return []
    else :
        return objects


@api_view ( ['POST'] )
def store ( request ) :
    """
    Store a new organisation
    Its name is required
    :param request:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )

    if not account :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    serializer = OrganisationSerializer ( data = request.data , partial = True )

    formula = get_one_with_params ( Formula , name = 'Free' )
    if 'formula' in request.data :
        formula = get_one_with_params ( Formula , uuid = request.data['formula'] )
        if not formula :
            return Response (
                { "errors" : 'Please make sure you select a correct Formula' } ,
                status = status.HTTP_400_BAD_REQUEST
            )

    if serializer.is_valid ( raise_exception = True ) :
        serializer.save ( )
        # Create an empty dir for this folder
        org = get_one_with_params ( Organisation , name = request.data['name'] )
        root_dir = create_root_dir ( org )
        org.root_folder = root_dir
        org.save ( )
        org = get_one_with_params ( Organisation , name = request.data['name'] )
        serializer = GetOrganisationSerializer ( org )

        # Create the subscription of this Organisation
        create_subscription ( formula , org )

        return Response ( serializer.data )
    else :
        return Response (
            { "errors" : serializer.errors } ,
            status = status.HTTP_400_BAD_REQUEST
        )


@api_view ( ['POST' , 'GET'] )
def index ( request ) :
    """
    Retrieve all Organisations some criteria may be specified
    :param request:
    :return:
    """
    if request.method == 'POST' :
        if 'keywords' in request.data :
            organisations = get_org_with_admin ( name__iregex = r'.*' + request.data['keywords'] + '.*' )
        else :
            organisations = get_all ( Organisation )
    else :
        organisations = Organisation.objects.order_by ( 'name' ).all ( )

    serializer = GetOrganisationSerializer ( organisations , many = True )
    return Response ( serializer.data )


@api_view ( ['GET'] )
def show ( request , pk ) :
    """
    Show an Organisation based on its ID as primary key.
    - If there is no organisation with that key, we return an 404 with error message
    :param request:
    :param pk:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params ( Organisation , id = pk )

    # If the object with the required ID doest not exist
    if not organisation :
        return Response (
            { "errors" : "The required organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    serializer = GetOrganisationSerializer ( organisation )
    return Response ( serializer.data )


@api_view ( ['PUT'] )
def update ( request , pk ) :
    """
    Update information of an organisation given in the request param
    Name and Admin should be given in the request
    :param request:
    :param pk<int>:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    if pk == 1 :
        return Response (
            { "errors" : "You cannot delete the Root Organisation" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    organisation = get_one_with_params ( Organisation , id = pk )

    # If the object with the required ID doest not exist
    if not organisation :
        return Response (
            { "errors" : "The required organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    serializer = OrganisationSerializer ( organisation , data = request.data , partial = True )
    if serializer.is_valid ( raise_exception = True ) :
        serializer.save ( )

        return Response ( GetOrganisationSerializer ( organisation ).data )
    else :
        return Response (
            { "errors" : serializer.errors } ,
            status = status.HTTP_400_BAD_REQUEST
        )


@api_view ( ['DELETE'] )
def delete ( request , pk ) :
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )

    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params ( Organisation , id = pk )

    # Impossible to delete the SuperOrga
    if organisation.name == 'Izytech Group SARL' :
        return Response (
            { "errors" : "You cannot delete the Root Organisation" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    # If the object with the required ID doest not exist
    if not organisation :
        return Response (
            { "errors" : "The required organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    # Get All the users of this organisation and delete
    users = get_all ( User , org = organisation.uuid )
    if users :
        users.delete ( )

    root_folder = get_one_with_params ( Folder , uuid = organisation.root_folder )
    if root_folder :
        root_folder.delete ( )

    # Delete The organisation
    organisation.delete ( )

    # Reload the memory
    load_indexes ( )

    # Get the remaining and return
    organisations = get_all ( Organisation )
    serializer = GetOrganisationSerializer ( organisations , many = True )

    return Response ( serializer.data )
