from datetime import datetime
from app.serializers.formula_serializer import GetFormulaSerializer
from app.serializers.subscription_serializer import GetSubscriptionHistorySerializer , GetSubscriptionSerializer , \
    SubscriptionSerializer
from django.test.client import RequestFactory
from noyau.models import Organisation
from noyau.models.subscription import SubscriptionHistory , Subscription , Formula
from noyau.repositories.db import get_one_with_params , get_all , get_all_exclude , is_valid_uuid
from noyau.repositories.subscription_helper import organisation_subscription_renew , create_subscription
from noyau.utils.user_utils import get_connected_user
from izysearch.settings import SUPER_ADMIN_ROLE
from rest_framework import status , generics
from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view ( ['POST'] )
def renew_subscription(request, uuid):
    """
    Renew an Organisation Subscription
    :param request:
    :param uuid:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params ( Organisation , uuid=uuid )

    if not organisation :
        return Response (
            { "errors" : "The required organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    subscription = organisation_subscription_renew(organisation)

    serializer = GetSubscriptionSerializer( subscription)
    return Response ( serializer.data )


@api_view ( ['POST'] )
def change_subscription(request, uuid):
    """
    Change an Organisation Subscription.
    The new one should be different from the current and should be in the request
    :param request:
    :param uuid:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params ( Organisation , uuid=uuid )

    if not organisation :
        return Response (
            { "errors" : "The required organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if 'formula' not in request.data:
        return Response (
            { "errors" : "You should select a valid formula" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    if not is_valid_uuid(request.data['formula']):
        return Response (
            { "errors" : "Please check the UUID params" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    formula = get_one_with_params(Formula, uuid=request.data['formula'])
    if not formula:
        return Response (
            { "errors" : "Please select an existing formula" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    current_subscription = get_one_with_params(Subscription, organisation=organisation)

    if str(current_subscription.formula.uuid) == str(formula.uuid):
        return Response (
            { "errors" : "Please Select a formula different from the current one" } ,
            status = status.HTTP_400_BAD_REQUEST
        )

    # Create new subscription
    subscription = create_subscription(formula, organisation)

    serializer = GetSubscriptionSerializer( subscription)
    return Response ( serializer.data )


@api_view ( ['GET'] )
def list_organisation_subscription_historic(request , uuid ):
    """
    List all the passed subscriptions of an organisation
    :param request:
    :param uuid:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params(Organisation , uuid=uuid)
    if not organisation:
        return Response(
            { "errors" : "This organisation does not exists !" },
            status = status.HTTP_404_NOT_FOUND
        )
    history_list = get_all(SubscriptionHistory, organisation=organisation)
    serializer = GetSubscriptionHistorySerializer ( history_list , many = True )
    return Response ( serializer.data )


@api_view ( ['GET'] )
def current_organisation_subscription(request , uuid ):
    """
    Get current organisation Subscription
    :param request:
    :param uuid:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params(Organisation , uuid=uuid)
    if not organisation:
        return Response(
            { "errors" : "This organisation does not exists !" },
            status = status.HTTP_404_NOT_FOUND
        )
    current_sub = get_one_with_params(Subscription, organisation=organisation)
    serializer = GetSubscriptionSerializer (current_sub)
    return Response ( serializer.data )


@api_view ( ['GET'] )
def get_possible_formula(request , uuid ):
    """
    Get Possibles formula of an organisation
    :param request:
    :param uuid:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user ( token )
    if account.role.id != SUPER_ADMIN_ROLE :
        return Response (
            { "errors" : "You are not allowed to be here !" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )
    organisation = get_one_with_params(Organisation , uuid=uuid)
    if not organisation:
        return Response(
            { "errors" : "This organisation does not exists !" },
            status = status.HTTP_404_NOT_FOUND
        )
    current_sub = get_one_with_params(Subscription, organisation=organisation)
    possible_formula = get_all_exclude(Formula, uuid=current_sub.formula.uuid)
    serializer = GetFormulaSerializer ( possible_formula , many = True )
    return Response ( serializer.data )


class SubscriptionUpdateView ( generics.RetrieveUpdateAPIView ) :
    """
    Update a Subscription information. <br/>
    Date is like : 1998-03-08 14:14:45
    """
    queryset = Subscription.objects.all ( )
    serializer_class = SubscriptionSerializer
    lookup_field = 'uuid'

    def put ( self , request , *args , **kwargs ) :
        data = RequestFactory ( ).get ( '/' )
        data.data = request.data.copy ( )
        for key , value in request.data.items ( ) :
            if (key == 'end_date') :
                data.data[key] = datetime.strptime(value, '%Y-%m-%d %H:%M:%S')
            else :
                data.data[key] = value
        return self.partial_update ( data , *args , **kwargs )
