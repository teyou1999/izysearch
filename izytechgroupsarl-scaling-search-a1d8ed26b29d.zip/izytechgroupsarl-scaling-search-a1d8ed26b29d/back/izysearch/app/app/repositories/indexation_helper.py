from background.utils.es_index_builder import build_file_metadata , format_files_for_es
from noyau import Memory
from noyau.models import DocIndex
from noyau.repositories.db import get_one_with_params
from noyau.repositories.folder_helper import get_file_text
from noyau.utils.organisation_utils import get_organisation_root_folder


def update_file_metadata(file_):
    """
    This is a kind of file reindexation
    Update File metadata in the index asn well as the name.
    This is performed during the adding or the removal of new metadata.
        - If the index exists, the file will be updated only
        - Else, we will create the index and update its information.
    :param file_:
    :return:
    """
    m = Memory.getInstance()
    preprocessor = m.text_processor
    es_client = m.es_client
    # Get the index
    root_folder = get_organisation_root_folder(file_.folder.organisation)

    doc_index = get_one_with_params(DocIndex, folder=root_folder)
    existing_index = False
    if doc_index:
        if not es_client.index_exists(doc_index.es_index):
            index_name = f'{root_folder.name}_{root_folder.id}'.lower()
            doc_index.es_index = index_name
            doc_index.save()
        else:
            index_name = doc_index.es_index
            existing_index = True
    else:
        # In this cas we just create a new Index
        index_name = f'{root_folder.name}_{root_folder.id}'.lower()
        # Delete the index if its exists
        es_client.delete_index(index_name)
        # Create the index
        es_client.create_index(index_name)


    file_text = get_file_text(file_)
    file_text = preprocessor.preprocess_string(file_text)

    # Get the logical name to the chunk text
    if not hasattr(file_, 'display_name'):
        doc_title = file_.display_name.split('.')[0]
        doc_title = doc_title.replace('_', ' ').replace('-', ' ')
        doc_title = preprocessor.preprocess_string(doc_title)
        file_.logical_name = doc_title

    file_.text = file_text

    # Insert Docs
    if not existing_index:
        docs_to_index = format_files_for_es([file_], index_name, '_doc', preprocessor)
        es_client.insert_doc_in_index(docs_to_index, index_name, '_doc', doc_size=len(docs_to_index))

        if not doc_index:
            DocIndex.objects.create(
                    es_index=index_name,
                    folder=root_folder,
                )
    else:
        query_file = {
            'query': {
                'term': {
                    'file_id': file_.id
                }
            }
        }
        existing_file = es_client.count_docs(query_file, index_name)
        if existing_file > 0:
            es_client.delete_documents(index_name, query_file)
            es_client.client.indices.refresh(index=index_name)

        docs_to_index = format_files_for_es([file_], index_name, '_doc', preprocessor)
        es_client.insert_doc_in_index(docs_to_index, index_name, '_doc', doc_size=len(docs_to_index))
        # else:
            # delete existing


            # Update the metadata only
            # new_doc = format_files_for_es([file_], index_name, '_doc', preprocessor)[0]
            # new_metadata = build_file_metadata(file_, preprocessor)
            # new_doc['metadata'] = new_metadata
            # update_query = {
            #     "script": {
            #     "source": "ctx._source.put('metadata', params)",
            #     "params": new_metadata,
            #     "lang": "painless"
            #   },
            #   "query": {
            #     "term": {
            #       "file_id": file_.id
            #     }
            #   }
            # }
            # es_client.update_by_query(update_query, index_name)
