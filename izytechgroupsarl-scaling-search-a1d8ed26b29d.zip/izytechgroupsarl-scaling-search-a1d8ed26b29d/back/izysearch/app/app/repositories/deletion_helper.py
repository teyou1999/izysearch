from noyau import Memory
from noyau.models import DocIndex , PageIndex
from noyau.repositories.db import get_one_with_params
from noyau.utils.organisation_utils import get_organisation_root_folder


def delete_files_in_index(files):
    """
    Delete a list of Files in Elastic Search Index.
    :param files:
    :return:
    """
    if not files:
        return

    file_ids = [file_.id for file_ in files]
    m = Memory.getInstance()
    root_folder = get_organisation_root_folder(files[0].organisation)

    doc_index = get_one_with_params(DocIndex, folder=root_folder)
    page_index = get_one_with_params(PageIndex, folder=root_folder)

    delete_query_body = {
        "query": {
            "terms": {
                "file_id": file_ids
            }
        }
    }
    if doc_index:
        m.es_client.delete_documents(index_name = doc_index.es_index, query_body = delete_query_body)

    if page_index:
        m.es_chunk_client.delete_documents(index_name = page_index.es_index, query_body = delete_query_body)


def delete_organisation(organisation):
    """
    Delete indices related to an organisation. <br/>
    :param organisation:
    :return:
    """
    # delete Root Folder
    root_folder = get_organisation_root_folder(organisation)
    root_folder.delete()

    # Delete the two Indices
    doc_index = get_one_with_params(DocIndex, folder=root_folder)
    page_index = get_one_with_params(PageIndex, folder=root_folder)
    doc_index.delete()
    page_index.delete()
