from izysearch.settings import SEUIL_SUGGESTION


def es_query_suggester(query:str, size:int) -> dict:
    """
    This function is used to generated the query body for filtering chunk with the following conditions :
      - The file_id must be include in the list given as parameter.
      - The chunk text should include the query text. \
    :param query:
    :param size:
    :return:
    """
    return {
        "suggest" : {
            "q" : {
                "text" : query,
                "term" : {
                    "size" : size,
                    "sort": "score",
                    "field" : "text"
                }
            }
        }
    }


def suggest_query(es_client, index_name,  query):
        """
        Get suggestions for each words of the query
        replace the one that can be replaced
        And remove the gibberish words
        """
        query_suggest_body = es_query_suggester(query, size=1)
        res_query = es_client.get_suggestion(query_suggest_body, index_name)
        dict_res = {}

        for r in res_query:
            if r["options"]:
                if r['options'][0]["score"] > SEUIL_SUGGESTION:
                    dict_res[r["text"]] = r['options'][0]["text"]
        new_query = []

        for word_query in query_suggest_body["suggest"]["q"]["text"].split():
            if word_query in dict_res:
                new_query.append(dict_res[word_query])
            else:
                new_query.append(word_query)

        modified_query = " ".join(new_query)
        return modified_query
