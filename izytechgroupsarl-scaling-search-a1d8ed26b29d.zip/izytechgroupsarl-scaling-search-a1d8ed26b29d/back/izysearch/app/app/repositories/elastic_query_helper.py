from noyau import TextPreprocessor
from noyau.models import MetadataType , Metadata
from noyau.repositories.db import get_one_with_params , get_all


def _add_interval_filter(must_body, metadata_entry):
    """
    This function builds an Elastic search query and add it to a must query.
    The entry here is an interval with a start and an end.
    :param must_body:
    :param metadata_entry:
    :return:
    """
    # If we want value to be in this interval only
    if 'to' not in metadata_entry:
        must_body.append({
            'range': {
                f"metadata.{metadata_entry['name']}.min":{
                    "lte": metadata_entry['selected']
                }
            }
        })

        must_body.append({
            'range': {
                f"metadata.{metadata_entry['name']}.max":{
                    "gte": metadata_entry['selected']
                }
            }
        })

    # An overlap or an inclusion is mandatory
    else:
        inf = metadata_entry['selected']
        if metadata_entry['type'] == 4:
            sup = metadata_entry['to'] if 'to' in metadata_entry else '2800-12-31'
        else:
            sup = metadata_entry['to'] if 'to' in metadata_entry else 999999999999.000

        shoulds = []

        # The min of the target interval is included in file Date range
        shoulds.append({
            "bool": {
                "must": [
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.min":{
                            "lte": inf
                            }
                        }
                    },
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.max":{
                            "gte": inf
                            }
                        }
                    }
                ]
            }
        })

        # The max of the target interval is included in file Date range
        shoulds.append({
            "bool": {
                "must": [
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.min":{
                            "lte": sup
                            }
                        }
                    },
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.max":{
                            "gte": sup
                            }
                        }
                    }
                ]
            }
        })

        # The min and max of the target interval are included in file Date range
        shoulds.append({
            "bool": {
                "must": [
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.min":{
                            "lte": inf
                            }
                        }
                    },
                    {
                        "range": {
                            f"metadata.{metadata_entry['name']}.max":{
                            "gte": sup
                            }
                        }
                    }
                ]
            }
        })

        must_body.append(shoulds)

    return must_body


def build_docs_filter_query(params:dict, size:int, offset:int=0, use_query=True, 
        all_props=False, preprocessor:TextPreprocessor=None) -> dict:
    """
        This function builds the body of the query dedicated to the filtering
        of size docs relevant for a query from position offset
        :params:
    """
    should_body = []
    must_body = []

    if 'folder_items' in params:
        must_body.append({
            "terms": {
            "folder_id": params['folder_items']
            }
        })

    if 'extensions' in params:
        must_body.append({
            "terms": {
                "extension": params['extensions']
            }
        })
    
    if 'name' in params:
        must_body.append({
            "match": {
                "name": preprocessor.preprocess_metadata(params['name'])
            }
        })

    if 'keywords' in params:
        must_body.append({
            "match_phrase": {
                "text": [preprocessor.preprocess_metadata(keyword) for keyword in params['keywords']]
            }
        })

    if 'meta_filters' in params:
        for metadata_entry in params['meta_filters']:
            if metadata_entry['type'] == '1':
                must_body.append({
                    "match_phrase": {
                        f"metadata.{metadata_entry['name']}": preprocessor.preprocess_metadata(str(metadata_entry['selected']))
                    }
                })

            # We want to match exact Data
            if metadata_entry['type'] == '2':
                must_body.append({
                    "term": {
                        f"metadata.{metadata_entry['name']}": metadata_entry['selected']
                    }
                })

            # Match with an interval of Date
            if metadata_entry['type'] in ['3', '4']:
                must_body = _add_interval_filter(must_body, metadata_entry)

            # Value in range
            if metadata_entry['type'] == '5':
                match_values = [preprocessor.preprocess_metadata(prop) for prop in metadata_entry['selected']]
                for matched_value in match_values:
                    must_body.append({
                        "match_phrase": {
                            f"metadata.{metadata_entry['name']}": matched_value
                        }
                    })

    if use_query and params['query'].strip():
        query = preprocessor.preprocess_string(params['query'])
        should_body.append({
            "match": {
                "text": query
            }
        })

        for term in query.split():
            should_body.append({
                "match": {
                    "text": term
                }
            })

        # Get all string metadata
        string_metadata_type = get_one_with_params(MetadataType, type=1)
        string_metadata = get_all(Metadata, type=string_metadata_type)
        string_metadata = [f"metadata.{metadata.name}" for metadata in string_metadata]
        string_metadata += ['name', 'display_name']

        should_body.append({
            "query_string": {
                "query": preprocessor.preprocess_metadata(params['query']),
                "fields": list(set(string_metadata))
            }
        })

    doc_query =  {
        "size": size,
        "query": {
            "bool": {
                "should": should_body,
                "must": must_body,
            }
        }
    }

    if not all_props:
        doc_query['_source'] = ['file_id', 'metadata']

    if offset > 0:
        doc_query['from'] = offset

    return doc_query


def build_pages_filter_query(params:dict, size:int, preprocessor:TextPreprocessor=None, file_ids:list=[]) -> dict:
    """
        Filter all the pages relevant for a given query as parameter. 
        This function return the body of the query to perform.
    """
    must_body = []
    should_body = []
    if file_ids:
        must_body.append({
            "terms": {
                "file_id": file_ids
            }
        })

    if 'query' in params and params['query'].strip()!='':
        query = preprocessor.preprocess_string(params['query'])

        should_body.append({
            "match": {
                "text": query
            }
        })


        for term in query.split():
            should_body.append({
                "match": {
                    "text": term
                }
            })

    return {
        "size": size,
        "query": {
           "bool":{
               "should": should_body,
               'must': must_body
           }
        }
    }
