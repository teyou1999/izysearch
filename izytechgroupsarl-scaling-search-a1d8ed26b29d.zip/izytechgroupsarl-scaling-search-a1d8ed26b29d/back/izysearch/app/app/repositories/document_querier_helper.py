from app.repositories.elastic_query_helper import build_docs_filter_query , build_pages_filter_query
from app.repositories.suggestion_helper import suggest_query
from noyau import Memory
from noyau.models import Folder , Page , Organisation
from izysearch.settings import MEDIA_BASE
from noyau.repositories.db import get_all , get_one_with_params


def construct_es_params ( folder: Folder , request: dict ) :
    """
    Build the param for Filtering ElasticSearch Information
    :param folder:
    :param request:
    :return:
    """
    params = {
        'folder' : folder
    }

    if 'extensions' in request.data :
        if isinstance ( request.data['extensions'] , list ) :
            params['extensions'] = [request.data['extensions']]
        else :
            params['extensions'] = [request.data['extensions']]

    if 'name' in request.data :
        params['name'] = request.data['name']

    if 'keywords' in request.data :
        if isinstance ( request.data['keywords'] , list ) :
            params['keywords'] = [request.data['keywords']]
        else :
            params['keywords'] = [request.data['keywords']]

    if 'query' in request.data :
        params['query'] = request.data['query']

    if 'meta_filters' in request.data :
        params['meta_filters'] = request.data['meta_filters']

    return params


def retrieve_filtered_paginate_docs ( params: dict , doc_size , offset: int , folder_items: list ,
                                      is_super_admin: bool = False ) :
    """
    Query a Specific folder ES index with params filtering doc size from offset. \
    :param params:
    :param doc_size:
    :param offset:
    :param folder_items: 
    :return: returns all the docs matching the query
    """
    folder = params['folder']
    if is_super_admin :
        return filter_paginate_docs_super_admin ( params , doc_size , offset , folder_items )

    return filter_docs_single_org ( params , doc_size , offset , folder_items , folder.organisation )


def filter_paginate_docs_super_admin ( params: dict , doc_size , offset , folder_items: list ) -> (list , list) :
    """
    Get docs related to a Super admin
    :param params:
    :param page_size:
    :param folder_items:
    :return:
    """
    # Get all orgas
    orgs = get_all ( Organisation )
    docs = []
    scores = []
    nb_matching = 0
    for org in orgs :
        root_folder = get_one_with_params ( Folder , uuid = org.root_folder )
        if root_folder.nb_files != 0 and root_folder.is_indexed :
            new_docs , new_scores , matching_docs = filter_docs_single_org ( params , doc_size , offset , folder_items ,
                                                                             org )
            docs += new_docs
            scores += new_scores
            nb_matching += matching_docs
        else :
            continue
    return docs , scores , nb_matching


def filter_docs_single_org ( params: dict , doc_size , offset , folder_items: list , org: Organisation ) -> (
list , list) :
    """
    Get all the docs for a single organisation
    :param params:
    :param page_size:
    :param folder_items:
    :param org:
    :return:
    """
    root_folder = get_one_with_params ( Folder , uuid = org.root_folder )
    m = Memory.getInstance ( )
    if str ( root_folder.uuid ) not in m.indexes :
        return [] , [] , 0

    index_name = m.indexes[str ( root_folder.uuid )]['documents']

    # Retrieve File ID in which we should filter
    use_query = 'query' in params
    # Build the ElasticSearch Body for this query
    if use_query :
        old_query = m.text_processor.preprocess_string ( params['query'] )
        params['query'] = suggest_query ( m.es_client , index_name , old_query )

    # Get Folder id in which to filter
    params['folder_items'] = folder_items

    # Build the ElasticSearch Body for this query

    filtering_query_es_body = build_docs_filter_query ( params , doc_size , offset , use_query ,
                                                        all_props = True , preprocessor = m.text_processor )
    # Apply the query to filter
    es_docs = m.es_client.retrieve_docs ( filtering_query_es_body , index_name , '_doc' )

    docs = [hit['_source'] for hit in es_docs]
    scores = [hit['_score'] for hit in es_docs]

    if not docs :
        return docs , scores , 0

    if max ( scores ) == 1.0 :
        return [] , [] , 0

    retrieved_docs = []
    retrieved_scores = []

    for doc , score in zip ( docs , scores ) :
        if score > 1.0 :
            retrieved_docs.append ( doc )
            retrieved_scores.append ( score )

    matching_docs = 0

    if offset == 0 :
        query = {
            "query" : filtering_query_es_body['query']
        }
        matching_docs = m.es_client.count_docs ( query , index_name )

    return retrieved_docs , retrieved_scores , matching_docs


def retrieve_filtered_paginate_pages ( params: dict , page_size: int , folder_items: list ,
                                       is_super_admin: bool = False ) -> list :
    """
    Query a Specific folder ES index with params filtering doc size from offset. \
    :param params:
    :param page_size:
    :param offset:
    :param folder_items
    :return: return all the pages
    """
    folder = params['folder']
    if is_super_admin :
        return filter_paginate_pages_super_admin ( params , page_size , folder_items )

    return filter_pages_single_org ( params , page_size , folder_items , folder.organisation )


def filter_paginate_pages_super_admin ( params: dict , page_size: int , folder_items: list ) -> list :
    """
    Get pages related to a Super admin
    :param params:
    :param page_size:
    :param folder_items:
    :return:
    """
    # Get all orgas
    orgs = get_all ( Organisation )
    pages = []
    for org in orgs :
        root_folder = get_one_with_params ( Folder , uuid = org.root_folder )
        if root_folder.nb_files != 0 and root_folder.is_indexed :
            pages += filter_pages_single_org ( params , page_size , folder_items , org )
        else :
            continue

    return pages


def filter_pages_single_org ( params: dict , page_size: int , folder_items: list , org: Organisation ) -> list :
    """
    Get all the pages for a single organisation
    :param params:
    :param page_size:
    :param folder_items:
    :param org:
    :return:
    """
    root_folder = get_one_with_params ( Folder , uuid = org.root_folder )
    m = Memory.getInstance ( )
    if str ( root_folder.uuid ) not in m.indexes :
        return []

    index_name = m.indexes[str ( root_folder.uuid )]['pages']

    # Retrieve File ID in which we should filter
    use_query = 'query' in params

    # Get Folder id in which to filter
    params['folder_items'] = folder_items

    # Build the ElasticSearch Body for this query
    if use_query :
        old_query = m.text_processor.preprocess_string ( params['query'] )
        params['query'] = suggest_query ( m.es_client , index_name , old_query )

    filtering_query_es_body = build_docs_filter_query ( params , 10000 , offset = 0 , use_query = use_query ,
                                                        all_props = False , preprocessor = m.text_processor )
    # Apply the query to filter
    es_docs = m.es_client.retrieve_docs ( filtering_query_es_body , index_name , '_doc' )
    file_ids = [hit['_source']['file_id'] for hit in es_docs]
    file_ids = list ( set ( file_ids ) )

    # Build the ElasticSearch Body for this query
    filtering_query_es_body = build_pages_filter_query ( params = params , size = page_size ,
                                                         preprocessor = m.text_processor , file_ids = file_ids )

    # Apply the query to filter
    es_pages = m.es_client.retrieve_docs ( filtering_query_es_body , index_name , '_doc' )

    return es_pages


def get_server_path ( abs_path ) :
    """
    Build an URL for an absolute path on the server. <br/>
    :param abs_path:
    :return:
    """
    if not abs_path :
        return None

    relative_path = abs_path.split ( 'izysearch/data/' )[-1]
    return MEDIA_BASE + relative_path


def add_infos ( docs: list , params: dict , scores: list ) -> list :
    """
    Append new information to file.
    We have for exemple :
     1. The text
     2. The direct parent folder
     3. The image of the first page
    :param docs:
    :return:
    """

    m = Memory.getInstance ( )

    for doc , score in zip ( docs , scores ) :
        doc_folder = get_one_with_params ( Folder , uuid = doc.folder.organisation.root_folder )
        index_name = f'{doc_folder.name}_pages_{doc_folder.id}'.lower ( )

        first_page = get_one_with_params ( Page , file = doc , page = 0 )
        doc.folder_name = doc.folder.name
        doc.score = score

        if first_page :
            doc.text = first_page.text
            doc.image = first_page.image.path

            filtering_query_es_body = build_pages_filter_query ( params = params , size = 1 ,
                                                                 preprocessor = m.text_processor , file_ids = [doc.id] )

            hits = m.es_client.retrieve_docs ( filtering_query_es_body , index_name , '_doc' )

            if hits :
                best_page = get_one_with_params ( Page , id = hits[0]['_source']['page_id'] )
                if best_page :
                    doc.text = best_page.text.replace ( '\n' , ' ' ).replace ( '\t' , ' ' )
                    doc.temp_pdf = best_page.url
                else :
                    doc.text = doc.text.replace ( '\n' , ' ' ).replace ( '\t' , ' ' )
            else :
                doc.text = doc.text.replace ( '\n' , ' ' ).replace ( '\t' , ' ' )
        else :
            doc.text = doc.display_name
            doc.image = None

    return docs
