import io
import os
import pickle

from datetime import datetime
from operator import itemgetter

import google_auth_oauthlib
from django.core.files import File as FileDjango
from app.repositories import SCOPES_GOOGLE_DRIVE , GOOGLE_DRIVE_FILEDS, GOOGLE_DRIVE_ITEM_FIELDS
from app.repositories.json_helper import load_json_file
from dateutil import parser
from django.shortcuts import redirect
from django.utils.timezone import get_current_timezone
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from noyau.models import Folder , Connector , Organisation , ConnectorType , ConnectorFolder , File , ConnectorFile
from noyau.repositories.db import get_all , get_one_with_params
from noyau.repositories.file_helper import compute_file_size
from noyau.utils.folder_utils import escaped_file_or_folder_name
from noyau.utils.organisation_utils import get_organisation_root_folder
from google.auth.transport.requests import Request
from noyau.utils.user_utils import get_connected_user , get_connected_user_organisation
from rest_framework import status
from rest_framework.response import Response
from izysearch.settings import SUPER_ADMIN_ROLE, QUERYING_SERVER



def create_folder_with_parent(name, parent):
    """
    Create a new folder based on its name and the parent folder object.
    :param name:
    :param parent:
    :return:
    """
    name = str(escaped_file_or_folder_name(name))
    path = os.path.join(str(parent.path), name)

    if os.path.exists(path):
        return None

    os.mkdir(path)
    folder = Folder.objects.create(
        name = name,
        path = path,
        organisation = parent.organisation,
        parent= parent
    )
    return folder

def get_folder_path(org, connector_type):
    """
    Get The path Created during a process of connector creation
    :param org:
    :param connector_type:
    :return:
    """
    root_folder = get_organisation_root_folder(org)
    name = str(escaped_file_or_folder_name(connector_type.name))
    path = os.path.join(str(root_folder.path), name)
    return path


def delete_inconsistent_folder(org, connector_type):
    """
    Delete a file from the file system and in the DB whe the connector creation fails.
    :param path:
    :return:
    """
    path = get_folder_path(org, connector_type)
    existing_folder = get_one_with_params(Folder, path=path)
    if existing_folder:
        existing_folder.delete()
    else:
        os.remove(path)


def create_connector_dir(org, connector_type):
    """
    Creation of the default Folder for an organisation for a given connector.
    We return None if the folder already Exists.
    :param org: Organisation object
    :param connector_type
    :return:
    """
    connector = get_all(Connector, organisation=org, type=connector_type)
    if connector:
        return None

    root_folder = get_organisation_root_folder(org)
    name = str(escaped_file_or_folder_name(connector_type.name))
    path = os.path.join(str(root_folder.path), name)

    if os.path.exists(path):
        return None

    os.mkdir(path)
    folder = Folder.objects.create(
        name = connector_type.name,
        path = path,
        organisation = org,
        parent= root_folder
    )
    return folder


def get_gdrive_auth_url(credential_file):
    """
    Create The Authorization URl and the State to track.
    :param credential_file:
    :return:
    """
    try:
        flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
            credential_file,
            SCOPES_GOOGLE_DRIVE
        )

        flow.redirect_uri = QUERYING_SERVER + 'gdrive/auth'

        authorization_url, state = flow.authorization_url(
            access_type='offline',
            include_granted_scopes='true'
        )

        return authorization_url, state
    except:
        return None, None


def google_drive_connection(credential_file, authorization_response):
    """
    Create the credential token object for a Google drive connection.
    :param credential_file:
    :return:
    """
    credentials = None
    try:
        flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
                credential_file,
                SCOPES_GOOGLE_DRIVE
            )
        flow.redirect_uri = QUERYING_SERVER + 'gdrive/auth'
        flow.fetch_token(authorization_response=authorization_response)
        credentials = flow.credentials
        return credentials
    except:
        print(f'An Error occurs during the authentication with : {credential_file}')
        return credentials


def get_connector_credentials(connector):
    """
    Get The credentials of a connector.
    :param connector:
    :return:
    """
    return pickle.loads(connector.credentials)


def google_drive_authentication(connector):
    """
    Try to authenticate on Google Drive using the credential file.
    Return True if everything is OK or False otherwise.
    :param connector:
    :return:
    """
    try:
        credentials = pickle.loads(connector.credentials)

        if credentials and credentials.valid and not credentials.expired:
            return True
        elif credentials and credentials.expired and credentials.refresh_token:
            credentials.refresh(Request())
            connector.credentials = pickle.dumps(credentials)
            connector.save()
            return True

        if not connector.credential_file:
            return False
    except:
        return False


def create_google_drive_connector_obj(org, connector_type, credential_file, authorization_response):
    """
    Create a connector for Google Drive
    :param org:
    :param connector_type:
    :param credential_file:
    :return:
     1 : A connector already exists or the root folder exists
     2 : The credential file is not valid
     3: Internal Error occurs.
     Connector : If everthing is OK
    """

    # Check the first connection for the credential file
    credentials = google_drive_connection(credential_file, authorization_response)
    if not credentials:
        return 2

    connector_folder = create_connector_dir(org, connector_type)
    if not connector_folder:
        return 1

    try:
        cred_infos = load_json_file(credential_file)

        print()
        print(cred_infos)
        print()

        # We have the credentials, we put them in te connector then
        connector = Connector.objects.create(
            type = connector_type,
            root_folder = connector_folder,
            organisation = org,
            signin_url = cred_infos['web']['auth_uri'],
            url = cred_infos['web']['auth_uri'],
            client_id = cred_infos['web']['client_id'],
            secret = cred_infos['web']['client_secret'],
            last_auth = datetime.now(tz=get_current_timezone()),
            credential_file = credential_file,
            credentials = pickle.dumps(credentials)
        )

        return connector
    except:
        connector_folder.delete()
        return 3

def check_request_connector_org_type(request, type='GET'):
    """
    Request Checking for th connector of an organisation.
    We want to check if the organisation and the connector are valid.
    :param request:
    :return:
    """
    token = request.META.get ( 'HTTP_AUTHORIZATION' , None )
    account = get_connected_user(token)
    connected_user_org = get_connected_user_organisation(token)

    data = request.GET if type == 'GET' else request.data
    if 'organisation' not in data:
        return Response (
            { "errors" : "The Organisation is mandatory" } ,
            status = status.HTTP_400_BAD_REQUEST
        )
    organisation = get_one_with_params(Organisation, uuid=data['organisation'])

    if not organisation:
        return Response (
            { "errors" : "The Organisation does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    if organisation.name != connected_user_org.name and account.role.id != SUPER_ADMIN_ROLE:
        return Response (
            { "errors" : "You Cannot Create connector for another Organisation" } ,
            status = status.HTTP_401_UNAUTHORIZED
        )

    if 'type' not in data:
        return Response (
            { "errors" : "The Connector Type is mandatory" } ,
            status = status.HTTP_400_BAD_REQUEST
        )
    connector_type = get_one_with_params(ConnectorType, uuid=data['type'])

    if not connector_type:
        return Response (
            { "errors" : "The Connector Type does not exist" } ,
            status = status.HTTP_404_NOT_FOUND
        )

    return {
        'organisation': organisation,
        'type': connector_type
    }


def get_gdrive_item_by_id(item_id, connector , service=None):
    """
    Get a Specific folder  or file with its connector based on its ID.
    The connector is already supposed to be authenticated.
    :param item_id:
    :param connector:
    :return:
    """
    if not service:
        credentials = get_connector_credentials(connector)
        service = build('drive', 'v3', credentials=credentials)
    try:
        item = service.files().get(fileId=item_id, fields=GOOGLE_DRIVE_ITEM_FIELDS).execute()
    except:
        print(f'An error Occurs during the item retrieval (ID): {item_id}')
        item = None
    return item


def get_gdrive_items_id_list(item_list, connector):
    """
    Get Drive item by list
    :param item_list:
    :param connector:
    :return:
    """
    return_list = []
    credentials = get_connector_credentials(connector)
    service = build('drive', 'v3', credentials=credentials)
    for item_id in item_list:
        item = get_gdrive_item_by_id(item_id, connector, service)
        if item:
            item['createdTime'] = parser.isoparse(item['createdTime'])
            return_list.append(item)

    # Sort item list
    sorted_item_list = sorted(return_list, key=itemgetter('createdTime'))
    return sorted_item_list


def create_gdrive_folders(folder_list, connector):
    """
    Create All Folder referenced by IDs in Google Drive
    :param folder_list:
    :param connector:
    :return:
    """
    sorted_folders = get_gdrive_items_id_list(folder_list, connector)
    created_folders = []
    created_files = []
    for folder_info in sorted_folders:
        # Get the associated folder if ti exists
        connector_folder = get_one_with_params(ConnectorFolder, connector=connector,
                                               id_resource = folder_info['id'])

        if connector_folder:
            # Everything is Deleted and Stuff are synchronized again
            connector_folder.folder.delete()

        # We check if its first parent exists
        parent_folder_connector = get_one_with_params(ConnectorFolder,
                                                      connector=connector, id_resource = folder_info['parents'][0])

        if parent_folder_connector:
            parent_folder = parent_folder_connector.folder
        else:
            # No parent put at the root of the connector
            parent_folder = connector.root_folder

        # Create folder
        created_folder = create_folder_with_parent(folder_info['name'], parent_folder)
        created_folders.append(created_folder)

        # Creation of the connector mapping object
        connector_folder = ConnectorFolder.objects.create(
            connector = connector,
            folder = created_folder,
            id_resource = folder_info['id'],
            created_time = datetime.now(tz=get_current_timezone()),
            update_time = datetime.now(tz=get_current_timezone()),
            last_synchro = datetime.now(tz=get_current_timezone())
        )

        # Get Files of this folder and create Them
        created_files += get_and_create_gdrive_files_in_folder(connector_folder, connector)

    return created_folders, created_files


def get_and_create_gdrive_files_in_folder(connector_folder, connector):
    """
    Create all files and their connector from Google Drive.
    :param connector_folder:
    :param connector:
    :return:
    """
    credentials = get_connector_credentials(connector)
    service = build('drive', 'v3', credentials=credentials)
    query = f"mimeType != 'application/vnd.google-apps.folder' and '{connector_folder.id_resource}' in parents"
    g_files = service.files().list(q="%s"%query, fields=GOOGLE_DRIVE_FILEDS).execute()
    gfile_items = g_files.get('files', [])

    if not gfile_items:
        return []

    create_files = []
    for item in gfile_items:
        item['base_name'] = item['name'].encode('utf-8').decode('utf-8')
        if 'fileExtension' not in item or item['fileExtension'].strip() == '':
            extension = 'pdf'
            item['fileExtension'] = extension
            gdrive_doc = True
            file_ = _get_file_and_create_db_entry(item, service, extension, connector, connector_folder, gdrive_doc)
            if file_:
                create_files.append(file_)

        if 'webContentLink' in item and 'fileExtension' in item:
            extension = item['fileExtension']
            gdrive_doc = False
            item['name'] = item['name'].split('.')[0]
            file_ = _get_file_and_create_db_entry(item, service, extension, connector, connector_folder, gdrive_doc)
            if file_:
                create_files.append(file_)

    # Return the list of created Files
    return create_files

def _get_file_and_create_db_entry(item, service, extension, connector, connector_folder, gdrive_doc):
    """
    Get the file create for a Given Item
    :param item:
    :param service:
    :param extension:
    :param connector:
    :param connector_folder:
    :param gdrive_doc
    :return:
    """
    file_id = item['id']
    fh = io.BytesIO()
    if gdrive_doc:
        request = service.files().export_media(fileId=file_id, mimeType='application/pdf')
    else:
        request = service.files().get_media(fileId=file_id)
    downloader = MediaIoBaseDownload(fh, request)
    done = False
    try:
        file_path = str(escaped_file_or_folder_name(f"{item['name']}.{extension}"))
        file_path = os.path.join(str(connector_folder.folder.path), file_path)
        while done is False:
            status, done = downloader.next_chunk()
            print("Download %d%%." % int(status.progress() * 100))
        with open(file_path, "wb") as f:
            f.write(fh.getbuffer())

        file_ = _create_gdrive_file_instance(connector, file_path, connector_folder.folder, item)
        return file_
    except:
        print(f"Skipping file : {item['name']}")
        return None

def _get_owner_name(infos):
    """
    Get the owner of a file based on its infos
    :param infos:
    :return:
    """
    if 'owners' not in infos:
        return None

    if not infos['owners']:
        return None

    return infos['owners'][0]['displayName'].encode('utf-8').decode('utf-8')

def _create_gdrive_file_instance(connector, path, folder, infos):
    """
    Create in the DB an instance file.
    :param connector:
    :param path:
    :param folder:
    :param infos:
    :return:
    """
    name = None
    if 'name' in infos:
        name = infos['name'].encode('utf-8').decode('utf-8')

    owner = None
    if _get_owner_name(infos):
        owner = _get_owner_name(infos)

    with open(path, 'rb') as f:
        path_obj = FileDjango(f)
        file_obj = File.objects.create(
            folder = folder,
            path = path_obj,
            size = compute_file_size(path),
            display_name = f"{name}.{infos['fileExtension'].strip()}",
            name = f"{name}.{infos['fileExtension'].strip()}",
            logical_name = infos['base_name'],
            owner_name = owner,
            organisation = folder.organisation
        )

    _create_gdrive_file_connector(connector, file_obj, infos)

    return file_obj


def _create_gdrive_file_connector(connector, file, infos):
    """
    Create a Connector for a given file mapping
    :param file:
    :param connector:
    :param infos:
    :return:
    """
    ConnectorFile.objects.create(
            connector = connector,
            file = file,
            id_resource = infos['id'],
            uri = infos['webContentLink'] if 'webContentLink' in infos else None,
            created_time = parser.isoparse(infos['createdTime']),
            update_time = parser.isoparse(infos['modifiedTime']),
            last_synchro = datetime.now(tz=get_current_timezone())
        )

