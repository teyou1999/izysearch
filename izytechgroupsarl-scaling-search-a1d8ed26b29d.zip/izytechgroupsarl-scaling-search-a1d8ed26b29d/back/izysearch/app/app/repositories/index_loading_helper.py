from noyau import Memory
from noyau.models import Organisation , Folder , DocIndex, PageIndex
from noyau.repositories.db import get_all , get_one_with_params


def load_indexes():
    """
    Loading all Organisation Indexes.
    :return:
    """
    print('Loading Indexes ....')
    organisations = get_all(Organisation)
    indexes = {}
    for organisation in organisations:
        root_folder = get_one_with_params(Folder, uuid=organisation.root_folder)
        doc_index = get_one_with_params(DocIndex, folder=root_folder)
        page_index = get_one_with_params(PageIndex, folder=root_folder)

        if page_index and doc_index:
            indexes[str(root_folder.uuid)] = {
               'pages': page_index.es_index,
                'documents': doc_index.es_index
            }

    m = Memory.getInstance()
    m.indexes = indexes
