import os

from noyau.repositories.folder_helper import get_children_files


def process_duplicate_names(folder_list):
    """ If there are duplicate names in the folder list,
        the duplicate names are replaced by a minimal
        path description to clarify their difference.
        Paths are only displayed from a common divergence
        point, and truncated if necessary.
    """
    folder_names = [f.name for f in folder_list]
    if len(set(folder_names)) != len(folder_names):
        new_folder_names = []
        while folder_names:
            folder_names2 = folder_names.copy()
            folder_names2.pop(0)
            folder_names = replace_duplicates(folder_names,
                                            folder_names2,
                                            folder_list,
                                            len(new_folder_names))
            new_folder_names.append(folder_names[0])
            folder_names.pop(0)
        folder_list = update_folder_names(folder_list, new_folder_names)
    return folder_list


def replace_duplicates(names, copy, folder_list, length):
    """ Detects if folder objects exist wihth duplicate names,
        and if they are found, they are replaces with a
        minimal path description.
    """
    if names[0] in copy:
        changed = []
        name_to_change = names[0]
        for i, f in enumerate(names):
            if f == name_to_change:
                names[i] = folder_list[length + i].path
                changed.append(names[i])
        common = os.path.commonprefix(changed).split('/')[:-1]
        common_len = len(''.join([ f'{f}/' for f in common]))
        for f in changed:
            i = names.index(f)
            names[i] = truncate_path(f, common_len, name_to_change)
    return names


def truncate_path(path, length, name):
    """ Path descriptions are truncated: first we remove
        all common root elements, then if the remaining
        description is more than 15 characters, we show the
        path in the following format: common_root/.../foldername.
        If the common root folder is itself longer than 15 characters.
        it is truncated to its last 5 characters with ... as its beginning.
        The same truncation is also performed on the folder name.
    """
    truncated = path[length:]
    if len(truncated) > 15:
        trunc_arr = truncated.split('/')
        root = trunc_arr[0]
        if len(trunc_arr) > 2:
            root = trunc_arr[0]
            if len(root) > 15:
                root = f'...{root[-5:]}'
        if len(name) > 15:
            name = f'...{name[-5:]}'
        truncated = f'{root}/.../{name}'
    return truncated

def update_folder_names(folder_list, new_names):
    """ Overwrites the names of the folder objects
        passed in a list, with new names also
        passed in a list of equal length.
    """
    for i, f in enumerate(folder_list):
        folder_list[i].name = new_names[i]
    return folder_list
