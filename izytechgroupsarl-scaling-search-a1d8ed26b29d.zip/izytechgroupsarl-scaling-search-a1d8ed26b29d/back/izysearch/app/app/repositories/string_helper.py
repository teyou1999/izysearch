def deduplicate_string_list(string_list: list):
    """
    Purge a String list with case insensibility.
    :param string_list: input list.
    :return:
    """
    result = []
    marker = set()
    for l in string_list:
        ll = l.lower()
        if ll not in marker:   # test presence
            marker.add(ll)
            l = l.capitalize()
            result.append(l)   # preserve order
    return result
