SCOPES_GOOGLE_DRIVE = [
    'https://www.googleapis.com/auth/drive.metadata.readonly',
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/drive'
]


GOOGLE_DRIVE_FILEDS = "nextPageToken, files(id, name, kind, parents, modifiedTime, createdTime, owners, fileExtension, size, md5Checksum, webContentLink)"
GOOGLE_DRIVE_FILEDS_GET = "nextPageToken, files(id, name, kind)"
GOOGLE_DRIVE_ITEM_FIELDS = "id, name, kind, parents, modifiedTime,  createdTime, owners, fileExtension, size, md5Checksum, webContentLink"
GDRIVE_MIME_MAPING ={
	"html" : "text/html",
	"xhtml" : "text/html",
	"rtf" :"application/rtf",
	"odt" :"application/vnd.oasis.opendocument.text",
	"pdf" :"application/pdf",
	"doc" :"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"docx" :"application/vnd.openxmlformats-officedocument.wordprocessingml.document",
	"xls" :"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	"xlsx" :"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	"ods" :"application/x-vnd.oasis.opendocument.spreadsheet",
	"csv" :"text/csv",
	"ppt" :"application/vnd.openxmlformats-officedocument.presentationml.presentation",
	"pptx" :"application/vnd.openxmlformats-officedocument.presentationml.presentation",
	"odp" :"application/vnd.oasis.opendocument.presentation",
	"json" :"application/vnd.google-apps.script+json",
	"jpeg" :"image/jpeg",
	"jpg" :"image/jpeg",
	"png" :"image/png"
}
