from re import sub
from django.http.response import HttpResponse
from rest_framework import status
from rest_framework.authtoken.models import Token

class TokenMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        # If the query is related to the api Group
        if request.path.startswith('/api'):
            # Get the user
            header_token = request.META.get('HTTP_AUTHORIZATION', None)

            if header_token:
                try:
                    token = sub('Token ', '', request.META.get('HTTP_AUTHORIZATION', None))
                    token_obj = Token.objects.get(key=token)
                    request.user = token_obj.user
                    response = self.get_response(request)

                    return response
                except Token.DoesNotExist:
                    response = HttpResponse("Please Login before !",
                                             status=status.HTTP_401_UNAUTHORIZED)
                    return response
            else:
                response = HttpResponse("The Token is required here !",
                                             status=status.HTTP_401_UNAUTHORIZED)
                return response
        else:
            # Execute the query and return th resut
            response = self.get_response(request)
            return response
