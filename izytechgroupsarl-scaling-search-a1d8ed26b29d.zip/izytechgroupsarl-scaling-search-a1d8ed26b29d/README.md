# configuration du premier noeuds


# intaller java 

$ sudo apt install default-jdk -y

# Obtenez les référentiels Elasticsearch et mettez à jour votre système afin que vos serveurs soient informés du référentiel Elasticsearch nouvellement ajouté

$ sudo apt update && apt upgrade -y

$ sudo apt install software-properties-common python-software-properties apt-transport-https -y

$ wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -

$ echo "deb https://artifacts.elastic.co/packages/6.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-6.x.list

$ sudo apt update


# installer elasticsearch

$ sudo apt install elasticsearch -y


# editer le fichier de configuration elasticsearch.yml

$ cat > /etc/elasticsearch/elasticsearch.yml << EOF
cluster.name: izysearch1
node.name: Elasticsearch01
node.master: true
node.data: false
path.logs: /var/log/elasticsearch
path.data: /usr/share/elasticsearch/data
bootstrap.memory_lock: true
network.host: ip du noeuds
#nombre de noeuds elligible comme maitre
discovery.zen.minimum_master_nodes: 1 
#adresse ip des noeuds elligble de comme maitre
discovery.zen.ping.unicast.hosts: ["ip master"] 
EOF
# demarrer elastic

$ systemctl enable elasticsearch
$ systemctl start elasticsearch


# configuration du second noeuds

# intaller java 

$ sudo apt install default-jdk -y

# Obtenez les référentiels Elasticsearch et mettez à jour votre système afin que vos serveurs soient informés du référentiel Elasticsearch nouvellement ajouté

$ sudo apt update && apt upgrade -y

$ sudo apt install software-properties-common python-software-properties apt-transport-https -y

$ wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -

$ echo "deb https://artifacts.elastic.co/packages/6.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-6.x.list

$ sudo apt update


# installer elasticsearch

$ sudo apt install elasticsearch -y


# editer le fichier de configuration elasticsearch.yml

$ cat > /etc/elasticsearch/elasticsearch.yml << EOF
cluster.name: izysearch1
node.name: Elasticsearch02
node.master: false
node.data: true
path.logs: /var/log/elasticsearch
path.data: /usr/share/elasticsearch/data
bootstrap.memory_lock: true
network.host: ip du noeuds
#nombre de noeuds elligible comme maitre
discovery.zen.minimum_master_nodes: 1 
#adresse ip des noeuds elligble de comme maitre
discovery.zen.ping.unicast.hosts: ["193.70.112.205"] 
EOF

# demarrer elastic

$ systemctl enable elasticsearch
$ systemctl start elasticsearch

# configuration du dernier noeuds
# intaller java 11

$ sudo apt install default-jdk -y

# Obtenez les référentiels Elasticsearch et mettez à jour votre système afin que vos serveurs soient informés du référentiel Elasticsearch nouvellement ajouté

$ sudo apt update && apt upgrade -y

$ sudo apt install software-properties-common python-software-properties apt-transport-https -y

$ wget -qO - https://artifacts.elastic.co/GPG-KEY-elasticsearch | sudo apt-key add -

$ echo "deb https://artifacts.elastic.co/packages/6.x/apt stable main" | sudo tee -a /etc/apt/sources.list.d/elastic-6.x.list

$ sudo apt update


# installer elasticsearch

$ sudo apt install elasticsearch -y


# editer le fichier de configuration elasticsearch.yml

$ cat > /etc/elasticsearch/elasticsearch.yml << EOF
cluster.name: izysearch1
node.name: Elasticsearch03
node.master: false
node.data: true
path.logs: /var/log/elasticsearch
path.data: /usr/share/elasticsearch/data
bootstrap.memory_lock: true
network.host: ip du noeuds
#nombre de noeuds elligible comme maitre
discovery.zen.minimum_master_nodes: 1 
#adresse ip des noeuds elligble de comme maitre
discovery.zen.ping.unicast.hosts: ["ip master"] 
EOF

# demarrer elastic

$ systemctl enable elasticsearch
$ systemctl start elasticsearch

